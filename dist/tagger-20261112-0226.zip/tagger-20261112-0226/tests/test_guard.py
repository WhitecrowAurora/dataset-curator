"""资源守护的守卫。

看门狗的错误全是"静默跑偏"型：stop 被温度分支降级回 pause、
连续运行计时永不重置、显存单位差 1024 倍、GPU 传感器死了没人发现。
这些都发生在后台线程里，出了问题不会抛异常，只能靠断言钉死。
"""

from __future__ import annotations

import time

import pytest

from tagger import guard
from tagger.guard import GuardPolicy, GuardState, GuardWatchdog


@pytest.fixture
def gpu(monkeypatch):
    """把 GPU 读数钉住。返回 holder，测试里随时换读数。"""
    holder = {"v": (0.5, 25.0, 4096.0)}
    monkeypatch.setattr(guard, "_read_gpu", lambda: holder["v"])
    return holder


def _watchdog(tmp_path, **policy_kw) -> GuardWatchdog:
    # 磁盘阈值默认全关：测试机器剩多少空间不该影响结论
    kw = {"disk_min_free_gb": 0.0, "disk_min_free_pct": 0.0,
          "auto_tune_laptop": False}
    kw.update(policy_kw)
    return GuardWatchdog(GuardPolicy(**kw), data_dir=tmp_path, verbose=False)


# ------------------------------------------------------------------ 级别不降级


def test_stop_not_downgraded_by_temp_branch(tmp_path, gpu):
    """磁盘熔断置 stop 后，同一次采样里的温度分支只许加理由，不许降级。"""
    gpu["v"] = (0.5, 90.0, 4096.0)                     # 温度同时超熔断线
    wd = _watchdog(tmp_path, disk_min_free_gb=1e6)     # 磁盘必然 stop
    st = wd.sample_once()
    assert st.level == "stop"
    assert any("磁盘" in r for r in st.reasons)
    assert any("温度" in r for r in st.reasons)         # 温度理由也记下了


# ------------------------------------------------------------------ 连续运行


def test_continuous_rest_resumes(tmp_path, gpu):
    """连续运行到点：必须重置计时并排一个休息终点，休完要能自己恢复。"""
    wd = _watchdog(tmp_path, continuous_minutes=60, rest_minutes=5)
    wd._started_at = time.time() - 3600.0              # 已连跑 60 分钟
    st = wd.sample_once()
    assert st.level == "pause"
    assert wd._started_at > time.time() - 10.0         # 计时被重置
    assert wd._resume_after > time.time()              # 休息终点已排上
    # 休完之后必须自己恢复——以前 _started_at 只增不减，pause 永不解除
    wd._resume_after = 0.0
    st2 = wd.sample_once()
    assert st2.level == "ok"


# ------------------------------------------------------------------ GPU 读数


def test_gpu_read_reports_gb_not_mib(monkeypatch):
    """nvidia-smi 的 memory.used 单位是 MiB，不换算的话状态里虚大 1024 倍。"""

    class _R:
        returncode = 0
        stdout = "42, 55, 8192\n"

    monkeypatch.setattr(guard.subprocess, "run", lambda *a, **k: _R())
    util, temp, vram_gb = guard._read_gpu()
    assert (util, temp) == (0.42, 55.0)
    assert vram_gb == pytest.approx(8.0)


def test_sensor_death_stops_after_being_seen(tmp_path, gpu):
    """读到过正常数、之后连续读零：第三次必须 stop，不能带着坏仪表跑。"""
    wd = _watchdog(tmp_path)
    assert wd.sample_once().level == "ok"              # 记住"这台机器有 GPU"
    gpu["v"] = (0.0, 0.0, 0.0)
    assert wd.sample_once().level in ("ok", "warn")
    assert wd.sample_once().level in ("ok", "warn")
    st = wd.sample_once()
    assert st.level == "stop"
    assert any("读不到" in r for r in st.reasons)


def test_never_seen_gpu_is_not_an_error(tmp_path, gpu):
    """无卡/无驱动的机器从头到尾都是零读数，不能被 fail-loud 拦在门外。"""
    gpu["v"] = (0.0, 0.0, 0.0)
    wd = _watchdog(tmp_path)
    for _ in range(5):
        assert wd.sample_once().level == "ok"


# ------------------------------------------------------------------ 等待循环


def test_wait_can_run_returns_when_state_recovers(tmp_path, gpu):
    """pause 解除后要从等待里出来；循环里的变量名错一次这里必炸。"""
    wd = _watchdog(tmp_path)
    box = {"n": 0}

    class _Flip(GuardWatchdog):
        # state 读第三次时翻成 ok。property 只挂读取；__init__ 里的
        # 初始化赋值走下面这个空 setter。
        @property
        def state(self):
            box["n"] += 1
            if box["n"] >= 3:
                return GuardState(level="ok")
            return GuardState(level="pause", reasons=["冷却中"])

        @state.setter
        def state(self, v):
            pass

    flip = _Flip(GuardPolicy(disk_min_free_gb=0.0, disk_min_free_pct=0.0,
                             auto_tune_laptop=False),
                 data_dir=tmp_path, verbose=False)
    st = flip.wait_can_run(max_wait_min=1.0, poll_s=0.01)
    assert st.can_run
    assert box["n"] >= 3


def test_wait_can_run_gives_up_at_deadline(tmp_path, gpu):
    wd = _watchdog(tmp_path)
    wd.state = GuardState(level="pause")
    st = wd.wait_can_run(max_wait_min=0.02, poll_s=0.01)
    assert st.level == "pause"
    assert any("等待超过" in r for r in st.reasons)
