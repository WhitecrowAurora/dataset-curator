"""进度回调：Web UI 唯一的数据来源。

钉住四条，每条都对应一个"不钉住就会静默出错"的场景：

1. 每张图**恰好一条**事件，且事件里看到的 stats 已经结账；
2. 跳过 / 拉黑的图**不跑推理，但也要报**——否则进度条永远差最后一截，
   用户以为卡住了；
3. 订阅方自己抛异常不能中断整批（前端一个 KeyError 不该让三百万张停在第 3 张），
   但也不能完全静默，要报一次；
4. 并发跑的时候事件照样在主线程逐张到达，不是攒到最后一起给。
"""

from __future__ import annotations

from tagger.client import (ClientStats, Outcome, TaskRow, _artifact_paths,
                           _write_json_atomic, run_batch)
from tagger.config import OutputSpec


class _FakeClient:
    """只实现 run_batch 会摸到的东西：need_tags / output / process。"""

    need_tags = True

    def __init__(self, fail: set[str] | None = None):
        self.output = OutputSpec(mode="both", tag_min_count=1, tag_max_count=10)
        self.fail = fail or set()
        self.calls: list[str] = []

    def process(self, task, data, reader):
        self.calls.append(task.image_id)
        if task.image_id in self.fail:
            return Outcome(task.image_id, False, error="坏图", wall_ms=5)
        return Outcome(task.image_id, True, tag={"tag": ["red"]},
                       nl={"caption": "a red thing"}, wall_ms=5, tokens=3)


def _tasks(n: int) -> list[TaskRow]:
    return [TaskRow(shard="s.zip", image_id=f"a-{i:06d}", file=f"a-{i:06d}.png")
            for i in range(1, n + 1)]


def _run(tmp_path, tasks, client, hook, *, concurrency=1, **kw):
    return run_batch(
        client, tasks, None, out_dir=tmp_path, layout="flat", force=False,
        concurrency=concurrency, guard=None, stats=ClientStats(), failures=None,
        verbose=False, on_progress=hook, **kw,
    )


def test_each_task_reports_exactly_one_event(tmp_path):
    events = []

    def hook(kind, task, outcome, stats):
        settled = stats.done + stats.failed + stats.skipped + stats.blacklisted
        events.append((kind, task.image_id, settled))

    stats = _run(tmp_path, _tasks(3), _FakeClient(fail={"a-000002"}), hook)

    assert [e[0] for e in events] == ["done", "failed", "done"]
    # 回调在 stats 更新之后调：第 n 条事件必须刚好对应 n 张已结账
    assert [e[2] for e in events] == [1, 2, 3]
    assert (stats.done, stats.failed) == (2, 1)


def test_skipped_tasks_report_without_inference(tmp_path):
    task = _tasks(1)[0]
    tag_path, nl_path = _artifact_paths(tmp_path, task, "flat")
    _write_json_atomic(tag_path, {"tag": ["red"]})
    _write_json_atomic(nl_path, {"caption": "a red thing"})

    events: list[tuple[str, object]] = []
    client = _FakeClient()
    stats = _run(tmp_path, [task], client,
                 lambda kind, t, outcome, s: events.append((kind, outcome)))

    assert events == [("skipped", None)]
    assert client.calls == []          # 关键：跳过的图不该再去推理
    assert stats.skipped == 1


def test_blacklisted_task_is_reported_before_others(tmp_path):
    events: list[str] = []
    client = _FakeClient()

    stats = _run(tmp_path, _tasks(2), client,
                 lambda kind, t, outcome, s: events.append(kind),
                 fail_counts={"a-000001": 3}, max_failures=3)

    assert events == ["blacklisted", "done"]
    assert stats.blacklisted == 1
    assert client.calls == ["a-000002"]


def test_broken_hook_does_not_abort_the_batch(tmp_path, capsys):
    def boom(kind, task, outcome, stats):
        raise RuntimeError("前端炸了")

    stats = _run(tmp_path, _tasks(3), _FakeClient(), boom)

    assert stats.done == 3                       # 三张照样打完
    assert len(list(tmp_path.glob("*-tag.json"))) == 3
    err = capsys.readouterr().err
    assert err.count("[client][on_progress 异常]") == 1   # 只报第一次


def test_concurrent_path_still_reports_every_task(tmp_path):
    seen: list[str] = []
    kinds: list[str] = []

    _run(tmp_path, _tasks(4), _FakeClient(),
         lambda kind, t, outcome, s: (seen.append(t.image_id), kinds.append(kind)),
         concurrency=2)

    assert len(seen) == 4 and len(set(seen)) == 4   # 不重不漏
    assert kinds.count("done") == 4
