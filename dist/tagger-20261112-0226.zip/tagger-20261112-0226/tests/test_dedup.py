"""去重模块：哈希、分组、缓存续跑、清单消费、web 管理器。

这里验的是契约与生命周期，不是识别精度——用确定性噪声图，
距离要么个位数（同图重压缩）要么 30 上下（不同图），阈值 8 足够分开。
"""

from __future__ import annotations

import argparse
import io
import json
import random
import time
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from PIL import Image

from tagger.dedup import (DB_NAME, DedupParams, DedupStopped, _flush_bucket,
                          _Union, dhash64, hamming, load_exclude, run_dedup)
from tagger.web import dedup as dedup_mod
from tagger.web.app import create_app


# ---------------------------------------------------------------- 造图

def _noise_png_bytes(seed: int, size: tuple[int, int] = (48, 48)) -> bytes:
    """确定性噪声图：同 seed 同字节；不同 seed 的 dHash 距离 30 上下。"""
    r = random.Random(seed)
    im = Image.new("L", size)
    im.putdata([r.randint(0, 255) for _ in range(size[0] * size[1])])
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()


def _recompress(data: bytes, quality: int) -> bytes:
    im = Image.open(io.BytesIO(data))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=quality)
    return buf.getvalue()


@pytest.fixture
def corpus(tmp_path: Path) -> Path:
    """a/1.png 与 a/2.png 字节相同；pack.zip 里还有一个同字节成员；
    b/3.jpeg、b/4.png 是另外两张独立的噪声图（与 base 距离 30 上下，
    不会误入精确组）。"""
    src = tmp_path / "batch"
    (src / "a").mkdir(parents=True)
    (src / "b").mkdir()
    base = _noise_png_bytes(1)
    (src / "a" / "1.png").write_bytes(base)
    (src / "a" / "2.png").write_bytes(base)
    (src / "b" / "3.jpeg").write_bytes(_noise_png_bytes(3))
    (src / "b" / "4.png").write_bytes(_noise_png_bytes(2))
    with zipfile.ZipFile(src / "pack.zip", "w") as zf:
        zf.writestr("a/1.png", base)
    return src


def _params(src: Path, tmp_path: Path, **kw) -> DedupParams:
    defaults = dict(input_dir=str(src), out_dir=str(tmp_path / "out"),
                    workers=4)
    defaults.update(kw)
    return DedupParams(**defaults)


# ---------------------------------------------------------------- 哈希

def test_dhash64_same_bytes_same_hash():
    a = _noise_png_bytes(7)
    assert dhash64(a) == dhash64(a)


def test_dhash64_recompress_close_other_far():
    a = _noise_png_bytes(1)
    b = _noise_png_bytes(2)
    assert hamming(dhash64(a), dhash64(_recompress(a, 90))) <= 8
    assert hamming(dhash64(a), dhash64(b)) > 16


def test_signed64_roundtrip():
    from tagger.dedup import _to_signed64, _to_unsigned64

    for v in (0, 1, (1 << 63) - 1, 1 << 63, (1 << 64) - 1):
        assert _to_unsigned64(_to_signed64(v)) == v


def test_hamming_threshold_boundary():
    # 距离恰好等于阈值要并上，差一就不并——LSH 的召回边界
    assert hamming(0b1111, 0b0000) == 4
    union = _Union()
    assert _flush_bucket([("a", 0b0000), ("b", 0b0100), ("c", 0b1111)],
                         threshold=2, union=union) == 1
    assert union.find("a") == union.find("b")
    assert union.find("c") not in (union.find("a"), union.find("b"))


def test_flush_bucket_cap_degrades_to_identical_only():
    # 超过 BUCKET_CAP 的大桶退化为只并完全相同的 dHash，避免平方级
    from tagger.dedup import BUCKET_CAP

    union = _Union()
    bucket = [(f"k{i}", i + 1) for i in range(BUCKET_CAP + 10)]
    bucket.append(("dup1", 99_999))
    bucket.append(("dup2", 99_999))
    n = _flush_bucket(bucket, threshold=8, union=union)
    assert n == 1
    assert union.find("dup1") == union.find("dup2")
    assert union.find("k0") != union.find("k1")


# ---------------------------------------------------------------- 参数校验

def test_validate_rejects_bad_params(tmp_path):
    with pytest.raises(ValueError):
        DedupParams(input_dir="").validate()
    with pytest.raises(ValueError):
        DedupParams(input_dir="x", mode="fuzzy").validate()
    with pytest.raises(ValueError):
        DedupParams(input_dir="x", keep="newest").validate()
    with pytest.raises(ValueError):
        DedupParams(input_dir="x", threshold=64).validate()


def test_default_out_dir_is_sibling(tmp_path):
    src = tmp_path / "batch"
    src.mkdir()
    assert DedupParams(input_dir=str(src)).resolved_out_dir() == \
        tmp_path / "batch-dedup"


# ---------------------------------------------------------------- 分组与产出

def test_exact_group_across_dir_and_zip(corpus, tmp_path):
    summary = run_dedup(_params(corpus, tmp_path, mode="similar"))
    assert summary["discovered"] == 5
    # 三个同字节成员并成一组（组内 sha 唯一 → kind=exact），噪声图独立
    assert summary["duplicates"] == 2
    assert summary["groups_exact"] == 1
    assert summary["groups_near"] == 0

    exclude = load_exclude(summary["exclude_file"])
    assert len(exclude) == 2
    assert any("pack.zip::a/1.png" in k for k in exclude)
    assert not any(k.endswith("a\\1.png") for k in exclude)  # 保留那张不进清单

    rows = [json.loads(line)
            for line in Path(summary["report_file"]).read_text(encoding="utf-8").splitlines()]
    assert len(rows) == 1
    row = rows[0]
    assert row["kind"] == "exact"
    assert Path(row["keep"]["rel_path"]).as_posix() == "a/1.png"
    assert {d["distance"] for d in row["duplicates"]} == {0}
    # 画师名与 split 同口径：第一层目录
    assert row["keep"]["artist"] == "a"


def test_near_group_from_recompression(corpus, tmp_path):
    # 换成没有 zip 的目录、把 2.png 删掉，把 3.jpeg 换成 1.png 的重压缩：
    # 相似组 = {1.png, 3.jpeg}，4.png 独立
    src = corpus
    (src / "pack.zip").unlink()
    (src / "a" / "2.png").unlink()
    base = _noise_png_bytes(1)
    (src / "b" / "3.jpeg").write_bytes(_recompress(base, 40))
    summary = run_dedup(_params(src, tmp_path, mode="similar", threshold=8))
    assert summary["groups_near"] == 1
    rows = [json.loads(line)
            for line in Path(summary["report_file"]).read_text(encoding="utf-8").splitlines()]
    row = rows[0]
    assert row["kind"] == "near"
    assert row["duplicates"][0]["rel_path"].endswith("3.jpeg")
    assert row["duplicates"][0]["distance"] <= 8


def test_exact_mode_ignores_recompression(corpus, tmp_path):
    (corpus / "pack.zip").unlink()
    summary = run_dedup(_params(corpus, tmp_path, mode="exact"))
    assert summary["duplicates"] == 1   # 只有 1.png/2.png 这对
    assert summary["groups_exact"] == 1


def test_keep_largest_picks_biggest_file(tmp_path):
    src = tmp_path / "batch"
    src.mkdir()
    base = _noise_png_bytes(3)
    (src / "small.png").write_bytes(base)
    (src / "big.png").write_bytes(_recompress(base, 95))  # 噪声图 jpeg95 通常比 png 大
    if (src / "big.png").stat().st_size <= (src / "small.png").stat().st_size:
        # 保险：构造大小差距与图内容无关的兜底
        (src / "big.png").write_bytes(base + b"\x00" * 2048)
    summary = run_dedup(_params(src, tmp_path, mode="similar", keep="largest"))
    rows = [json.loads(line)
            for line in Path(summary["report_file"]).read_text(encoding="utf-8").splitlines()]
    assert rows[0]["keep"]["rel_path"].endswith("big.png")
    assert summary["duplicates"] == 1


def test_summary_and_output_files_exist(corpus, tmp_path):
    summary = run_dedup(_params(corpus, tmp_path))
    out = Path(summary["out_dir"])
    assert (out / DB_NAME).is_file()
    assert (out / "dedup-summary.json").is_file()
    assert summary["elapsed_s"] >= 0
    assert summary["stopped"] is False
    assert summary["preview"] and summary["preview"][0]["kind"] == "exact"


# ---------------------------------------------------------------- 断点续跑

def test_resume_uses_cache_and_mtime_invalidation(corpus, tmp_path):
    p = _params(corpus, tmp_path)
    first = run_dedup(p)
    assert first["hashed"] == 5 and first["cached"] == 0

    second = run_dedup(p)
    assert second["hashed"] == 0 and second["cached"] == 5

    # 文件变了要重算
    time.sleep(0.01)
    import os

    os.utime(corpus / "a" / "1.png")
    third = run_dedup(p)
    assert third["hashed"] == 1 and third["cached"] == 4


def test_stop_mid_scan_then_resume(corpus, tmp_path):
    calls = {"n": 0}

    def stop_after_first() -> bool:
        return calls["n"] > 0

    def on_progress(done, total, cur):
        calls["n"] += 1

    p = _params(corpus, tmp_path, workers=1)
    with pytest.raises(DedupStopped):
        run_dedup(p, on_progress=on_progress, should_stop=stop_after_first)

    # 中断后产出文件不该出现；缓存里已有部分哈希
    assert not (Path(p.out_dir) / "dedup-exclude.txt").exists()

    # 重跑：剩下的接着算，最终结果完整
    summary = run_dedup(p)
    assert summary["duplicates"] == 2
    assert summary["cached"] >= 1   # 至少第一张来自中断前


def test_errors_do_not_break_the_batch(corpus, tmp_path):
    # 一个成员损坏：记错误、不进组、整批照常出结果
    (corpus / "b" / "broken.png").write_bytes(b"not an image")
    summary = run_dedup(_params(corpus, tmp_path))
    assert summary["errors"] == 1
    assert summary["discovered"] == 6
    assert summary["duplicates"] == 2
    exclude = load_exclude(summary["exclude_file"])
    assert not any("broken" in k for k in exclude)


# ---------------------------------------------------------------- 清单消费（split --exclude）

def _split_args(src: Path, tmp_path: Path, exclude: Path | None) -> argparse.Namespace:
    return argparse.Namespace(
        tiers=None, input_dir=str(src), out_dir=str(tmp_path / "dist"),
        table=str(tmp_path / "shards.json"), mode="count", per_shard=100,
        max_bytes=0, layout="flat", aliases=None, limit=None,
        no_recursive=False, verify_pack=False,
        exclude=str(exclude) if exclude else None,
    )


def test_split_exclude_end_to_end(corpus, tmp_path):
    from tagger.cli import cmd_dedup, cmd_split
    from tagger.config import DEFAULT_TIERS

    summary = run_dedup(_params(corpus, tmp_path))
    exclude = Path(summary["exclude_file"])

    args = _split_args(corpus, tmp_path, exclude)
    args.tiers = DEFAULT_TIERS
    assert cmd_split(args) == 0

    shard = next((tmp_path / "dist").glob("*.zip"))
    with zipfile.ZipFile(shard) as zf:
        names = [n for n in zf.namelist() if n != "manifest.jsonl"]
    # 5 张里排除 2 张（同字节的 2.png 与 zip 成员）；保留的按
    # (artist, rel_path) 从存活集合顺序编号
    assert sorted(names) == ["a-000001.png", "b-000002.jpg", "b-000003.png"]

    table = json.loads((tmp_path / "shards.json").read_text(encoding="utf-8"))
    assert table["total_count"] == 3


def test_split_exclude_all_gone_returns_1(corpus, tmp_path):
    from tagger.cli import cmd_split
    from tagger.config import DEFAULT_TIERS

    summary = run_dedup(_params(corpus, tmp_path))
    # 全部排除：清单手工扩成全量（zip 成员的键是 容器::成员）
    all_keys = "\n".join([
        str(corpus / "a" / "1.png"), str(corpus / "a" / "2.png"),
        str(corpus / "b" / "3.jpeg"), str(corpus / "b" / "4.png"),
        f"{corpus / 'pack.zip'}::a/1.png",
    ])
    excl = tmp_path / "all.txt"
    excl.write_text(all_keys + "\n", encoding="utf-8")
    args = _split_args(corpus, tmp_path, excl)
    args.tiers = DEFAULT_TIERS
    assert cmd_split(args) == 1


def test_cli_dedup_parser():
    from tagger.cli import build_parser

    args = build_parser().parse_args([
        "dedup", "--input-dir", "x", "--mode", "exact", "--keep", "largest",
        "--threshold", "6", "--workers", "3"])
    assert args.input_dir == "x"
    assert args.mode == "exact"
    assert args.keep == "largest"
    assert args.threshold == 6
    assert args.workers == 3
    assert args.func.__name__ == "cmd_dedup"


def test_cli_dedup_resume_print(tmp_path, corpus, capsys):
    from tagger.cli import cmd_dedup

    args = argparse.Namespace(
        input_dir=str(corpus), out_dir=str(tmp_path / "out"), mode="similar",
        threshold=8, keep="first", workers=2, no_recursive=False)
    assert cmd_dedup(args) == 0
    assert cmd_dedup(args) == 0          # 第二次全缓存命中
    out = capsys.readouterr().out
    assert "缓存复用" in out
    assert "--exclude" in out


# ---------------------------------------------------------------- web 管理器

def _wait_dedup(job, timeout=8.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        snap = job.snapshot()
        if snap["status"] in ("done", "failed", "stopped"):
            return snap
        time.sleep(0.05)
    raise AssertionError(f"去重没在 {timeout}s 内结束：{snap['status']}")


@pytest.fixture
def dedup_client(monkeypatch, tmp_path):
    dedup_mod.DEDUPS._jobs.clear()
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def test_dedup_manager_success_and_summary(monkeypatch, tmp_path):
    dedup_mod.DEDUPS._jobs.clear()
    src = tmp_path / "batch"
    src.mkdir()
    (src / "1.png").write_bytes(_noise_png_bytes(1))
    monkeypatch.setattr(dedup_mod, "run_dedup", lambda params, **kw: {
        "duplicates": 3, "groups_exact": 1, "out_dir": str(tmp_path / "o")})
    job = dedup_mod.DEDUPS.create(input_dir=str(src), workers=2)
    snap = _wait_dedup(job)
    assert snap["status"] == "done"
    assert snap["summary"]["duplicates"] == 3
    assert snap["params"]["mode"] == "similar"


def test_dedup_manager_failure(monkeypatch, tmp_path):
    dedup_mod.DEDUPS._jobs.clear()
    src = tmp_path / "batch"
    src.mkdir()
    (src / "1.png").write_bytes(_noise_png_bytes(1))

    def boom(params, **kw):
        raise RuntimeError("磁盘没了")

    monkeypatch.setattr(dedup_mod, "run_dedup", boom)
    job = dedup_mod.DEDUPS.create(input_dir=str(src))
    snap = _wait_dedup(job)
    assert snap["status"] == "failed"
    assert "磁盘没了" in snap["error"]


def test_dedup_manager_stop(monkeypatch, tmp_path):
    dedup_mod.DEDUPS._jobs.clear()
    src = tmp_path / "batch"
    src.mkdir()
    (src / "1.png").write_bytes(_noise_png_bytes(1))

    def slow(params, *, should_stop=None, **kw):
        deadline = time.time() + 5
        while should_stop is None or not should_stop():
            if time.time() > deadline:
                raise AssertionError("stop 没传导到 run_dedup")
            time.sleep(0.02)
        raise DedupStopped()

    monkeypatch.setattr(dedup_mod, "run_dedup", slow)
    job = dedup_mod.DEDUPS.create(input_dir=str(src))
    time.sleep(0.1)
    assert dedup_mod.DEDUPS.stop(job.id) is True
    snap = _wait_dedup(job)
    assert snap["status"] == "stopped"
    # 已结束的再 stop 是 False（409 路径）
    assert dedup_mod.DEDUPS.stop(job.id) is False


def test_dedup_manager_one_at_a_time(monkeypatch, tmp_path):
    dedup_mod.DEDUPS._jobs.clear()
    src = tmp_path / "batch"
    src.mkdir()
    (src / "1.png").write_bytes(_noise_png_bytes(1))

    def slow(params, *, should_stop=None, **kw):
        time.sleep(0.5)
        return {}

    monkeypatch.setattr(dedup_mod, "run_dedup", slow)
    job = dedup_mod.DEDUPS.create(input_dir=str(src))
    with pytest.raises(RuntimeError):
        dedup_mod.DEDUPS.create(input_dir=str(src))
    _wait_dedup(job)
    # 结束后可以再开
    job2 = dedup_mod.DEDUPS.create(input_dir=str(src))
    _wait_dedup(job2)


def test_dedup_manager_validates_input(tmp_path):
    dedup_mod.DEDUPS._jobs.clear()
    with pytest.raises(ValueError):
        dedup_mod.DEDUPS.create(input_dir=str(tmp_path / "nope"))
    with pytest.raises(ValueError):
        dedup_mod.DEDUPS.create(input_dir=str(tmp_path), mode="fuzzy")


# ---------------------------------------------------------------- web 端点

def test_dedup_endpoints(dedup_client, monkeypatch, tmp_path):
    src = tmp_path / "batch"
    src.mkdir()
    (src / "1.png").write_bytes(_noise_png_bytes(1))
    monkeypatch.setattr(dedup_mod, "run_dedup", lambda params, **kw: {
        "duplicates": 0, "groups_exact": 0, "groups_near": 0,
        "exclude_file": str(tmp_path / "o" / "dedup-exclude.txt")})

    # 缺输入目录 → 400
    r = dedup_client.post("/api/dedup/start", json={"input_dir": ""})
    assert r.status_code == 400
    r = dedup_client.post("/api/dedup/start", json={"input_dir": str(tmp_path / "nope")})
    assert r.status_code == 400

    r = dedup_client.post("/api/dedup/start", json={"input_dir": str(src)})
    assert r.status_code == 202
    job_id = r.json()["id"]

    deadline = time.time() + 8
    while time.time() < deadline:
        snap = dedup_client.get(f"/api/dedup/{job_id}").json()
        if snap["status"] in ("done", "failed", "stopped"):
            break
        time.sleep(0.05)
    assert snap["status"] == "done"
    assert snap["summary"]["duplicates"] == 0

    assert dedup_client.get("/api/dedup/missing").status_code == 404
    r = dedup_client.post(f"/api/dedup/{job_id}/stop")
    assert r.status_code == 409


def test_dedup_endpoints_conflict(dedup_client, monkeypatch, tmp_path):
    src = tmp_path / "batch"
    src.mkdir()
    (src / "1.png").write_bytes(_noise_png_bytes(1))

    def slow(params, *, should_stop=None, **kw):
        time.sleep(0.6)
        return {}

    monkeypatch.setattr(dedup_mod, "run_dedup", slow)
    r = dedup_client.post("/api/dedup/start", json={"input_dir": str(src)})
    assert r.status_code == 202
    r2 = dedup_client.post("/api/dedup/start", json={"input_dir": str(src)})
    assert r2.status_code == 409
    job_id = r.json()["id"]
    r = dedup_client.post(f"/api/dedup/{job_id}/stop")
    assert r.status_code == 200
    assert r.json()["ok"] is True
