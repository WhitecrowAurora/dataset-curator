"""jsonl 产物形态：写、读、坏行，以及对账 / 报告 / 整理页能不能认。

这个文件**刻意不 importorskip("pyarrow")**：jsonl 形态存在的理由之一就是
"不装 pyarrow 也能落盘、也能读回来"。如果这里的测试自己要求 pyarrow，
那条理由就等于没人验证过，等哪天真在纯标准库环境里跑起来才发现是空的。

重点和 parquet 那份一样：**换形态之后结论不变**。同一条数据用 json 落、
用 jsonl 落、用 parquet 落，merge 与 report 给出的数字必须一致。
"""

from __future__ import annotations

import builtins
import json
from pathlib import Path

import pytest

from tagger import tag_manage as tm
from tagger.artifacts import (COLUMNS, JsonlSink, MultiShardSink, find_artifacts,
                              is_artifact, is_artifact_jsonl, iter_artifact_rows,
                              iter_jsonl_artifacts, load_done_ids, parse_payload,
                              safe_stem, shard_stem)
from tagger.merge import MergeStats, check, collect
from tagger.report import collect_points


def _tag_payload(image_id: str, tags: list[str], **extra) -> dict:
    return {"image_id": image_id, "tag": ", ".join(tags),
            "tags": [[t, 1.0] for t in tags], "ok": True, **extra}


def _nl_payload(image_id: str, caption: str, **extra) -> dict:
    return {"image_id": image_id, "caption": caption, "chars": len(caption),
            "nl_tokens": 42, "score": 4.0, "flags": [], "ok": True, **extra}


# ------------------------------------------------------------------ 落盘


def test_sink_writes_one_shard_and_reads_back(tmp_path):
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]),
             _nl_payload("a-000001", "一位穿红裙的女孩"))
    sink.close()

    files = sorted(tmp_path.glob("artifacts-*.jsonl"))
    assert [f.name for f in files] == ["artifacts-00000.jsonl"]
    rows = list(iter_jsonl_artifacts(files[0]))
    assert [r["image_id"] for r in rows] == ["a-000001"]
    # 中文必须原样回来：分隔符与转义都由标准库保证，不该出现 \\uXXXX
    assert "一位穿红裙的女孩" in files[0].read_text(encoding="utf-8")
    assert parse_payload("nl", rows[0]["nl"])["caption"] == "一位穿红裙的女孩"


def test_row_structure_matches_parquet(tmp_path):
    """两种分片的行结构必须逐字段一致，否则读侧就得按形态分支。"""
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    sink.close()

    row = next(iter(iter_artifact_rows(sorted(tmp_path.glob("*.jsonl"))[0])))
    assert tuple(row) == COLUMNS
    assert isinstance(row["tag"], str) and json.loads(row["tag"])["tag"] == "red"
    assert row["nl"] == ""          # 只跑 tag 时这一侧是空串，不是 None
    assert isinstance(row["ts"], float)


def test_named_sink_writes_one_file_per_shard(tmp_path):
    """定名模式：`artifacts-<包名>.jsonl`，不再带序号。"""
    sink = JsonlSink(tmp_path, rows_per_file=3, stem="dist-01")
    for i in range(1, 11):
        sink.add(f"a-{i:06d}", _tag_payload(f"a-{i:06d}", ["red"]), None)
    sink.close()

    files = sorted(p.name for p in tmp_path.glob("*.jsonl"))
    assert files == ["artifacts-dist-01.jsonl"]          # 满 3 行只落盘、不换文件
    assert len(list(iter_jsonl_artifacts(tmp_path / files[0]))) == 10


def test_named_sink_appends_when_resumed(tmp_path):
    """暂停后继续：接着写同名文件，不多出 -00001。"""
    first = JsonlSink(tmp_path, rows_per_file=10, stem="dist-01")
    first.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    first.close()

    second = JsonlSink(tmp_path, rows_per_file=10, stem="dist-01")
    second.add("a-000002", _tag_payload("a-000002", ["blue"]), None)
    second.close()

    files = sorted(p.name for p in tmp_path.glob("*.jsonl"))
    assert files == ["artifacts-dist-01.jsonl"]
    assert sorted(load_done_ids(tmp_path)) == ["a-000001", "a-000002"]


@pytest.mark.parametrize("named", [False, True])
def test_flush_failure_keeps_rows_and_retry_has_no_duplicates(tmp_path, monkeypatch, named):
    from tagger import artifacts

    sink = JsonlSink(tmp_path, stem="dist" if named else "")
    sink.add("old", {"tag": "red"}, None)
    sink.flush()
    sink.add("a", {"tag": "blue"}, None)
    sink.add("b", {"tag": "green"}, None)
    with monkeypatch.context() as mp:
        def fail_sync(_fd):
            raise OSError("disk unavailable after write")
        mp.setattr(artifacts.os, "fsync", fail_sync)
        with pytest.raises(OSError):
            sink.flush()
    assert sink.pending == 2
    sink.flush()
    assert sink.pending == 0
    assert [row["image_id"] for p in sorted(tmp_path.glob("*.jsonl"))
            for row in iter_jsonl_artifacts(p)] == ["old", "a", "b"]


@pytest.mark.parametrize("tail,kept", [
    (b'{"image_id":"bad","tag":', []),
    (b'{"image_id":"bad","tag":"\xe4', []),
    (b'{"image_id":"full","tag":"red"}', ["full"]),
])
def test_resume_repairs_only_incomplete_tail(tmp_path, tail, kept):
    sink = JsonlSink(tmp_path, stem="dist")
    sink.add("old", {"tag": "red"}, None)
    sink.flush()
    with sink.path.open("ab") as fh:
        fh.write(tail)
    resumed = JsonlSink(tmp_path, stem="dist")
    resumed.add("new", {"tag": "blue"}, None)
    resumed.close()
    assert [r["image_id"] for r in iter_jsonl_artifacts(resumed.path)] == ["old", *kept, "new"]


def test_replace_failure_keeps_numbered_batch(tmp_path, monkeypatch):
    sink = JsonlSink(tmp_path)
    sink.add("a", {"tag": "red"}, None)
    with monkeypatch.context() as mp:
        def fail_replace(*args):
            raise OSError("replace failed")
        mp.setattr(Path, "replace", fail_replace)
        with pytest.raises(OSError):
            sink.flush()
    assert sink.pending == 1
    sink.close()
    assert load_done_ids(tmp_path) == {"a"}


@pytest.mark.parametrize("fmt", ["jsonl", "parquet"])
def test_done_ids_require_a_valid_side(tmp_path, fmt):
    from tagger.artifacts import ParquetSink

    if fmt == "parquet":
        pytest.importorskip("pyarrow")
    sink = (JsonlSink if fmt == "jsonl" else ParquetSink)(tmp_path)
    cases = {
        "failed": ({"ok": False, "tag": "red"}, None),
        "empty": (None, None),
        "legacy": ({"tag": "red"}, None),
        "valid-nl": ({"ok": False, "tag": "red"}, {"caption": "description"}),
        "zero": ({"ok": True, "tag": "", "tags": [], "tag_backend": "wd-eva02"}, None),
        "empty-vlm": ({"ok": True, "tag": "", "tags": [], "tag_backend": "vlm"}, None),
        "bad-type": ({"ok": True, "tag": ["red"]}, None),
    }
    for image_id, (tag, nl) in cases.items():
        sink.add(image_id, tag, nl)
    sink._rows.append({"image_id": "broken", "tag": "{broken", "nl": "", "ts": 0.0})
    sink.close()
    assert load_done_ids(tmp_path) == {"legacy", "valid-nl", "zero"}


def test_named_sink_never_overwrites_when_append_is_off(tmp_path):
    """--force 会重做已完成的图，不能续写；那就退成 -2，绝不覆盖旧产物。"""
    first = JsonlSink(tmp_path, rows_per_file=10, stem="dist-01")
    first.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    first.close()

    forced = JsonlSink(tmp_path, rows_per_file=10, stem="dist-01", append=False)
    forced.add("a-000001", _tag_payload("a-000001", ["blue"]), None)
    forced.close()

    assert sorted(p.name for p in tmp_path.glob("*.jsonl")) == [
        "artifacts-dist-01-2.jsonl", "artifacts-dist-01.jsonl"]


def test_multi_shard_sink_splits_by_shard(tmp_path):
    """一个 job 里多个分包 → 每个包一个文件，交替写入也不串。"""
    sink = MultiShardSink(tmp_path, rows_per_file=2)
    sink.add("d1-001", _tag_payload("d1-001", ["red"]), None, "/in/dist-01.zip")
    sink.add("d2-001", _tag_payload("d2-001", ["blue"]), None, "/in/dist-02.zip")
    sink.add("d1-002", _tag_payload("d1-002", ["red"]), None, "/in/dist-01.zip")
    sink.close()

    got = {p.name: len(list(iter_jsonl_artifacts(p)))
           for p in sorted(tmp_path.glob("*.jsonl"))}
    assert got == {"artifacts-dist-01.jsonl": 2, "artifacts-dist-02.jsonl": 1}
    assert sorted(load_done_ids(tmp_path)) == ["d1-001", "d1-002", "d2-001"]


def test_multi_shard_sink_keeps_same_named_shards_apart(tmp_path):
    """两个目录里的同名 dist-01.zip 不能并进一个文件（成员机常见）。"""
    sink = MultiShardSink(tmp_path, rows_per_file=10)
    sink.add("a-1", _tag_payload("a-1", ["red"]), None, "/m1/dist-01.zip")
    sink.add("b-1", _tag_payload("b-1", ["blue"]), None, "/m2/dist-01.zip")
    sink.close()

    assert sorted(p.name for p in tmp_path.glob("*.jsonl")) == [
        "artifacts-dist-01-2.jsonl", "artifacts-dist-01.jsonl"]


def test_multi_shard_sink_names_shardless_rows(tmp_path):
    """拿不到来源包（HF 直读、单包）时用中性名，不落成 `artifacts-.jsonl`。"""
    sink = MultiShardSink(tmp_path, rows_per_file=10)
    sink.add("a-1", _tag_payload("a-1", ["red"]), None, "")
    sink.close()
    assert [p.name for p in tmp_path.glob("*.jsonl")] == ["artifacts-multi.jsonl"]


def test_safe_stem_cleans_only_what_cannot_be_a_filename():
    assert safe_stem("dist-01") == "dist-01"
    assert safe_stem("a/b:c*d?e") == "a_b_c_d_e"
    assert safe_stem("  第一包  ") == "第一包"        # 中文保留，日志里认得出
    assert safe_stem("...") == "batch"                # 全是点 → 回退
    assert safe_stem("x" * 100).__len__() == 60


def test_shard_stem_handles_local_and_hf_paths():
    assert shard_stem("/in/dist-01.zip") == "dist-01"
    assert shard_stem("D:\\in\\dist-02.tar") == "dist-02"
    # HF 直读：不能把 `#成员` 和 `hf://` 带进文件名
    assert shard_stem("hf://org/repo/shard-00001.tar#member") == "shard-00001"
    assert shard_stem("") == "multi"


def test_sink_shards_by_rows_and_collects_done_ids(tmp_path):
    sink = JsonlSink(tmp_path, rows_per_file=2)
    for i in range(1, 6):
        sink.add(f"a-{i:06d}", _tag_payload(f"a-{i:06d}", ["red"]), None)
    sink.close()

    assert len(sorted(tmp_path.glob("artifacts-*.jsonl"))) == 3      # 2 + 2 + 1
    assert sorted(load_done_ids(tmp_path)) == [f"a-{i:06d}" for i in range(1, 6)]


def test_sink_seq_continues_after_restart(tmp_path):
    """重启后接着往后编号。撞号会让新片把上次的成果整个覆盖掉。"""
    first = JsonlSink(tmp_path, rows_per_file=10)
    first.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    first.close()

    second = JsonlSink(tmp_path, rows_per_file=10)
    second.add("a-000002", _tag_payload("a-000002", ["blue"]), None)
    second.close()

    files = sorted(tmp_path.glob("artifacts-*.jsonl"))
    assert [f.name for f in files] == ["artifacts-00000.jsonl",
                                       "artifacts-00001.jsonl"]
    assert sorted(load_done_ids(tmp_path)) == ["a-000001", "a-000002"]


def test_seq_is_independent_per_format(tmp_path):
    """parquet 与 jsonl 各有各的编号。共用一套号会让两边的片名含义对不上。"""
    (tmp_path / "artifacts-00007.parquet").write_bytes(b"")
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    sink.close()
    assert (tmp_path / "artifacts-00000.jsonl").is_file()


def test_jsonl_needs_no_pyarrow(tmp_path, monkeypatch):
    """纯标准库环境：写、读、续跑判定都得照常工作——这是选它的理由之一。"""
    real_import = builtins.__import__

    def no_pyarrow(name, *args, **kwargs):
        if name.split(".")[0] == "pyarrow":
            raise ImportError("模拟没装 pyarrow")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", no_pyarrow)

    sink = JsonlSink(tmp_path, rows_per_file=1)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    sink.add("a-000002", _tag_payload("a-000002", ["blue"]), None)
    sink.close()

    assert sorted(load_done_ids(tmp_path)) == ["a-000001", "a-000002"]
    assert len(collect([tmp_path])) == 2


# ------------------------------------------------------------------ 坏行


def test_truncated_last_line_is_skipped(tmp_path):
    """写盘途中被杀 → 末尾留半行。当残片跳过，别让整片读不出来。"""
    path = tmp_path / "artifacts-00000.jsonl"
    path.write_text(
        json.dumps({"image_id": "a-1", "tag": "", "nl": "", "ts": 0.0}) + "\n"
        + '{"image_id": "a-2", "tag": "", "nl"',      # 没有换行，也没写全
        encoding="utf-8")

    assert [r["image_id"] for r in iter_jsonl_artifacts(path)] == ["a-1"]


def test_broken_middle_line_raises(tmp_path):
    """中间的行坏掉是真坏了，必须报出来——静默跳过等于悄悄少几张图。"""
    path = tmp_path / "artifacts-00000.jsonl"
    path.write_text(
        json.dumps({"image_id": "a-1", "tag": "", "nl": "", "ts": 0.0}) + "\n"
        + "这一行不是 JSON\n"
        + json.dumps({"image_id": "a-3", "tag": "", "nl": "", "ts": 0.0}) + "\n",
        encoding="utf-8")

    # 报错里要带行号，否则"这一片读不出来"等于没说
    with pytest.raises(ValueError, match=r":2:"):
        list(iter_jsonl_artifacts(path))


def test_foreign_jsonl_is_not_an_artifact(tmp_path):
    """failures.jsonl / manifest.jsonl 不是产物：既不该被扫进合并，也不该
    影响续跑判定。"""
    (tmp_path / "failures.jsonl").write_text(
        json.dumps({"image_id": "a-9", "error": "坏图"}) + "\n", encoding="utf-8")
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    sink.close()

    assert [p.name for p in find_artifacts(tmp_path)] == ["artifacts-00000.jsonl"]
    assert not is_artifact(tmp_path / "failures.jsonl")
    assert is_artifact_jsonl(tmp_path / "artifacts-00000.jsonl")
    assert sorted(load_done_ids(tmp_path)) == ["a-000001"]


# ------------------------------------------------------------------ 对账


def test_merge_reads_jsonl_artifacts(tmp_path):
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red", "blue"]),
             _nl_payload("a-000001", "a red square"))
    sink.add("a-000002", _tag_payload("a-000002", ["green"]),
             _nl_payload("a-000002", "a green circle"))
    sink.close()

    stats = MergeStats()
    records = collect([tmp_path], stats=stats)
    assert sorted(records) == ["a-000001", "a-000002"]
    assert records["a-000001"].tag == "red, blue"
    assert records["a-000001"].caption == "a red square"
    assert not stats.unreadable

    check(records, expected_ids=["a-000001", "a-000002"], stats=stats)
    assert stats.complete == 2
    assert not stats.failed


def test_merge_flags_conflict_between_json_and_jsonl(tmp_path, write_artifact):
    """两种形态并存且内容不同 = 内容冲突。不能因为格式不同就当成两条。"""
    write_artifact(tmp_path, "a-000001", tag="red", caption="from json")
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["blue"]),
             _nl_payload("a-000001", "from jsonl"))
    sink.close()

    stats = MergeStats()
    collect([tmp_path], stats=stats)
    assert "a-000001" in stats.duplicates
    assert stats.failed


# ------------------------------------------------------------------ 报告与整理页


def test_report_reads_jsonl_artifacts(tmp_path):
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red", "blue", "green"]),
             _nl_payload("a-000001", "a red square"))
    sink.close()

    points = collect_points([tmp_path])
    assert len(points) == 1
    p = points[0]
    assert (p.image_id, p.tag_count, p.chars) == ("a-000001", 3, len("a red square"))
    assert p.ok


def test_verify_reads_jsonl_artifacts(tmp_path):
    """复核页按分片扫目录：不认 jsonl 的话这一批就是"0 分片"，等于没人验过。"""
    from tagger.verify import iter_samples

    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["1girl", "solo"]),
             _nl_payload("a-000001", "a girl alone"))
    sink.close()
    # 同目录下的失败账不是样本
    (tmp_path / "failures.jsonl").write_text('{"image_id": "a-9"}\n', encoding="utf-8")

    samples = dict(iter_samples(tmp_path))
    assert list(samples) == ["a-000001"]
    assert samples["a-000001"][".tag"] == b"1girl, solo"
    assert samples["a-000001"][".nl"] == b"a girl alone"


def test_upload_page_lists_merged_table(tmp_path):
    """成员的流程是"本地合并成总表 → 发总表给服务器"，所以回传页必须能选到
    merged.jsonl；而 failures.jsonl 是失败账，不该出现在待传清单里。"""
    from fastapi.testclient import TestClient

    from tagger.web import app as app_mod

    sink = JsonlSink(tmp_path, rows_per_file=10, stem="dist-01")
    sink.add("a-1", _tag_payload("a-1", ["red"]), None)
    sink.close()
    (tmp_path / "merged.jsonl").write_text(
        '{"image_id": "a-1"}\n{"image_id": "a-2"}\n', encoding="utf-8")
    (tmp_path / "failures.jsonl").write_text('{"image_id": "bad"}\n', encoding="utf-8")

    client = TestClient(app_mod.create_app(ui_dist=tmp_path / "no-ui"))
    res = client.get("/api/artifacts", params={"path": str(tmp_path)})
    assert res.status_code == 200
    rows = {f["name"]: f["rows"] for f in res.json()["files"]}
    assert rows == {"artifacts-dist-01.jsonl": 1, "merged.jsonl": 2}


def test_tag_manage_scans_and_merges_jsonl(tmp_path):
    """整理页只扫 *.json 的话，jsonl 用户看到的是"这个目录里没有 json"。"""
    sink = JsonlSink(tmp_path, rows_per_file=10)
    sink.add("a-1", _tag_payload("a-1", ["1girl", "solo"]),
             _nl_payload("a-1", "a girl alone"))
    sink.close()

    scanned = tm.scan(tmp_path)
    assert [r["kind"] for r in scanned] == ["jsonl"]

    out = tmp_path / "merged.json"
    report = tm.merge_files([str(scanned[0]["path"])], out)
    assert report.inputs == 1
    assert report.records_out == 1
    row = json.loads(out.read_text(encoding="utf-8"))[0]
    assert row["caption"] == "a girl alone" and row["tag"] == "1girl, solo"
