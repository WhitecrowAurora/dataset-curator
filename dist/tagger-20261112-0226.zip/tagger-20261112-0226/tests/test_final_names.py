"""最终表字段命名（规范 v0.2 §8 的 nl_final / tags_final 与历史 caption / tag）。"""

from __future__ import annotations

import json

import pytest

from tagger.merge import (Record, apply_final_names, build_rows, final_field,
                          write_merged)


def _recs() -> dict:
    return {
        "000001": Record(image_id="000001", caption="a girl sitting",
                         tag="1girl, sitting",
                         meta={"caption_language": "en"}),
        "000002": Record(image_id="000002", caption="", tag="1girl"),
    }


def _rows(tmp_path, mode):
    out, n = write_merged(_recs(), tmp_path / f"{mode}.jsonl",
                          final_names=mode, require="both")
    return [json.loads(line) for line in out.read_text("utf-8").splitlines()]


def test_默认两套名字都在(tmp_path):
    rows = _rows(tmp_path, "both")
    assert len(rows) == 1                     # 空 caption 的那条被 require=both 滤掉
    row = rows[0]
    assert row["caption"] == row["nl_final"] == "a girl sitting"
    assert row["tag"] == row["tags_final"] == "1girl, sitting"


def test_legacy模式不多写别名(tmp_path):
    row = _rows(tmp_path, "legacy")[0]
    assert "nl_final" not in row and "tags_final" not in row
    assert row["caption"] == "a girl sitting"


def test_v02模式只留文档字段名(tmp_path):
    row = _rows(tmp_path, "v02")[0]
    assert "caption" not in row and "tag" not in row
    assert row["nl_final"] == "a girl sitting"
    assert row["tags_final"] == "1girl, sitting"


def test_两种列名都能读回来():
    """读侧统一走 final_field：盘上是哪一套都不能被判成空。"""
    assert final_field({"caption": "x"}, "caption") == "x"
    assert final_field({"nl_final": "x"}, "caption") == "x"
    assert final_field({"tag": "a, b"}, "tag") == "a, b"
    assert final_field({"tags_final": "a, b"}, "tag") == "a, b"
    assert final_field({}, "caption") == ""


def test_非法命名直接报错(tmp_path):
    with pytest.raises(ValueError):
        write_merged(_recs(), tmp_path / "x.jsonl", final_names="v03")


def test_别名不影响溯源字段(tmp_path):
    row = _rows(tmp_path, "v02")[0]
    assert row["caption_language"] == "en"


def test_build_rows保持旧键名():
    """build_rows 是内层接口：别名只在写盘那一步加，避免两处各有一套。"""
    rows = list(build_rows(_recs()))
    assert all("caption" in r and "tag" in r for r in rows)
    assert all("nl_final" not in r for r in rows)
    assert apply_final_names(rows[0], "both")["nl_final"] == rows[0]["caption"]
