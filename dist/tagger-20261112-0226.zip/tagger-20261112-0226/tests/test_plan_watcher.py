"""计划任务：跑到 N 张后停任务/关机。只验"到点触发一次"与"不触发"。"""

from __future__ import annotations

import time

from tagger.web.plan import PlanWatcher


class _Job:
    def __init__(self, done: int = 0) -> None:
        self.done = done

    def snapshot(self) -> dict:
        return {"id": "j1", "counts": {"done": self.done, "total": 100}}


def _wait(seconds: float = 1.2) -> None:
    time.sleep(seconds)


def test_fires_once_when_threshold_reached():
    job = _Job(1)
    stopped: list[str] = []
    w = PlanWatcher(None, running_job=lambda: job,
                    stop_job=lambda i: stopped.append(i) or True,
                    interval=0.2, dry_run=True)
    try:
        w.configure(after_images=3, action="shutdown")
        job.done = 2
        _wait()
        assert stopped == [], "还没到阈值就动了"

        job.done = 5
        _wait()
        assert stopped == ["j1"]

        # 再跨过几次阈值也不能重复动作（否则会反复下关机指令）
        job.done = 8
        _wait()
        assert stopped == ["j1"]
    finally:
        w.close()


def test_disabled_plan_never_fires():
    job = _Job(0)
    stopped: list[str] = []
    w = PlanWatcher(None, running_job=lambda: job,
                    stop_job=lambda i: stopped.append(i) or True,
                    interval=0.2, dry_run=True)
    try:
        w.configure(after_images=1, action="stop", enabled=False)
        job.done = 99
        _wait()
        assert stopped == []
    finally:
        w.close()


def test_cancel_stops_future_firing():
    job = _Job(0)
    stopped: list[str] = []
    w = PlanWatcher(None, running_job=lambda: job,
                    stop_job=lambda i: stopped.append(i) or True,
                    interval=0.2, dry_run=True)
    try:
        w.configure(after_images=2, action="stop")
        w.cancel()
        job.done = 10
        _wait()
        assert stopped == []
    finally:
        w.close()


def test_dry_run_reports_without_shutdown():
    job = _Job(0)
    w = PlanWatcher(None, running_job=lambda: job,
                    stop_job=lambda i: True, interval=0.2, dry_run=True)
    try:
        w.configure(after_images=1, action="shutdown")
        job.done = 1
        _wait()
        snap = w.snapshot()
        assert snap["plan"]["fired"] is True
        assert "dry-run" in snap["plan"]["note"]
    finally:
        w.close()


def test_rejects_bad_parameters():
    w = PlanWatcher(None, running_job=lambda: None,
                    stop_job=lambda i: True, interval=5, dry_run=True)
    try:
        try:
            w.configure(after_images=0, action="stop")
        except ValueError:
            pass
        else:
            raise AssertionError("after_images=0 应该被拒绝")
        try:
            w.configure(after_images=1, action="reboot")
        except ValueError:
            pass
        else:
            raise AssertionError("未知动作应该被拒绝")
    finally:
        w.close()
