"""合并对账的守卫。

重点不是"能合并"，而是**能不能发现该发现的东西**：
整条缺失、整份没交、整包没交、内容冲突、幂等重跑。
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tagger.merge import (MergeStats, check, collect, coverage_by_shard,
                          load_shard_plans)


@pytest.mark.parametrize("fmt", ["json", "jsonl"])
@pytest.mark.parametrize("failure", ["rows", "fsync", "replace"])
def test_failed_export_preserves_previous_table(tmp_path, monkeypatch, fmt, failure):
    from tagger import merge

    out = tmp_path / f"merged.{fmt}"
    out.write_bytes(b"previous complete result\n")
    def rows(*args, **kwargs):
        yield {"caption": "one", "tag": "one"}
        if failure == "rows":
            raise OSError("interrupted export")
    def fail(*args):
        raise OSError("disk unavailable")
    monkeypatch.setattr(merge, "build_rows", rows)
    if failure == "fsync":
        monkeypatch.setattr(merge.os, "fsync", fail)
    elif failure == "replace":
        monkeypatch.setattr(Path, "replace", fail)
    with pytest.raises(OSError):
        merge.write_merged({}, out, fmt=fmt)
    assert out.read_bytes() == b"previous complete result\n"
    assert list(tmp_path.iterdir()) == [out]


def _plans():
    return [
        {"name": "dist-0000.zip", "first_id": "a-000001",
         "last_id": "a-000003", "count": 3},
        {"name": "dist-0001.zip", "first_id": "a-000004",
         "last_id": "a-000006", "count": 3},
    ]


# ------------------------------------------------------------------ 收集


def test_collect_merges_two_files_into_one_record(tmp_path, write_artifact):
    write_artifact(tmp_path, "a-000001", tag="red, square", caption="a red square")
    stats = MergeStats()
    records = collect([tmp_path], stats=stats)

    assert list(records) == ["a-000001"]
    rec = records["a-000001"]
    assert rec.tag == "red, square"
    assert rec.caption == "a red square"
    assert len(rec.src_files) == 2
    assert not stats.empty_roots


def test_collect_flags_conflicting_content(tmp_path, write_artifact):
    r1 = tmp_path / "member1"
    r2 = tmp_path / "member2"
    write_artifact(r1, "a-000001", tag="red", caption="one")
    write_artifact(r2, "a-000001", tag="blue", caption="two")

    stats = MergeStats()
    records = collect([r1, r2], stats=stats)
    # tag 与 nl 各自冲突，两侧各自的原始版本和冲突版本都必须可定位。
    assert "a-000001" in stats.duplicates
    assert set(stats.duplicates["a-000001"]) == {
        str(root / f"a-000001-{kind}.json")
        for root in (r1, r2) for kind in ("tag", "nl")
    }
    # 先到的那份留在 records 里，但流程会因 stats.failed 而中断
    assert records["a-000001"].tag == "red"


def test_collect_treats_identical_duplicates_as_idempotent(tmp_path, write_artifact):
    r1 = tmp_path / "member1"
    r2 = tmp_path / "member2"
    write_artifact(r1, "a-000001", tag="red", caption="same")
    write_artifact(r2, "a-000001", tag="red", caption="same")

    stats = MergeStats()
    collect([r1, r2], stats=stats)
    assert stats.idempotent_repeats
    assert not stats.duplicates
    assert not stats.failed


def test_collect_flags_empty_root(tmp_path):
    """整份没交：目录在、但一份产出都没有。它和"目录不存在"一样要报。"""
    empty = tmp_path / "empty_member"
    empty.mkdir()

    stats = MergeStats()
    collect([empty, tmp_path / "never_uploaded"], stats=stats)
    assert len(stats.empty_roots) == 2
    assert stats.failed


# ------------------------------------------------------------------ 逐条对账


def test_check_detects_missing_ids(tmp_path, write_artifact):
    write_artifact(tmp_path, "a-000001", tag="red", caption="x")
    stats = MergeStats()
    records = collect([tmp_path], stats=stats)
    check(records, expected_ids=["a-000001", "a-000002"], stats=stats)

    assert stats.expected == 2
    assert stats.missing_ids == ["a-000002"]
    assert stats.failed


def test_check_accepts_complete_batch(tmp_path, write_artifact):
    write_artifact(tmp_path, "a-000001", tag="red", caption="x")
    write_artifact(tmp_path, "a-000002", tag="blue", caption="y")
    records = collect([tmp_path])
    stats = check(records, expected_ids=["a-000001", "a-000002"], require="both")

    assert stats.complete == 2
    assert not stats.failed
    assert stats.by_artist["a"]["expected"] == 2


# ------------------------------------------------------------------ 逐包对账


def test_coverage_detects_whole_missing_shard(write_artifact, tmp_path):
    """一整包一条都没回来——10 个人里少 1 个，完整率仍有 50%，但必须阻断。"""
    write_artifact(tmp_path, "a-000004", tag="red", caption="x")
    write_artifact(tmp_path, "a-000005", tag="red", caption="x")
    write_artifact(tmp_path, "a-000006", tag="red", caption="x")

    records = collect([tmp_path])
    stats = MergeStats()
    rows = coverage_by_shard(records, _plans(), require="both", stats=stats)

    assert [r.name for r in rows] == ["dist-0000.zip", "dist-0001.zip"]
    assert rows[0].whole_missing is True
    assert rows[0].expected == 3 and rows[0].got == 0
    assert rows[1].got == 3 and rows[1].complete == 3
    assert [c.name for c in stats.whole_missing_shards] == ["dist-0000.zip"]
    assert stats.failed


def test_coverage_detects_partial_shard(write_artifact, tmp_path):
    write_artifact(tmp_path, "a-000001", tag="red", caption="x")
    write_artifact(tmp_path, "a-000002", tag="red", caption="x")
    # a-000003 没交
    records = collect([tmp_path])
    stats = MergeStats()
    coverage_by_shard(records, _plans()[:1], require="both", stats=stats)

    cov = stats.shard_coverage[0]
    assert cov.got == 2 and cov.short == 1
    assert not cov.whole_missing
    assert stats.short_shards == [cov]


def test_coverage_flags_ids_outside_table(write_artifact, tmp_path):
    write_artifact(tmp_path, "b-000099", tag="red", caption="x")
    records = collect([tmp_path])
    stats = MergeStats()
    coverage_by_shard(records, _plans(), require="both", stats=stats)
    assert stats.unassigned_ids == ["b-000099"]
    assert stats.failed


def test_check_with_plans_uses_table_total_as_expected(write_artifact, tmp_path):
    write_artifact(tmp_path, "a-000001", tag="red", caption="x")
    records = collect([tmp_path])
    stats = check(records, shard_plans=_plans(), require="both")
    # 没有逐条清单时，应产出取分发表合计，而不是"自己跟自己比"
    assert stats.expected == 6
    assert stats.shard_coverage


def test_provenance_missing_tag_payload_does_not_crash(tmp_path, write_artifact):
    """老产物/手改产物里 tag 那份没有 provenance。

    这曾经是一个 KeyError：tag_backend 维度直接去 rec.prov["tag"] 取。
    缺溯源只该降级成"(缺失)"告警，不该让整个 merge 崩掉。
    """
    from tagger.merge import collect_provenance

    write_artifact(tmp_path, "a-000001", tag="red", caption="x")
    records = collect([tmp_path])
    prov = collect_provenance(records, stats=MergeStats())
    assert prov["tag_backend"] == {"(缺失)": 1}
    assert prov["model_id"] == {"(缺失)": 1}


def test_load_shard_plans(tmp_path):
    path = tmp_path / "shards.json"
    path.write_text(json.dumps({
        "schema": 1,
        "shards": [{"shard": 0, "name": "dist-0000.zip", "first_id": "a-000001",
                    "last_id": "a-000003", "count": 3}],
        "total_count": 3,
    }), encoding="utf-8")
    plans = load_shard_plans(path)
    assert plans[0]["name"] == "dist-0000.zip"
    assert plans[0]["count"] == 3


def test_provenance_tracks_tag_precision(tmp_path):
    """精度必须能按成员对账。

    fp32 / tf32 / bf16 出的 tag 集合不一样（bf16 每 79 张约 2 个 tag 真改判），
    混批之后没有这一维就只能靠猜。tag_precision 只存在于 tag 产物，
    查它时不能去翻 NL 的那份 provenance，否则永远得到"(缺失)"。
    """
    import json

    from tagger.merge import collect_provenance, provenance_warnings

    def write(image_id, precision):
        payload = {
            "image_id": image_id,
            "tag": "1girl",
            "tags": [["1girl", 0.9]],
            "ok": True,
            "provenance": {"model_id": "m", "prompt_ver": "v1",
                           "tag_backend": "wd-eva02", "tag_precision": precision},
            "ts": 0.0,
        }
        (tmp_path / f"{image_id}-tag.json").write_text(
            json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    write("a-000001", "bf16")
    write("a-000002", "tf32")

    prov = collect_provenance(collect([tmp_path]), stats=MergeStats())
    assert prov["tag_precision"] == {"bf16": 1, "tf32": 1}
    assert prov["tag_backend"] == {"wd-eva02": 2}
    assert any("tag_precision" in m for m in provenance_warnings(prov))


def test_provenance_marks_missing_tag_precision(tmp_path, write_artifact):
    """老产物没有这一维：降级成"(缺失)"，不能崩、也不能算成"一致"。"""
    from tagger.merge import collect_provenance

    write_artifact(tmp_path, "a-000001", tag="red", caption="x")
    prov = collect_provenance(collect([tmp_path]), stats=MergeStats())
    assert prov["tag_precision"] == {"(缺失)": 1}
