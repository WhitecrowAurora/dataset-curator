"""并发链路：服务端批调度参数、客户端在途数、本机地址不吃代理。

30M 量级下这几条决定要跑几天而不是几小时，所以每条都要钉住：
不填并发时跟着服务端 max_num_seqs 走；单步 token 预算只在该给的时候
出现在命令行里；本机地址绝不经过系统代理（开着 Clash 时"服务起着却连不上"）。
"""

from __future__ import annotations

import pytest

from tagger.cli import _pick_concurrency
from tagger.client import resolve_concurrency
from tagger.config import load_tier_table, resolve_profile
from tagger.hardware import GPUInfo
from tagger.model_loader import build_command
from tagger.netutil import is_loopback_url, trust_env_for


def _gpu(vram: float = 16.0) -> GPUInfo:
    return GPUInfo(index=0, name="test", vram_gb=vram, compute_cap=(8, 9))


def _profile(**kw):
    return resolve_profile(load_tier_table("configs/tiers.yaml"), _gpu(), **kw)


# ------------------------------------------------------------------ 在途数


def test_explicit_concurrency_wins():
    assert resolve_concurrency(7, {"max_num_seqs": 16}) == 7
    # 0 / 负数都当 1：串行至少能跑
    assert resolve_concurrency(0, {}) == 1


def test_concurrency_follows_server_seqs_by_default():
    """默认跟着服务端 max_num_seqs：低于它服务端永远凑不满 batch。"""
    assert resolve_concurrency(None, {"max_num_seqs": 8}) == 8
    assert resolve_concurrency(None, {"max_num_seqs": 24}) == 24
    # 再高只是排队，吞吐不涨而客户端内存跟着涨
    assert resolve_concurrency(None, {"max_num_seqs": 128}) == 32


def test_concurrency_without_fingerprint_is_not_one():
    """指纹缺失时退回 4。退回 1 的表现是"能跑"但慢十倍，很难意识到。"""
    assert resolve_concurrency(None, {}) == 4
    assert resolve_concurrency(None, {"max_num_seqs": "bad"}) == 4


def test_fingerprint_separates_engine_and_its_concurrency_field():
    """指纹要分开记引擎与各自的服务端并发，否则客户端只有一个数可看。

    max_num_seqs 在 llama.cpp 分支根本没进命令（那是分档表的数），
    唯一有效的并发是 slots=-np。两个都记下来，取哪个由 engine 决定。
    """
    from tagger.model_loader import ServerHandle, fingerprint_env

    p = _profile()
    vllm_fp = fingerprint_env(
        ServerHandle(process=None, base_url="http://127.0.0.1:8000",
                     port=8000, profile=p, engine="vllm"))
    assert vllm_fp["engine"] == "vllm"
    assert vllm_fp["slots"] is None          # vLLM 没有槽位这回事

    nl_fp = fingerprint_env(
        ServerHandle(process=None, base_url="http://127.0.0.1:8000",
                     port=8000, profile=p, engine="llamacpp", slots=12))
    assert (nl_fp["engine"], nl_fp["slots"]) == ("llamacpp", 12)
    # 端到端：llama.cpp 的指纹 → 在途数取槽位，不取 max_num_seqs
    assert resolve_concurrency(None, nl_fp) == 12


# ------------------------------------------------------------------ 服务端参数

def test_batched_tokens_only_when_set():
    """0 = 不传参数，让 vLLM 用默认；不能传一个 0 进去。"""
    base = build_command(_profile())
    assert "--max-num-batched-tokens" not in base

    cmd = build_command(_profile(max_num_batched_tokens_override=32768))
    idx = cmd.index("--max-num-batched-tokens")
    assert cmd[idx + 1] == "32768"


def test_profile_overrides_reach_command_line():
    p = _profile(max_num_seqs_override=32, gpu_mem_override=0.92)
    cmd = build_command(p)
    assert cmd[cmd.index("--max-num-seqs") + 1] == "32"
    assert cmd[cmd.index("--gpu-memory-utilization") + 1] == "0.92"


def test_profile_defaults_come_from_tier():
    """不覆盖时必须回到分档表的值，别被覆盖逻辑顺手改成常量。"""
    table = load_tier_table("configs/tiers.yaml")
    tier = next(t for t in table["tiers"] if t["name"] == "low-16g")
    p = _profile(tier_override="low-16g")
    assert p.max_num_seqs == int(tier["max_num_seqs"])
    assert p.max_num_batched_tokens == int(tier.get("max_num_batched_tokens", 0))


# ------------------------------------------------------------------ 代理

@pytest.mark.parametrize("url", [
    "http://127.0.0.1:8000",
    "http://localhost:8000/v1",
    "http://[::1]:8000",
    "https://LOCALHOST:1234/health",
])
def test_loopback_addresses_bypass_proxy(url):
    """打标机常开代理，它的规则未必放过本机：base64 图片多绕一圈就砍半。"""
    assert is_loopback_url(url) is True
    assert trust_env_for(url) is False


@pytest.mark.parametrize("url", [
    "http://192.168.1.10:8000",
    "http://gpu-box:8000",
    "https://hf-mirror.example.com",
    "",
])
def test_remote_addresses_keep_default_proxy_behaviour(url):
    assert is_loopback_url(url) is False
    assert trust_env_for(url) is True


# ------------------------------------------------------------------ 选并发

def test_bench_picks_smallest_level_near_peak():
    """差不到 10% 时选小的：峰值往往是"刚好塞满"，连跑几天会掉到线下。"""
    rows = [(1, 1.0, 100, 1, 1, 0),
            (2, 2.0, 200, 1, 1, 0),
            (4, 2.9, 300, 2, 3, 0),
            (8, 3.0, 300, 4, 8, 0),
            (16, 2.8, 250, 9, 20, 2)]
    best, pick = _pick_concurrency(rows)
    assert best[0] == 8
    assert pick[0] == 4


def test_bench_pick_keeps_peak_when_nothing_is_close():
    rows = [(1, 1.0, 100, 1, 1, 0), (2, 3.0, 300, 1, 2, 0)]
    best, pick = _pick_concurrency(rows)
    assert best is pick and pick[0] == 2


# ------------------------------------------------------------------ bench 命令

def test_bench_reports_all_failure_instead_of_zero_throughput(tmp_path, monkeypatch):
    """全失败时不能输出"最高点 0 img/s"——那会让人以为测了但机器慢，
    而实际是连不上 / 模型名错。返回码也要非 0。"""
    from tagger import cli as cli_mod

    img = tmp_path / "a.jpg"
    img.write_bytes(b"x")

    def fake_load(*_a, **_kw):
        return [([img, "[ERROR] ConnectError: refused", 0, 0.01])], 0.01

    monkeypatch.setattr(cli_mod, "_load_test", fake_load)
    args = cli_mod.build_parser().parse_args(
        ["bench", "--images", str(img), "--concurrency", "1,2"])
    assert cli_mod.cmd_bench(args) == 1


def test_bench_throughput_and_percentiles(monkeypatch, tmp_path):
    """正常路径：img/s 与 p95 来自实测，建议并发取自梯度。"""
    from tagger import cli as cli_mod

    img = tmp_path / "a.jpg"
    img.write_bytes(b"x")
    calls = {"n": 0}

    def fake_load(*_a, concurrency=1, **_kw):
        calls["n"] += 1
        # 并发 4 时吞吐最高；并发 8 掉回一半
        rate = {1: 1.0, 2: 2.0, 4: 4.0, 8: 2.0}[concurrency]
        n = 4
        return [(img, "ok", 100, 1.0 / rate)] * n, n / rate

    monkeypatch.setattr(cli_mod, "_load_test", fake_load)
    args = cli_mod.build_parser().parse_args(
        ["bench", "--images", str(img), "--concurrency", "1,2,4,8",
         "--images-total", "1000000"])
    assert cli_mod.cmd_bench(args) == 0
    assert calls["n"] == 4
