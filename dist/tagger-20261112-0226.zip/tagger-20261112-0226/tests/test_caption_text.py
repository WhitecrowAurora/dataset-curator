"""caption 入库前的清洗：去重引文、砍末尾复述、删"没有文字"的交代句。

这三步都是确定性字符串操作。之所以放在代码里而不是只靠 prompt：实测在
规则里写"不要重复引用""没有文字就不要提"，模型要么反着来，要么只对一半
（中文 1/3 仍会补一句），只有后处理能保证 0。
"""

from __future__ import annotations

from tagger.caption_text import (dedupe_quotes, drop_no_text_note,
                                 drop_restatement, est_caption_tokens,
                                 fit_token_budget, tidy_caption)


# ------------------------------------------------------------ 引文去重

def test_重复引用只留第一次的引号():
    src = '牌子写着"A"，另一块写着"A"，还有"A"。'
    out = dedupe_quotes(src)
    assert out.count('"A"') == 1
    # 文字本身要留着：重复那句常带位置信息，删了会丢内容。
    assert out.count("A") == 3


def test_不同引文都保留():
    src = '左边"甲"，右边"乙"。'
    assert dedupe_quotes(src) == src


# ------------------------------------------------------------ 复述段

def test_砍掉末尾复述段():
    # 正文必须够长，复述标志才会落在后 1/3：真实 caption 都是这样。
    src = ("白盘里堆着深褐色肉干条，表面撒满橙红色辣椒碎，堆叠成小山状。"
           "背景为浅米色，四周有淡紫色猪、牛、苹果的简笔剪影。"
           "画面从斜上方俯视拍摄，近大远小透视明显。"
           "整体为摄影风格，线条清晰，完成度高。"
           "画面中可见文字：风干肉（麻辣味）为红色印刷体。")
    out = drop_restatement(src)
    assert "画面中可见文字" not in out
    assert "白盘里堆着深褐色肉干条" in out


def test_复述标志在开头时不砍():
    """整段就在讲招牌时，"可见文字"是正文的一部分，从中间砍等于毁掉正文。"""
    src = "画面中可见文字：欢迎光临。字体为红色。" + "背景是木质墙面。" * 10
    assert drop_restatement(src) == src


def test_可见文字单独收尾不砍():
    src = "一只猫坐在窗台上。" + "阳光很好。" * 5 + "画面中可见文字"
    assert drop_restatement(src) == src


# ------------------------------------------------------------ 无文字交代句

def test_删掉英文的无文字交代():
    src = ("A wooden bowl of jerky sits on a plain background. "
           "The lighting is soft and even. No visible text is present.")
    out = drop_no_text_note(src)
    assert "No visible text" not in out
    assert "The lighting is soft and even." in out


def test_删掉中文的无文字交代():
    src = "一个木碗装着肉干，背景为浅米色。画面中无可见文字。"
    out = drop_no_text_note(src)
    assert "无可见文字" not in out
    assert "木碗装着肉干" in out


def test_各种英文变体都能删():
    for tail in ("No text appears in the image.",
                 "There is no visible text.",
                 "The image contains no readable text.",
                 "The packaging is shown without any text."):
        out = drop_no_text_note("A red bag on a white table. " + tail)
        assert "text" not in out.lower(), tail


def test_带引号的句子不动():
    """讲别的对象的句子不能因为含"文字"就删。"""
    src = '招牌上没有文字，只有"福"字图案。'
    assert drop_no_text_note(src) == src


def test_整段都在说无文字时不删空():
    """删空会被质检判成"没有产出 caption"，比留一句废话更糟。"""
    src = "No visible text is present."
    assert drop_no_text_note(src) == src


def test_空串原样返回():
    assert drop_no_text_note("") == ""
    assert tidy_caption("") == ""


# ------------------------------------------------------------ infra token 保险

def test_估算英文按_5点4_字符每token():
    text = "A" * 540                       # 全 ASCII
    assert est_caption_tokens(text) == 100


def test_估算中文按_1点4_字符每token():
    text = "画面" * 70                     # 140 个汉字
    assert 95 <= est_caption_tokens(text) <= 105


def test_没超预算就原样返回():
    text = "A red bag on a white table."
    assert fit_token_budget(text, 512) == text


def test_超预算按句砍到线下():
    # 每句 23 个汉字 ≈ 16 token；40 句 ≈ 660 token，超过 512 的 92%（471）。
    sentence = "这是一句用来测试长度限制的画面描述文字内容很简单。"
    text = sentence * 40
    out = fit_token_budget(text, 512)
    assert est_caption_tokens(out) <= int(512 * 0.92)
    assert out != text
    # 砍在句边界上，不留半句。
    assert out.endswith("。")


def test_第一句就超预算时硬切():
    out = fit_token_budget("长" * 1200, 512)
    assert est_caption_tokens(out) <= int(512 * 0.92)
    assert len(out) < 1200


def test_limit为0表示关闭():
    text = "长" * 1200
    assert fit_token_budget(text, 0) == text


def test_tidy_会应用token上限():
    sentence = "这是一句用来测试长度限制的画面描述文字内容很简单。"
    text = sentence * 40
    out = tidy_caption(text, token_limit=512)
    assert est_caption_tokens(out) < est_caption_tokens(text)
    # 不传 limit 时不砍（默认关闭）。
    assert tidy_caption(text) == text


# ------------------------------------------------------------ 总入口

def test_tidy_串起三步():
    src = ('一只浅色木碗放在米白色台面上，碗里堆着深褐色肉干条。'
           '背景为纯色，光线均匀柔和，画面从正上方俯视拍摄。'
           '整体为摄影风格，完成度高。'
           '画面中可见文字："A"为红色印刷体，另一处"A"也是红色。')
    out = tidy_caption(src)
    assert "画面中可见文字" not in out          # 复述段被砍
    assert out.count('"A"') <= 1               # 重复引号只留一次
    assert "木碗放在米白色台面上" in out
