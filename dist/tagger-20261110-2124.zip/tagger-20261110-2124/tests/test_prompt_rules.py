"""规则文件（`prompts/*.md`）的解析、按 mode 取用与注入。"""

from __future__ import annotations

import textwrap

import pytest

from tagger import prompt_rules
from tagger.client import _prompt_for
from tagger.config import OutputSpec
from tagger.prompt_rules import load_rules, rules_for


MD = textwrap.dedent("""\
    # 说明

    - `## TAG` 是 tag 规则

    ## TAG
    - 一条 tag 规则

    ## CAPTION
    - one caption rule

    ## CAPTION_ZH
    - 一条中文 caption 规则

    ## TEXT
    - one text rule

    ## TEXT_ZH
    - 一条中文文字规则

    ## 其他
    - 不应被收进来
    """)


@pytest.fixture()
def rules_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(prompt_rules, "RULES_DIR", tmp_path)
    return tmp_path


def test_解析出五种节(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    rs = load_rules()
    assert set(rs.sections) == {"TAG", "CAPTION", "CAPTION_ZH", "TEXT", "TEXT_ZH"}


def test_带出标题行(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    rs = load_rules()
    assert rs.get("TAG").startswith("<TAGS> rules:")
    assert rs.get("CAPTION").startswith("<CAPTION> rules:")
    assert rs.get("CAPTION_ZH").startswith("<CAPTION> 规则：")


def test_TEXT节不带标题(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    assert load_rules().get("TEXT") == "- one text rule"


def test_未知小节不串进来(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    rs = load_rules()
    assert all("不应被收进来" not in v for v in rs.sections.values())


def test_折行并到上一条(rules_dir):
    (rules_dir / "t.md").write_text(
        "## TEXT\n- a long rule\nthat continues\n", encoding="utf-8")
    assert load_rules().get("TEXT") == "- a long rule that continues"


def test_多文件按名字合并(rules_dir):
    (rules_dir / "a.md").write_text("## TAG\n- a\n", encoding="utf-8")
    (rules_dir / "b.md").write_text("## TEXT\n- b\n", encoding="utf-8")
    rs = load_rules()
    assert rs.get("TAG") == "<TAGS> rules:\n- a"
    assert rs.get("TEXT") == "- b"


def test_同名节取第一份(rules_dir):
    (rules_dir / "a.md").write_text("## TEXT\n- first\n", encoding="utf-8")
    (rules_dir / "b.md").write_text("## TEXT\n- second\n", encoding="utf-8")
    assert load_rules().get("TEXT") == "- first"


def test_空目录不报错(rules_dir):
    assert not load_rules().used_any
    assert not rules_for("both", zh=False, text_rules=True)[0]


def test_只有标题的节被丢掉(rules_dir):
    (rules_dir / "t.md").write_text("## TAG\n\n## CAPTION\n- x\n", encoding="utf-8")
    rs = load_rules()
    assert "TAG" not in rs.sections
    assert "CAPTION" in rs.sections


# ---------------------------------------------------------------- 按 mode 取用

def test_tag模式强制带tag规则(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    tag, cap, text = rules_for("tag", zh=False, text_rules=True)
    assert tag and not cap and not text


def test_nl模式强制带caption规则(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    tag, cap, text = rules_for("nl", zh=False, text_rules=True)
    assert not tag and cap and text


def test_both模式两套都带(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    tag, cap, text = rules_for("both", zh=False, text_rules=True)
    assert tag and cap and text


def test_中文取中文节(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    _, cap, text = rules_for("nl", zh=True, text_rules=True)
    assert "中文 caption" in cap
    assert "中文文字" in text


def test_关掉text_rules就不追加(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    _, cap, text = rules_for("nl", zh=False, text_rules=False)
    assert cap and not text


# ---------------------------------------------------------------- 注入 prompt

def test_prompt用文件里的规则(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    p = _prompt_for(OutputSpec(mode="both", text_rules="x"))
    assert "一条 tag 规则" in p
    assert "one caption rule" in p
    assert "one text rule" in p


def test_文件缺节时退回内置(rules_dir):
    (rules_dir / "t.md").write_text("## TEXT\n- only text\n", encoding="utf-8")
    p = _prompt_for(OutputSpec(mode="both", text_rules="x"))
    assert "<TAGS> rules:" in p
    assert "danbooru style" in p          # 内置 tag 规则的标志性内容


def test_占位符被填充(rules_dir):
    (rules_dir / "t.md").write_text(
        "## TAG\n- {lo} to {hi} tags\n## CAPTION\n- {char_lo}-{char_hi}\n",
        encoding="utf-8")
    p = _prompt_for(OutputSpec(mode="both", text_rules=""))
    assert "{lo}" not in p and "{char_lo}" not in p


def test_tag模式不出现caption规则(rules_dir):
    (rules_dir / "t.md").write_text(MD, encoding="utf-8")
    p = _prompt_for(OutputSpec(mode="tag", text_rules="x"))
    assert "<TAGS> rules:" in p
    assert "<CAPTION> rules:" not in p
    assert "one text rule" not in p
