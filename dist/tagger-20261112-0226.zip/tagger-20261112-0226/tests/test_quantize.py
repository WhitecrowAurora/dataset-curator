"""页内 W4A16 量化：状态机、目录守卫、覆盖清单落盘。

量化本身要几十分钟和一张 GPU，测试里不可能真跑；所以这里钉的是**外围**：
进度行怎么解析、取消怎么收尾、产物路径写去哪里、越界目录怎么拦。
这几处出错的表现都很隐蔽——量化"跑完了"，服务却还在用 bf16。
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from tagger import quantize as qz
from tagger.quantize import QuantManager


class _FakeProc:
    """替身：stdout 逐行吐，退出码可控。"""

    def __init__(self, lines: list[str], code: int = 0):
        self.stdout = iter(lines)
        self._code = code
        self.pid = 4242
        self.terminated = False

    def wait(self, timeout: float | None = None) -> int:
        return self._code

    def poll(self) -> int:
        return self._code

    def terminate(self) -> None:
        self.terminated = True


def _patch_env(monkeypatch, tmp_path: Path, *, code: int = 0,
               lines: list[str] | None = None) -> Path:
    """把模型根、分档表、子进程全部替换成临时世界。"""
    models_root = tmp_path / "models"
    models_root.mkdir(parents=True, exist_ok=True)
    # 源权重也放在 models/ 内：真实场景里 bf16 权重就是下到 models/nl/<key> 的，
    # 这样"输出目录不能是源目录"那条守卫才测得到。
    src = models_root / "src"
    src.mkdir(parents=True, exist_ok=True)
    overlay = tmp_path / "models.json"

    table = {"models": {"qwen3vl-4b": {
        "path": str(src), "revision": None, "family": "qwen3vl",
        "precision": "int4", "quantized_path": None,
    }}}
    monkeypatch.setattr(qz, "MODELS_ROOT", models_root)
    # ROOT 跟着挪，才能测到"覆盖清单里写相对路径"这条（真实部署里
    # models/ 就在仓库根下，Windows 与 WSL 用同一份清单）。
    monkeypatch.setattr(qz, "ROOT", tmp_path)
    monkeypatch.setattr(qz, "load_tier_table", lambda *a, **kw: table)
    monkeypatch.setattr(qz, "overlay_path", lambda: overlay)
    monkeypatch.setattr(qz.platform, "system", lambda: "Linux")
    monkeypatch.setattr(qz, "_module_ready", lambda _name: True)
    # 量化能力要查显卡；测试机可能没卡，统一假装有。
    monkeypatch.setattr("tagger.hardware.query_gpus", lambda: [object()])
    payload = lines if lines is not None else [
        "@@PROGRESS 15 加载 bf16 权重\n",
        "一些普通日志\n",
        "@@PROGRESS 92 保存 tokenizer\n",
        "@@PROGRESS 100 完成\n",
    ]
    monkeypatch.setattr(qz.subprocess, "Popen",
                        lambda *a, **kw: _FakeProc(payload, code))
    return overlay


def _wait_done(svc: QuantManager, timeout: float = 3.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        task = svc._task
        if task is not None and task.status != "running":
            return task
        time.sleep(0.01)
    raise AssertionError("量化任务没有在超时内结束")


# ------------------------------------------------------------------ 进度与产物


def test_progress_lines_are_parsed_and_logs_kept(monkeypatch, tmp_path):
    _patch_env(monkeypatch, tmp_path)
    svc = QuantManager()
    svc.start(model_key="qwen3vl-4b", method="gptq")
    task = _wait_done(svc)

    assert task.status == "done"
    assert task.percent == 100.0
    assert task.stage == "完成"
    # 普通输出进日志，@@PROGRESS 不进（否则页面上会刷一堆协议行）
    assert "一些普通日志" in list(task.log)
    assert all("@@PROGRESS" not in line for line in task.log)


def test_done_writes_quantized_path_into_overlay(monkeypatch, tmp_path):
    """量化完必须登记，否则下次启动还是加载 bf16——白跑几十分钟。"""
    overlay = _patch_env(monkeypatch, tmp_path)
    svc = QuantManager()
    svc.start(model_key="qwen3vl-4b", method="gptq")
    _wait_done(svc)

    doc = json.loads(overlay.read_text(encoding="utf-8"))
    entry = doc["vlm"]["qwen3vl-4b"]
    # 相对仓库根：同一份清单在 Windows 与 WSL(/mnt) 下都能解析
    assert entry["quantized_path"] == "models/nl/qwen3vl-4b-w4a16"
    # 覆盖条目是整体替换，path 必须在，否则 apply_model_overlay 会直接忽略它
    assert entry["path"] == str(tmp_path / "models" / "src")
    assert entry["precision"] == "gptq"


def test_nonzero_exit_is_error_and_keeps_overlay_untouched(monkeypatch, tmp_path):
    overlay = _patch_env(monkeypatch, tmp_path, code=1,
                         lines=["boom\n"])
    svc = QuantManager()
    svc.start(model_key="qwen3vl-4b", method="gptq")
    task = _wait_done(svc)

    assert task.status == "error"
    assert "code=1" in task.message
    assert not overlay.exists()


# ------------------------------------------------------------------ 守卫


def test_output_dir_must_stay_inside_models(monkeypatch, tmp_path):
    _patch_env(monkeypatch, tmp_path)
    svc = QuantManager()
    with pytest.raises(ValueError, match="不在模型目录"):
        svc.start(model_key="qwen3vl-4b", out_dir=str(tmp_path / "elsewhere"))


def test_output_dir_cannot_overwrite_source(monkeypatch, tmp_path):
    _patch_env(monkeypatch, tmp_path)
    svc = QuantManager()
    with pytest.raises(ValueError, match="原始权重目录"):
        svc.start(model_key="qwen3vl-4b", out_dir=str(tmp_path / "models" / "src"))


def test_unknown_method_rejected(monkeypatch, tmp_path):
    _patch_env(monkeypatch, tmp_path)
    with pytest.raises(ValueError, match="未知量化方法"):
        QuantManager().start(model_key="qwen3vl-4b", method="int2")


def test_start_while_running_returns_the_same_task(monkeypatch, tmp_path):
    """单卡上两份量化必有一份 OOM：重复点开始只能看同一个任务。"""
    _patch_env(monkeypatch, tmp_path)
    svc = QuantManager()
    running = qz.QuantTask(
        model_key="qwen3vl-4b", source=str(tmp_path / "models" / "src"),
        out_dir=tmp_path / "models" / "nl" / "qwen3vl-4b-w4a16", method="gptq")
    svc._task = running

    out = svc.start(model_key="qwen3vl-4b")
    assert out["status"] == "running"
    assert svc._task is running


# ------------------------------------------------------------------ 能力与清单


def test_capability_names_the_missing_package(monkeypatch):
    monkeypatch.setattr(qz.platform, "system", lambda: "Linux")
    monkeypatch.setattr(qz, "_module_ready", lambda name: name != "llmcompressor")
    ok, reason = QuantManager().capability()
    assert ok is False
    assert "llmcompressor" in reason
    assert "tagger[quantize]" in reason


def test_capability_allows_windows_with_gpu(monkeypatch):
    """量化是纯 torch 的活，Windows 原生能跑。

    vLLM 只能跑 Linux/WSL2 是**另一回事**：产物是普通目录，WSL 走 /mnt
    或拷到远端都能加载，不该因此把 Windows 上的量化按钮禁掉。
    """
    monkeypatch.setattr(qz.platform, "system", lambda: "Windows")
    monkeypatch.setattr(qz, "_module_ready", lambda _name: True)
    monkeypatch.setattr("tagger.hardware.query_gpus", lambda: [object()])
    ok, reason = QuantManager().capability()
    assert ok is True
    assert reason == ""


def test_capability_requires_a_gpu(monkeypatch):
    monkeypatch.setattr(qz, "_module_ready", lambda _name: True)
    monkeypatch.setattr("tagger.hardware.query_gpus", lambda: [])
    ok, reason = QuantManager().capability()
    assert ok is False
    assert "NVIDIA" in reason


def test_snapshot_reports_existing_quantized_weights(monkeypatch, tmp_path):
    _patch_env(monkeypatch, tmp_path)
    out = tmp_path / "models" / "nl" / "qwen3vl-4b-w4a16"
    out.mkdir(parents=True)
    monkeypatch.setattr(qz, "load_tier_table", lambda *a, **kw: {"models": {
        "qwen3vl-4b": {"path": str(tmp_path / "src"), "revision": None,
                       "family": "qwen3vl", "precision": "gptq",
                       "quantized_path": str(out)}}})

    svc = QuantManager()
    snap = svc.snapshot("qwen3vl-4b")
    assert snap["model"] == "qwen3vl-4b"
    assert snap["has_quantized"] is True
    assert snap["quantized_path"] == str(out)
    assert snap["suggested_dir"].endswith("qwen3vl-4b-w4a16")


def test_snapshot_without_weights_suggests_a_dir(monkeypatch, tmp_path):
    _patch_env(monkeypatch, tmp_path)
    snap = QuantManager().snapshot("qwen3vl-4b")
    assert snap["has_quantized"] is False
    assert snap["suggested_dir"].endswith("qwen3vl-4b-w4a16")
