"""pipeline 是"输入 → 打标 → 封包"的接线层，也是最容易静默毁数据的一层。

这里守四件事：
  1. zip 成员必须能当输入（4TB 级素材的常见形态），且命名不能带 `::`
  2. flat 布局的 id 必须是全局序号，画师名取自包内路径而不是包名
  3. mirror 布局下不同 zip 的同名成员不能互相覆盖
  4. 封包参数一变就要重新封，不能拿旧的 .packstate 冒充已完成
"""

from __future__ import annotations

import io
import json
import zipfile

import pytest

from PIL import Image

from tagger.artist import ArtistRule
from tagger.local_tag import TagItem, artifact_path
from tagger.pack import PackOptions
from tagger.pipeline import (MemberReader, PackSpaceError, estimate_item_bytes,
                            estimate_pack_bytes, pack_fingerprint, pack_items,
                            plan_inputs, plan_stats, required_pack_bytes)


def _png(color=(20, 40, 60), size=(8, 8)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, "PNG")
    return buf.getvalue()


def _write_artifacts(out, items, *, tag="red, square"):
    for it in items:
        p = artifact_path(out, it)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({
            "image_id": it.image_id, "ok": True, "tag": tag,
            "tags": [[t, 0.9] for t in tag.split(",")],
            "provenance": {"mode": "test"},
        }, ensure_ascii=False), encoding="utf-8")


# ------------------------------------------------------------------ 发现与命名


def test_discover_accepts_single_zip_file(tmp_path, make_zip, make_png):
    """素材是一个 4TB 的包时，用户不该先解压再指目录。"""
    zp = make_zip(tmp_path / "big.zip", {
        "artist_a/001.png": make_png(),
        "artist_a/002.png": make_png(),
    })
    plan = plan_inputs(zp, artist_rule=ArtistRule(enabled=True))
    assert len(plan.items) == 2
    assert {it.artist for it in plan.items} == {"artist_a"}
    # 包内路径取画师名，不能取成包名
    assert all("big" not in it.artist for it in plan.items)


def test_flat_ids_are_global_and_artist_prefixed(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "s1.zip", {
        "alice/0001.png": make_png(),
        "alice/0002.png": make_png(),
        "bob/0001.png": make_png(),
    })
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=True))
    ids = [it.image_id for it in plan.items]
    assert ids == ["alice-000001", "alice-000002", "bob-000003"]
    names = [it.out_name for it in plan.items]
    # 扩展名跟着实际字节走（这里源是 PNG，封包时才转 .jpg），但 id 前缀必须对
    assert names[0].startswith("alice-000001.")


def test_flat_ids_without_artist_are_plain_numbers(tmp_path, make_png):
    (tmp_path / "a.png").write_bytes(make_png())
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=False))
    assert plan.items[0].image_id == "000001"


def test_zip_members_do_not_leak_separator_into_names(tmp_path, make_zip, make_png):
    """zip 成员的相对路径形如 `s.zip::a/1.png`；`::` 在 Windows 文件名里非法。"""
    make_zip(tmp_path / "s.zip", {"a/1.png": make_png()})
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=False))
    name = plan.items[0].out_name
    assert "::" not in name and ":" not in name


def test_mirror_keeps_structure_and_avoids_cross_zip_collision(tmp_path, make_zip,
                                                               make_png):
    """两个包里都有 `x/1.png`：mirror 结构原样保留，但撞名时不能让两条覆盖。

    包名不进路径（素材包内部结构已经是干净的），冲突时追加 id 保命。
    """
    make_zip(tmp_path / "s1.zip", {"x/1.png": make_png()})
    make_zip(tmp_path / "s2.zip", {"x/1.png": make_png()})
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=False),
                       layout="mirror")
    names = [it.out_name for it in plan.items]
    assert len(names) == 2
    assert names[0] != names[1]
    # 层级来自包内路径，不再多一层包名
    assert all(n.startswith("x/") for n in names)


def test_seq_width_overflow_is_rejected(tmp_path, make_png):
    from tagger.config import ConfigError
    import pytest

    for i in range(11):
        (tmp_path / f"{i}.png").write_bytes(make_png())
    with pytest.raises(ConfigError):
        plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=False), seq_width=1)


def test_plan_stats_reports_sources_and_samples(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "s1.zip", {"alice/1.png": make_png(), "alice/2.png": make_png()})
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=True))
    stats = plan_stats(plan)
    assert stats["total"] == 2
    assert stats["sources"][0]["count"] == 2
    assert stats["artists"]["count"] == 1
    assert len(stats["samples"]) == 2
    assert stats["samples"][0]["name"].startswith("alice-")


# ------------------------------------------------------------------ 读取


def test_member_reader_reads_loose_and_zip(tmp_path, make_zip, make_png):
    loose = tmp_path / "a.png"
    loose.write_bytes(make_png())
    make_zip(tmp_path / "s.zip", {"a/b.png": make_png()})
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=False))
    by_kind = {}
    for it in plan.items:
        by_kind["zip" if it.in_zip else "loose"] = it
    with MemberReader() as reader:
        assert reader.read(by_kind["loose"]) == make_png()
        assert reader.read(by_kind["zip"])[:4] == b"\x89PNG"


def test_tag_item_read_bytes_works_without_pool(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "s.zip", {"a/b.png": make_png()})
    plan = plan_inputs(tmp_path, artist_rule=ArtistRule(enabled=False))
    item = plan.items[0]
    assert isinstance(item, TagItem)
    assert item.read_bytes()[:4] == b"\x89PNG"


# ------------------------------------------------------------------ 封包


def test_pack_writes_all_three_formats(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "src.zip", {
        "alice/1.png": make_png(),
        "alice/2.png": make_png(),
        "bob/1.png": make_png(),
    })
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=True))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)

    opts = PackOptions(formats=("parquet", "webdataset", "zip"), max_records=10)
    report = pack_items(plan.items, out, opts, layout="flat", workers=2)

    assert report.packed == 3 and report.failed == 0
    names = {p.name for p in out.iterdir()}
    assert any(n.endswith(".parquet") for n in names)
    assert any(n.endswith(".tar") for n in names)
    assert any(n.endswith(".zip") for n in names)

    with zipfile.ZipFile(next(out.glob("*.zip"))) as zf:
        members = zf.namelist()
        assert "alice-000001.jpg" in members
        assert any(m.endswith(".tag") for m in members)
        meta = json.loads(zf.read("alice-000001.json"))
    assert meta["artist"] == "alice"
    assert meta["artist_tag"] == "@alice"


def test_pack_skips_on_second_run_and_repacks_when_params_change(
        tmp_path, make_zip, make_png):
    """断点记忆必须按参数指纹分文件：改了质量还得重封，不能假装做完。"""
    make_zip(tmp_path / "src.zip", {"a/1.png": make_png(), "a/2.png": make_png()})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=False))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)

    opts = PackOptions(formats=("zip",), max_records=10)
    first = pack_items(plan.items, out, opts, layout="flat", workers=1)
    assert first.packed == 2 and first.skipped_done == 0

    again = pack_items(plan.items, out, opts, layout="flat", workers=1)
    assert again.packed == 0 and again.skipped_done == 2

    changed = PackOptions(formats=("zip",), max_records=10, jpeg_quality=92)
    assert pack_fingerprint(changed, "flat") != pack_fingerprint(opts, "flat")
    third = pack_items(plan.items, out, changed, layout="flat", workers=1)
    assert third.packed == 2 and third.skipped_done == 0


def test_pack_repacks_when_naming_changes(tmp_path, make_zip, make_png):
    """改名口径（seq_width/画师开关）一变，旧记忆不能当成"这批也封过"。

    否则同一张图会以旧 id 和新 id 各进一次包，训练集里凭空多出一份重复。
    """
    make_zip(tmp_path / "src.zip", {"a/1.png": make_png()})
    out = tmp_path / "out"
    opts = PackOptions(formats=("zip",))
    plan1 = plan_inputs(tmp_path / "src.zip", seq_width=6,
                        artist_rule=ArtistRule(enabled=False))
    _write_artifacts(out, plan1.items)
    assert pack_items(plan1.items, out, opts, layout="flat", workers=1,
                      naming={"seq_width": 6}).packed == 1

    plan2 = plan_inputs(tmp_path / "src.zip", seq_width=4,
                        artist_rule=ArtistRule(enabled=False))
    _write_artifacts(out, plan2.items)
    assert plan2.items[0].image_id != plan1.items[0].image_id
    report = pack_items(plan2.items, out, opts, layout="flat", workers=1,
                        naming={"seq_width": 4})
    assert report.packed == 1 and report.skipped_done == 0


def test_pack_skips_entries_without_artifact(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "src.zip", {"a/1.png": make_png(), "a/2.png": make_png()})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=False))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items[:1])          # 只给第一张产物

    report = pack_items(plan.items, out, PackOptions(formats=("zip",)),
                        layout="flat", workers=1)
    assert report.packed == 1
    assert report.skipped_missing == 1


def test_pack_reports_bad_image_as_failed(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "src.zip", {
        "a/1.png": make_png(),
        "a/broken.png": b"not an image at all",
    })
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=False))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)

    report = pack_items(plan.items, out, PackOptions(formats=("zip",)),
                        layout="flat", workers=1)
    assert report.packed == 1
    assert report.failed == 1


def test_pack_mirror_layout_writes_nested_members(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "src.zip", {"alice/1.png": make_png()})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=True),
                       layout="mirror")
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)

    pack_items(plan.items, out, PackOptions(formats=("zip",)),
               layout="mirror", workers=1)
    with zipfile.ZipFile(next(out.glob("*.zip"))) as zf:
        members = [m for m in zf.namelist() if m.endswith(".jpg")]
    # 层级来自包内路径，不再多套一层包名（包内结构本来就是干净的）
    assert members == ["alice/1.jpg"]


def test_pack_stop_seals_partial_and_resume_neither_loses_nor_duplicates(
        tmp_path, make_zip, make_png):
    """中途停止：已封的必须记账，重跑才能"不丢也不重"。

    封口和记账如果不成对，两种事故各一次：只封不记 → 重跑把同样几张再写
    一遍（训练集里凭空多一份）；只记不封 → 状态说做过，包里没有（静默丢图）。
    """
    make_zip(tmp_path / "src.zip", {f"a/{i}.png": make_png() for i in range(5)})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=False))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)
    opts = PackOptions(formats=("zip",), max_records=100)

    stop = {"flag": False, "packed": 0}

    def on_sample(_item):
        stop["packed"] += 1
        if stop["packed"] >= 3:
            stop["flag"] = True

    first = pack_items(plan.items, out, opts, layout="flat", workers=1,
                       on_sample=on_sample, should_stop=lambda: stop["flag"])
    assert first.packed == 3
    assert first.stopped, "停止原因要能让上层落成 stopped 状态"
    assert first.sealed, "已写进缓冲的条目必须封口，否则句柄留在 .tmp 上"
    assert not list(out.glob("*.tmp"))

    second = pack_items(plan.items, out, opts, layout="flat", workers=1)
    assert second.packed == 2 and second.skipped_done == 3

    names = []
    for shard in sorted(out.glob("*.zip")):
        with zipfile.ZipFile(shard) as zf:
            names.extend(m for m in zf.namelist() if m.endswith(".jpg"))
    assert len(names) == 5 and len(set(names)) == 5


# ------------------------------------------------------------------ 盘位预算


def test_estimate_does_not_inflate_when_bytes_are_copied_verbatim(tmp_path):
    """reencode=never 是原样拷贝：按 4:4:4 的 2.6× 估会凭空多报一倍。

    这个估算的唯一用途是决定"让不让开跑"，高估的后果是明明装得下却被拦。
    """
    item = TagItem(image_id="a-000001", path=tmp_path / "a.jpg", rel="a.jpg",
                   source=str(tmp_path / "a.jpg"), size=100_000)
    copied = PackOptions(formats=("zip",), reencode_mode="never")
    transcoded = PackOptions(formats=("zip",), reencode_mode="always")

    assert estimate_item_bytes(item, copied) < 102_000
    assert estimate_item_bytes(item, transcoded) > 200_000


def test_estimate_scales_with_format_count(tmp_path):
    item = TagItem(image_id="a-000001", path=tmp_path / "a.png", rel="a.png",
                   source=str(tmp_path / "a.png"), size=50_000)
    one = PackOptions(formats=("parquet",), reencode_mode="never")
    two = PackOptions(formats=("parquet", "zip"), reencode_mode="never")
    assert estimate_pack_bytes([item], two) > estimate_pack_bytes([item], one) * 1.8


def test_required_bytes_adds_twenty_percent_headroom(tmp_path):
    item = TagItem(image_id="a-000001", path=tmp_path / "a.png", rel="a.png",
                   source=str(tmp_path / "a.png"), size=500_000)
    opts = PackOptions(formats=("zip",), reencode_mode="never")
    plain = estimate_pack_bytes([item], opts)
    assert required_pack_bytes([item], opts) == int(plain * 1.2)


def test_pack_refuses_before_writing_anything_when_budget_exceeds_free(
        tmp_path, make_zip, make_png, monkeypatch):
    """装不下就在第一条之前失败：不留半成品，换块盘重跑代价为零。"""
    make_zip(tmp_path / "src.zip", {f"a/{i}.png": make_png() for i in range(3)})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=False))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)

    import tagger.pipeline as pipeline_mod

    monkeypatch.setattr(pipeline_mod, "free_bytes", lambda _p: 1024)
    with pytest.raises(PackSpaceError):
        pack_items(plan.items, out, PackOptions(formats=("zip",)), workers=1)

    assert not list(out.glob("*.zip"))
    assert not list(out.glob("*.tmp"))


def test_pack_stops_midway_when_free_space_runs_out(tmp_path, make_zip, make_png,
                                                     monkeypatch):
    """开跑时够、跑着不够：停下并把原因带给上层（如实落 stopped，不冒充 done）。"""
    make_zip(tmp_path / "src.zip", {f"a/{i}.png": make_png() for i in range(4)})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=False))
    out = tmp_path / "out"
    _write_artifacts(out, plan.items)

    import tagger.pipeline as pipeline_mod

    # 第一次问（开跑前）很远，之后每次问都只剩 1 字节
    calls = {"n": 0}

    def fake_free(_path):
        calls["n"] += 1
        return 1 << 40 if calls["n"] == 1 else 1

    monkeypatch.setattr(pipeline_mod, "free_bytes", fake_free)
    report = pack_items(plan.items, out, PackOptions(formats=("zip",), max_records=1),
                        workers=1)
    assert report.stopped and "磁盘" in report.stopped
    assert report.packed < len(plan.items)


def _tar_texts(out) -> dict[str, str]:
    """读出 webdataset 分片里的文本成员，键是完整成员名（图片不是 utf-8，跳过）。"""
    import tarfile

    texts: dict[str, str] = {}
    with tarfile.open(next(out.glob("*.tar"))) as tf:
        for member in tf.getmembers():
            if member.isdir() or not member.name.endswith((".tag", ".nl", ".json")):
                continue
            texts[member.name] = tf.extractfile(member).read().decode("utf-8")
    return texts


def test_pack_injects_artist_into_sample_text(tmp_path, make_zip, make_png):
    """画师注入写进 .tag/.nl —— 训练侧读的是这两份文本，不是 JSON 字段。"""
    make_zip(tmp_path / "src.zip", {"alice/1.png": make_png()})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=True))
    out = tmp_path / "out"
    item = plan.items[0]
    p = artifact_path(out, item)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({
        "image_id": item.image_id, "ok": True, "tag": "red, square",
        "caption": "a red square", "tags": [["red", 0.9]],
        "provenance": {"mode": "test"},
    }, ensure_ascii=False), encoding="utf-8")

    pack_items([item], out, PackOptions(formats=("webdataset",)),
               layout="flat", workers=1, inject_artist=True, artist_prefix="@")

    texts = _tar_texts(out)
    stem = item.image_id
    assert texts[f"{stem}.tag"].startswith("@alice,")
    assert texts[f"{stem}.nl"].startswith("@alice,")


def test_pack_leaves_text_alone_when_inject_disabled(tmp_path, make_zip, make_png):
    make_zip(tmp_path / "src.zip", {"alice/1.png": make_png()})
    plan = plan_inputs(tmp_path / "src.zip", artist_rule=ArtistRule(enabled=True))
    out = tmp_path / "out"
    item = plan.items[0]
    p = artifact_path(out, item)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({
        "image_id": item.image_id, "ok": True, "tag": "red, square",
        "caption": "a red square", "tags": [["red", 0.9]],
        "provenance": {"mode": "test"},
    }, ensure_ascii=False), encoding="utf-8")

    pack_items([item], out, PackOptions(formats=("webdataset",)),
               layout="flat", workers=1, inject_artist=False, artist_prefix="@")

    texts = _tar_texts(out)
    stem = item.image_id
    assert texts[f"{stem}.tag"] == "red, square"
    assert texts[f"{stem}.nl"] == "a red square"
    assert '"artist": "alice"' in texts[f"{stem}.json"]
