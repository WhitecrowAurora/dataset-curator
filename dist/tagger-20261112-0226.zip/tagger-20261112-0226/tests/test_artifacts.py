"""parquet 产物形态：写、读、以及对账/报告能不能认。

这一层的价值全在"换形态之后结论不变"。所以测试的重点是：
同一条数据用 json 落和用 parquet 落，merge 与 report 得到的结论必须一致。
"""

from __future__ import annotations

import json

import pytest

from tagger.artifacts import (JsonlSink, ParquetSink, iter_parquet_artifacts,
                              load_done_ids, parse_payload)
from tagger.merge import MergeStats, check, collect
from tagger.report import collect_points

pytest.importorskip("pyarrow")


def _tag_payload(image_id: str, tags: list[str], **extra) -> dict:
    return {"image_id": image_id, "tag": ", ".join(tags),
            "tags": [[t, 1.0] for t in tags], "ok": True, **extra}


def _nl_payload(image_id: str, caption: str, **extra) -> dict:
    return {"image_id": image_id, "caption": caption, "chars": len(caption),
            "nl_tokens": 42, "score": 4.0, "flags": [], "ok": True, **extra}


def test_sink_writes_and_reads_back(tmp_path):
    sink = ParquetSink(tmp_path, rows_per_file=2)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]),
             _nl_payload("a-000001", "a red square"))
    sink.add("a-000002", _tag_payload("a-000002", ["blue"]),
             _nl_payload("a-000002", "a blue square"))
    sink.close()

    files = sorted(tmp_path.glob("artifacts-*.parquet"))
    assert len(files) == 1
    rows = list(iter_parquet_artifacts(files[0]))
    assert [r["image_id"] for r in rows] == ["a-000001", "a-000002"]
    payload = parse_payload("tag", rows[0]["tag"])
    assert payload["tag"] == "red"


def test_sink_flushes_multiple_shards(tmp_path):
    sink = ParquetSink(tmp_path, rows_per_file=2)
    for i in range(1, 6):
        sink.add(f"a-{i:06d}", _tag_payload(f"a-{i:06d}", ["red"]), None)
    sink.close()
    files = sorted(tmp_path.glob("artifacts-*.parquet"))
    assert len(files) == 3          # 2 + 2 + 1
    assert sorted(load_done_ids(tmp_path)) == [f"a-{i:06d}" for i in range(1, 6)]


def test_sink_seq_continues_after_restart(tmp_path):
    """重启后追加不能覆盖已有分片——否则续做会把前面的成果冲掉。"""
    first = ParquetSink(tmp_path, rows_per_file=10)
    first.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    first.close()

    second = ParquetSink(tmp_path, rows_per_file=10)
    second.add("a-000002", _tag_payload("a-000002", ["blue"]), None)
    second.close()

    files = sorted(tmp_path.glob("artifacts-*.parquet"))
    assert [f.name for f in files] == ["artifacts-00000.parquet",
                                       "artifacts-00001.parquet"]
    assert sorted(load_done_ids(tmp_path)) == ["a-000001", "a-000002"]


def test_parse_payload_handles_empty_and_plain_text():
    assert parse_payload("tag", "") is None
    assert parse_payload("tag", "red, blue") == {"tag": "red, blue"}
    assert parse_payload("nl", "a caption") == {"caption": "a caption"}


# ------------------------------------------------------------------ 对账


def test_merge_reads_parquet_artifacts(tmp_path):
    sink = ParquetSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red", "blue"]),
             _nl_payload("a-000001", "a red square"))
    sink.add("a-000002", _tag_payload("a-000002", ["green"]),
             _nl_payload("a-000002", "a green circle"))
    sink.close()

    stats = MergeStats()
    records = collect([tmp_path], stats=stats)
    assert sorted(records) == ["a-000001", "a-000002"]
    assert records["a-000001"].tag == "red, blue"
    assert records["a-000001"].caption == "a red square"
    assert not stats.empty_roots
    assert not stats.unreadable

    check(records, expected_ids=["a-000001", "a-000002"], stats=stats)
    assert stats.complete == 2
    assert not stats.failed


def test_merge_detects_missing_when_parquet_given(tmp_path):
    sink = ParquetSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red"]),
             _nl_payload("a-000001", "a red square"))
    sink.close()

    records = collect([tmp_path])
    stats = check(records, expected_ids=["a-000001", "a-000002"])
    assert stats.missing_ids == ["a-000002"]
    assert stats.failed


def test_merge_flags_conflict_between_json_and_parquet(tmp_path, write_artifact):
    """两种形态并存且内容不同 = 内容冲突。不能因为格式不同就当成两条。"""
    write_artifact(tmp_path, "a-000001", tag="red", caption="from json")
    sink = ParquetSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["blue"]),
             _nl_payload("a-000001", "from parquet"))
    sink.close()

    stats = MergeStats()
    collect([tmp_path], stats=stats)
    assert "a-000001" in stats.duplicates
    assert stats.failed


def test_merge_ignores_unrelated_parquet(tmp_path):
    """不是 artifacts-*.parquet 的文件不该被当成产物（比如别人放的训练分片）。"""
    import pyarrow as pa
    import pyarrow.parquet as pq

    pq.write_table(pa.table({"image": [b"x"], "caption": ["y"]}),
                   tmp_path / "train-00000.parquet")
    stats = MergeStats()
    records = collect([tmp_path], stats=stats)
    assert records == {}
    assert stats.empty_roots == [str(tmp_path)]


# ------------------------------------------------------------------ 报告


def test_report_reads_parquet_artifacts(tmp_path):
    sink = ParquetSink(tmp_path, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", ["red", "blue", "green"]),
             _nl_payload("a-000001", "a red square"))
    sink.close()

    points = collect_points([tmp_path])
    assert len(points) == 1
    p = points[0]
    assert p.image_id == "a-000001"
    assert p.tag_count == 3
    assert p.chars == len("a red square")
    assert p.ok


def test_report_gives_same_numbers_for_json_and_parquet(tmp_path, write_artifact):
    json_dir = tmp_path / "json"
    pq_dir = tmp_path / "pq"
    tags = ["red", "blue", "green"]
    caption = "a red square with blue and green tones"

    write_artifact(json_dir, "a-000001", tag=", ".join(tags), caption=caption)
    sink = ParquetSink(pq_dir, rows_per_file=10)
    sink.add("a-000001", _tag_payload("a-000001", tags),
             _nl_payload("a-000001", caption))
    sink.close()

    a = collect_points([json_dir])[0]
    b = collect_points([pq_dir])[0]
    assert (a.image_id, a.tag_count, a.chars) == (b.image_id, b.tag_count, b.chars)


def test_sink_roundtrip_preserves_unicode(tmp_path):
    """中文描述在 parquet 里必须原样回来（编码问题在列式存储里很常见）。"""
    sink = ParquetSink(tmp_path, rows_per_file=10)
    sink.add("画师-000001", _tag_payload("画师-000001", ["红裙"]),
             _nl_payload("画师-000001", "一位穿红裙子的女孩站在树下"))
    sink.close()

    records = collect([tmp_path])
    rec = records["画师-000001"]
    assert rec.caption == "一位穿红裙子的女孩站在树下"
    assert json.loads(json.dumps(rec.tag, ensure_ascii=False)) == "红裙"


# ------------------------------------------------- 两种分片必须给同一个结论


def test_merge_and_report_agree_between_parquet_and_jsonl(tmp_path):
    """换形态不换结论：同一批数据，两种分片出来的对账与统计逐字段相同。"""
    ids = ["a-000001", "a-000002"]
    tags = [["red", "blue"], ["green"]]
    captions = ["a red square", "a green circle"]

    pq_dir, jl_dir = tmp_path / "pq", tmp_path / "jl"
    for target, cls in ((pq_dir, ParquetSink), (jl_dir, JsonlSink)):
        sink = cls(target, rows_per_file=1)
        for i, image_id in enumerate(ids):
            sink.add(image_id, _tag_payload(image_id, tags[i]),
                     _nl_payload(image_id, captions[i]))
        sink.close()

    a, b = collect([pq_dir]), collect([jl_dir])
    assert sorted(a) == sorted(b) == ids
    for image_id in ids:
        assert (a[image_id].tag, a[image_id].caption) == (
            b[image_id].tag, b[image_id].caption)

    pa = {p.image_id: (p.tag_count, p.chars, p.nl_tokens, p.score)
          for p in collect_points([pq_dir])}
    pb = {p.image_id: (p.tag_count, p.chars, p.nl_tokens, p.score)
          for p in collect_points([jl_dir])}
    assert pa == pb


def test_done_ids_unite_both_formats(tmp_path):
    """换过形态重跑时，已完成集合必须是并集，否则会把做过的图再做一遍，
    而重做出来的那份会在 merge 里变成要人工裁决的内容冲突。"""
    pq = ParquetSink(tmp_path, rows_per_file=10)
    pq.add("a-000001", _tag_payload("a-000001", ["red"]), None)
    pq.close()

    jl = JsonlSink(tmp_path, rows_per_file=10)
    jl.add("a-000002", _tag_payload("a-000002", ["blue"]), None)
    jl.close()

    assert sorted(load_done_ids(tmp_path)) == ["a-000001", "a-000002"]
    assert load_done_ids(tmp_path, fmt="parquet") == {"a-000001"}
    assert load_done_ids(tmp_path, fmt="jsonl") == {"a-000002"}
