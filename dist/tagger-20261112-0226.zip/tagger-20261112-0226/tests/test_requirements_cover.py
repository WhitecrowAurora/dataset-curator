"""依赖清单必须覆盖代码真的 import 的东西。

为什么值得一条测试：漏一个包不会在开发机上暴露（每个人的 env 都被手动
装过），只会在别人按标准流程 `install.bat` 装完之后炸——而且通常炸在
某个很少走的分支里（加密 zip、7z、HF 下载）。那种发现方式代价太高，
所以在提交前就拦住。

口径：
* 扫 `tagger/` 下所有 `.py`（含函数体内的延迟 import，它们最容易漏）。
* 只认**顶层模块名**，`from .x import y` 这种相对导入不算。
* 把清单里的发行名换算成 import 名（Pillow → PIL 等）。
* 手工维护的"允许缺席"表：确实是可选功能、缺了有降级路径的，写理由。
"""

from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "tagger"

# 发行名 → import 名。只有两者不一致的才需要写在这里。
DIST_TO_MODULE = {
    "pyyaml": "yaml",
    "pillow": "PIL",
    "open-clip-torch": "open_clip",
    "pydantic-core": "pydantic_core",
    "typing-extensions": "typing_extensions",
    "annotated-doc": "annotated_doc",
    "annotated-types": "annotated_types",
    "typing-inspection": "typing_inspection",
    "pygments": "pygments",
}

# 允许不在清单里的模块 → 理由。每条都对应代码里真的能降级的路径，
# 不是"懒得装"。新加一条之前先确认缺了它真的还能跑。
ALLOWED_MISSING = {
    # 7z / AES-zip 之外的解包后端，缺了 describe_backends() 会照实报"不可用"，
    # 且 rar 还要外部 unrar.exe，装了 Python 包也不能保证能读。
    "rarfile": "rar 需外部 unrar.exe，装了 Python 包也不能保证可读",
    # 4bit 量化专用（pyproject 的 quantize extra），几百 MB 且对 torch 版本卡死。
    "llmcompressor": "只做量化那一次需要，见 pyproject 的 quantize extra",
}


def _read_requirements() -> set[str]:
    names: set[str] = set()
    for fname in ("requirements-embedded.txt", "requirements-tag.txt"):
        path = ROOT / fname
        if not path.is_file():
            continue
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # `torch==2.14.1` / `transformers>=4.46,<6` / `pkg[extra]` 都取包名
            m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)", line)
            if m:
                names.add(m.group(1).lower().replace("_", "-"))
    return names


def _imported_modules() -> dict[str, list[str]]:
    """顶层模块名 → 出现位置（文件:行）。"""
    found: dict[str, list[str]] = {}

    def add(name: str, where: str) -> None:
        found.setdefault(name, []).append(where)

    for path in PKG.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (OSError, SyntaxError):
            continue
        rel = path.relative_to(ROOT).as_posix()
        for node in ast.walk(tree):
            # ast.walk 会走遍函数体，所以延迟 import 一样能抓到——这正是要点。
            if isinstance(node, ast.Import):
                for alias in node.names:
                    add(alias.name.split(".")[0], f"{rel}:{node.lineno}")
            elif isinstance(node, ast.ImportFrom):
                if node.level:            # from . import x / from ..a import b
                    continue
                if node.module:
                    add(node.module.split(".")[0], f"{rel}:{node.lineno}")
    return found


def _stdlib() -> set[str]:
    names = set(sys.stdlib_module_names)
    names |= set(sys.builtin_module_names)
    # 本项目自己的包 / 测试内部模块
    names |= {"tagger", "tests"}
    return names


def test_每个第三方import都在依赖清单里():
    have = _read_requirements()
    modules = {DIST_TO_MODULE.get(d, d.replace("-", "_")).lower(): d for d in have}
    missing: dict[str, list[str]] = {}

    for mod, places in _imported_modules().items():
        if mod in _stdlib():
            continue
        if mod.lower() in modules:
            continue
        if mod in ALLOWED_MISSING:
            continue
        missing[mod] = places

    if missing:
        detail = "\n".join(f"  {m}: {', '.join(ps[:3])}"
                           for m, ps in sorted(missing.items()))
        pytest.fail(
            "下面这些模块被 import 了，但两份 requirements 里都没有：\n"
            f"{detail}\n"
            "要么补进 requirements-embedded.txt，要么加进 ALLOWED_MISSING 并写清理由。"
        )


def test_允许缺席的模块真的不在清单里():
    """反向检查：ALLOWED_MISSING 里列的东西如果已经进了清单，这条豁免就是
    陈旧注释，留着会让人以为那个包还没有。"""
    have = {d.replace("-", "_") for d in _read_requirements()}
    stale = [m for m in ALLOWED_MISSING if m in have]
    assert not stale, f"这些模块已经在清单里了，可以从 ALLOWED_MISSING 删掉：{stale}"


def test_新增的解包后端在清单里():
    """containers.py 的 AES-zip / 7z 两条路缺包时会静默返回空列表，
    表现成"这个包里的图一张都没读到"——比报错难查得多，所以钉住。"""
    have = _read_requirements()
    for dist in ("pyzipper", "py7zr"):
        assert dist in have, f"{dist} 必须进 requirements-embedded.txt"


def test_嵌入清单里的包名都合法():
    """拼错的包名 pip 会直接报 'No matching distribution'，而那句报错
    看起来像"镜像坏了"。这里只做形状检查，不校验存在性（那要联网）。"""
    for fname in ("requirements-embedded.txt", "requirements-tag.txt"):
        path = ROOT / fname
        if not path.is_file():
            continue
        for i, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            assert re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]*(\[[\w,]+\])?\s*(==|>=|<=|~=|!=|>|<)?",
                            line), f"{fname}:{i} 不是合法的依赖行：{line!r}"
