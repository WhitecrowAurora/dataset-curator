"""批次报告的守卫。

报告最容易出的错不是算错，而是**算出一个看起来很正常的假数**：
批次大小被忽略、空目录被算成 0 条合格、列顺序与图例对不上。
"""

from __future__ import annotations

import json

from tagger.pack import PackOptions, Packer
from tagger.report import (SamplePoint, build_report, collect_points,
                           collect_points_from_archives, render_markdown,
                           sort_points, summary_lines, write_report)


# ------------------------------------------------------------------ 读产物


def test_collect_points_merges_tag_and_nl(tmp_path, write_artifact):
    write_artifact(tmp_path, "a-000001", tag="red, blue, green",
                   caption="a red square", nl_tokens=42, score=4.2,
                   flags=["short"])
    points = collect_points([tmp_path])

    assert len(points) == 1
    p = points[0]
    assert p.image_id == "a-000001"
    assert p.tag_count == 3
    assert p.chars == len("a red square")
    assert p.nl_tokens == 42
    assert p.score == 4.2
    assert p.flags == ("short",)
    assert p.ok


def test_collect_points_reports_missing_dir(tmp_path):
    bad: list[str] = []
    points = collect_points([tmp_path / "nope"], unreadable=bad)
    assert points == []
    assert bad and "nope" in bad[0]


def test_collect_points_from_parquet(tmp_path, make_png):
    """parquet 是默认输出格式，报告也得能读。"""
    import pytest

    pytest.importorskip("pyarrow")
    opts = PackOptions(max_records=10, formats=("parquet",))
    packer = Packer(tmp_path / "out", opts, verbose=False)
    packer.add(flat_name="a-000001.png", image_bytes=make_png(),
               meta={"width": 8, "height": 8},
               nl="a red square", tag_text="red, square")
    packer.close()

    points = collect_points_from_archives(tmp_path / "out")
    assert len(points) == 1
    # 名字口径与 tar/zip 一致（带扩展名），否则同一批数据换个格式就"对不上"。
    assert points[0].image_id == "a-000001.jpg"
    assert points[0].tag_count == 2
    assert points[0].chars == len("a red square")


def test_collect_points_from_tar(tmp_path, make_png):
    opts = PackOptions(max_records=10, formats=("webdataset",))
    packer = Packer(tmp_path / "out", opts, verbose=False)
    packer.add(flat_name="a-000001.png", image_bytes=make_png(),
               meta={"width": 8, "height": 8},
               nl="a red square", tag_text="red, square")
    packer.close()

    points = collect_points_from_archives(tmp_path / "out")
    assert len(points) == 1
    assert points[0].image_id == "a-000001.jpg"
    assert points[0].tag_count == 2
    assert points[0].chars == len("a red square")
    assert points[0].ok


# ------------------------------------------------------------------ 分批


def _points(n: int) -> list[SamplePoint]:
    return [SamplePoint(image_id=f"a-{i:06d}", tag_count=10 + i,
                        chars=400 + i, nl_tokens=100, score=4.0, ok=True)
            for i in range(1, n + 1)]


def test_build_report_splits_batches():
    report = build_report(_points(5), batch_size=2, order="id", source="test")
    assert report["batch_count"] == 3
    assert [r["count"] for r in report["series"]] == [2, 2, 1]
    assert report["series"][0]["start_id"] == "a-000001"
    assert report["series"][0]["end_id"] == "a-000002"
    assert report["series"][-1]["end_id"] == "a-000005"
    assert report["totals"]["samples"] == 5


def test_build_report_series_and_columns_are_aligned():
    report = build_report(_points(4), batch_size=2)
    for key, col in report["metrics"].items():
        assert len(col["values"]) == report["batch_count"], key
        for i, value in enumerate(col["values"]):
            assert value == report["series"][i][key]


def test_build_report_rates_and_means():
    pts = [
        SamplePoint("a-000001", tag_count=10, chars=100, score=4.0, ok=True),
        SamplePoint("a-000002", tag_count=20, chars=300, score=3.0, ok=False,
                    flags=("short",)),
    ]
    report = build_report(pts, batch_size=10)
    totals = report["totals"]
    assert totals["avg_tag_count"] == 15.0
    assert totals["avg_chars"] == 200.0
    assert totals["avg_score"] == 3.5
    assert totals["complete_rate"] == 0.5
    assert totals["flag_rate"] == 0.5


def test_build_report_empty_is_zero_not_crash():
    report = build_report([], batch_size=10)
    assert report["batch_count"] == 0
    assert report["totals"]["samples"] == 0
    assert report["totals"]["avg_tag_count"] == 0.0
    assert report["metrics"]["avg_tag_count"]["values"] == []


def test_sort_points_time_vs_id():
    pts = [
        SamplePoint("a-000002", ts=10.0),
        SamplePoint("a-000001", ts=20.0),
    ]
    assert [p.image_id for p in sort_points(pts, "id")] == ["a-000001", "a-000002"]
    assert [p.image_id for p in sort_points(pts, "time")] == ["a-000002", "a-000001"]


def test_batch_size_must_be_positive():
    import pytest

    with pytest.raises(ValueError):
        build_report(_points(2), batch_size=0)


# ------------------------------------------------------------------ 渲染 / 落盘


def test_render_markdown_lists_metrics(tmp_path):
    report = build_report(_points(3), batch_size=2, source="artifacts:x")
    md = render_markdown(report)
    assert "批次报告" in md
    assert "| 1 |" in md and "| 2 |" in md
    assert "a-000001" in md


def test_render_markdown_truncates_long_series():
    report = build_report(_points(10), batch_size=1)
    md = render_markdown(report, top=3)
    assert "其余 7 批略" in md


def test_write_report_writes_both(tmp_path):
    report = build_report(_points(2), batch_size=10, source="test")
    json_out = tmp_path / "r" / "report.json"
    md_out = tmp_path / "r" / "report.md"
    written = write_report(report, json_out=json_out, md_out=md_out)

    assert len(written) == 2
    data = json.loads(json_out.read_text(encoding="utf-8"))
    assert data["schema"] == 1
    assert data["totals"]["samples"] == 2
    assert "批次报告" in md_out.read_text(encoding="utf-8")


def test_summary_lines_point_at_worst_batch():
    pts = [
        SamplePoint("a-000001", tag_count=10, chars=100, ok=True),
        SamplePoint("a-000002", tag_count=10, chars=100, ok=False),
    ]
    report = build_report(pts, batch_size=1)
    lines = summary_lines(report)
    assert any("最差批" in line and "完整率 0.0%" in line for line in lines)
