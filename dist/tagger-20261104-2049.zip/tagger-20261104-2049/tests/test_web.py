"""Web 层：任务 API / 事件流 / 结果读回。

用假后端，不碰真权重——这里要验的是"HTTP 契约与任务生命周期"，不是数值。
真数值由 test_tag_golden / verify_dtype 管。

三条最值得钉的：
1. 同一时刻只允许一个任务（单卡并行只会两个都慢）；
2. 停止是协作式的：**已经算完的块不白扔**，产物照落盘；
3. 事件流带 cursor，断线重连能补齐（前端就靠这个，队列式的实现做不到）。
"""

from __future__ import annotations

import os
import time

import pytest
from fastapi.testclient import TestClient

from tagger.cpu_tagger import TagPrediction
from tagger.web import jobs as jobs_mod
from tagger.web.app import create_app


class _FakeBackend:
    name = "fake"
    precision = "bf16"
    batch_size = 1

    def __init__(self, delay=0.0):
        self.delay = delay
        self.last_timings = {"total": 5, "decode": 2, "forward": 2}
        self.calls = 0

    def load(self):
        return None

    def predict_batch(self, images):
        self.calls += 1
        if self.delay:
            time.sleep(self.delay)
        return [TagPrediction(tags=[("red", 0.9)], backend="fake",
                              rating={"general": 0.6}) for _ in images]


@pytest.fixture
def client(monkeypatch, tmp_path):
    jobs_mod.MANAGER._jobs.clear()
    monkeypatch.setattr(jobs_mod, "build_backend",
                        lambda *a, **kw: _FakeBackend(delay=0.05))
    monkeypatch.setattr(jobs_mod, "resolve_device", lambda s: "cpu")
    # guard 是真 ResourceGuard，磁盘熔断线跟着**这台机器**的余量走（本仓库
    # 开发机的临时盘就低于 30G）。契约测试要的是确定性：这里统一关掉，
    # guard 行为本身由 test_guard 与本文件里接 stub guard 的用例负责。
    monkeypatch.setattr(jobs_mod.JobManager, "_make_guard",
                        lambda self, job: None)
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def _images(tmp_path, n=4):
    src = tmp_path / "in"
    src.mkdir()
    for i in range(n):
        (src / f"{i}.png").write_bytes(b"\x89PNG\r\n\x1a\n")
    return src


def _wait(client, job_id, timeout=8.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        snap = client.get(f"/api/jobs/{job_id}").json()
        if snap["status"] in ("done", "failed", "stopped"):
            return snap
        time.sleep(0.05)
    raise AssertionError(f"任务没在 {timeout}s 内结束：{snap}")


def test_health_reports_environment(client):
    data = client.get("/api/health").json()
    assert data["ok"] is True
    assert data["running_job"] is None
    assert isinstance(data["gpus"], list)


def test_defaults_have_form_fields(client):
    data = client.get("/api/defaults").json()
    assert set(data) >= {"backend", "precision", "batch", "threshold"}
    assert 0.0 < data["threshold"] < 1.0
    # 硬件保护的滑条初值来自 limits 段：页面可调的键必须与后端白名单同源，
    # 否则会出现"页面上能调、后端默默丢掉"的假开关。
    assert set(data["guard"]) == set(jobs_mod.GUARD_KNOBS)
    assert 0.0 < data["guard"]["duty_cycle"] <= 1.0


def test_job_runs_and_writes_artifacts(client, tmp_path):
    src = _images(tmp_path, 4)
    created = client.post("/api/jobs", json={"input_dir": str(src),
                                             "out_dir": str(tmp_path / "out")})
    assert created.status_code == 202, created.text
    job_id = created.json()["id"]
    snap = _wait(client, job_id)

    assert snap["status"] == "done"
    assert snap["counts"]["done"] == 4
    assert snap["progress"] == 1.0

    # 产物真的落盘了（UI 不缓存，全靠文件）
    arts = list((tmp_path / "out" / "tags").glob("*-tag.json"))
    assert len(arts) == 4

    res = client.get(f"/api/jobs/{job_id}/results").json()
    assert res["total"] == 4
    assert res["items"][0]["tags"] == [["red", 0.9]]
    assert res["items"][0]["rating"]["general"] == 0.6


def test_results_support_search_and_paging(client, tmp_path):
    src = _images(tmp_path, 4)
    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}
                         ).json()["id"]
    _wait(client, job_id)

    page = client.get(f"/api/jobs/{job_id}/results", params={"limit": 2}).json()
    assert len(page["items"]) == 2 and page["total"] == 4
    one = client.get(f"/api/jobs/{job_id}/results", params={"q": "1"}).json()
    assert one["total"] == 1


def test_events_are_replayable_from_cursor(client, tmp_path):
    src = _images(tmp_path, 3)
    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}
                         ).json()["id"]
    _wait(client, job_id)

    all_events = client.get(f"/api/jobs/{job_id}/events").json()["events"]
    kinds = [e["kind"] for e in all_events]
    assert kinds[0] == "job_started"
    assert kinds[-1] == "job_finished"
    assert kinds.count("item") == 3

    # after 的语义是"严格大于"：带 cursor=2 只回 3 之后，不会把 2 重发一遍
    tail = client.get(f"/api/jobs/{job_id}/events",
                      params={"after": all_events[1]["seq"]}).json()["events"]
    assert [e["seq"] for e in tail] == [e["seq"] for e in all_events[2:]]


def test_second_job_is_rejected_while_one_runs(client, monkeypatch, tmp_path):
    monkeypatch.setattr(jobs_mod, "build_backend",
                        lambda *a, **kw: _FakeBackend(delay=0.4))
    src = _images(tmp_path, 10)
    first = client.post("/api/jobs", json={"input_dir": str(src),
                                           "out_dir": str(tmp_path / "out")})
    assert first.status_code == 202

    second = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out2")})
    assert second.status_code == 409
    assert "已有任务在跑" in second.json()["detail"]


def test_stop_keeps_finished_chunks(client, monkeypatch, tmp_path):
    """中止只在块边界生效：块内那几张必须算完并落盘，不能白扔。"""
    monkeypatch.setattr(jobs_mod, "build_backend",
                        lambda *a, **kw: _FakeBackend(delay=0.3))
    src = _images(tmp_path, 40)          # batch_size=1 → 每块 8 张
    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}
                         ).json()["id"]
    time.sleep(0.4)                       # 等第一块开始
    assert client.post(f"/api/jobs/{job_id}/stop").status_code == 200
    snap = _wait(client, job_id)

    assert snap["status"] == "stopped"
    assert snap["counts"]["done"] > 0
    assert snap["counts"]["done"] < 40
    assert len(list((tmp_path / "out" / "tags").glob("*-tag.json"))) == snap["counts"]["done"]


def test_missing_job_is_404(client):
    assert client.get("/api/jobs/nope").status_code == 404
    assert client.get("/api/jobs/nope/results").status_code == 404


def test_empty_directory_is_400(client, tmp_path):
    empty = tmp_path / "empty"
    empty.mkdir()
    resp = client.post("/api/jobs", json={"input_dir": str(empty)})
    assert resp.status_code == 400
    assert "没有找到图片" in resp.json()["detail"]


def test_thumbnail_is_jpeg_and_cached(client, tmp_path):
    from PIL import Image

    src = tmp_path / "in"
    src.mkdir()
    Image.new("RGB", (512, 256), (200, 30, 40)).save(src / "a.png")

    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}
                         ).json()["id"]
    _wait(client, job_id)

    resp = client.get(f"/api/jobs/{job_id}/thumb/a", params={"w": 128})
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "image/jpeg"
    img = Image.open(__import__("io").BytesIO(resp.content))
    assert img.width == 128 and img.height == 64


def test_websocket_pushes_snapshot_and_finishes(client, tmp_path):
    src = _images(tmp_path, 2)
    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}
                         ).json()["id"]

    seen_kinds: list[str] = []
    with client.websocket_connect(f"/ws/events?job_id={job_id}") as ws:
        for _ in range(30):
            msg = ws.receive_json()
            if msg["type"] == "tick":
                seen_kinds += [e["kind"] for e in msg["events"]]
                assert msg["snapshot"]["counts"]["total"] == 2
            elif msg["type"] == "done":
                break
    assert "job_finished" in seen_kinds


def test_websocket_rejects_unknown_job(client):
    with client.websocket_connect("/ws/events?job_id=nope") as ws:
        msg = ws.receive_json()
    assert msg["type"] == "error"


# ------------------------------------------------------------------ 输入发现与命名


def _real_png(path, color=(30, 60, 90)):
    from PIL import Image

    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (16, 12), color).save(path, "PNG")


def test_preview_reports_zip_input_and_flat_names(client, tmp_path, make_zip):
    import io

    from PIL import Image

    def png():
        buf = io.BytesIO()
        Image.new("RGB", (8, 8), (1, 2, 3)).save(buf, "PNG")
        return buf.getvalue()

    make_zip(tmp_path / "big.zip", {
        "alice/1.png": png(),
        "alice/2.png": png(),
        "bob/1.png": png(),
    })
    data = client.get("/api/preview", params={
        "path": str(tmp_path / "big.zip"), "artist": "true", "layout": "flat",
    }).json()

    assert data["total"] == 3
    assert [s["image_id"] for s in data["samples"]] == [
        "alice-000001", "alice-000002", "bob-000003"]
    assert [s["name"] for s in data["samples"]][0].startswith("alice-000001.")
    assert data["sources"][0]["name"] == "big.zip"
    assert data["artists"]["count"] == 2


def test_preview_mirror_keeps_structure(client, tmp_path, make_zip):
    import io

    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", (8, 8), (9, 9, 9)).save(buf, "PNG")
    make_zip(tmp_path / "s.zip", {"alice/sub/1.png": buf.getvalue()})

    data = client.get("/api/preview", params={
        "path": str(tmp_path), "layout": "mirror", "artist": "true",
    }).json()
    assert "/" in data["samples"][0]["name"]


def test_preview_without_pack_uses_legacy_ids(client, tmp_path, make_zip):
    """只打标的任务沿用相对路径 id，预览必须跟着变，否则展示的名字是假的。"""
    import io

    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", (8, 8), (5, 5, 5)).save(buf, "PNG")
    make_zip(tmp_path / "bundle.zip", {"alice/1.png": buf.getvalue()})

    packed = client.get("/api/preview", params={
        "path": str(tmp_path / "bundle.zip"), "artist": "true",
        "layout": "flat", "pack": "true",
    }).json()
    tag_only = client.get("/api/preview", params={
        "path": str(tmp_path / "bundle.zip"), "artist": "true",
        "layout": "flat", "pack": "false",
    }).json()

    assert packed["samples"][0]["image_id"] == "alice-000001"
    assert tag_only["samples"][0]["image_id"] == "bundle/alice/1"
    assert "::" not in tag_only["samples"][0]["image_id"]


def test_fs_lists_zip_files(client, tmp_path, make_zip):
    make_zip(tmp_path / "pack-1.zip", {"a.png": b"x"})
    (tmp_path / "sub").mkdir()
    data = client.get("/api/fs", params={"path": str(tmp_path)}).json()
    assert data["zips"][0]["name"] == "pack-1.zip"
    assert data["zips"][0]["bytes"] > 0
    assert any(d["name"] == "sub" for d in data["dirs"])
    # 目录浏览器要能换盘：Windows 上给出来的 path 必须都是 "X:\" 形式，
    # 否则前端那排盘符按钮点下去是条死路。label 允许为空（很多人不给盘起名），
    # 但字段必须存在——前端靠它决定显示 "名字 (C:)" 还是只显示 "C:"。
    assert isinstance(data["drives"], list)
    if os.name == "nt":
        assert data["drives"]
        assert all(d["path"].endswith(":\\") for d in data["drives"])
        assert all(isinstance(d["label"], str) for d in data["drives"])


def test_preview_rejects_missing_path(client):
    assert client.get("/api/preview", params={"path": str(__import__("pathlib").Path("nope-xyz"))}).status_code in (400, 404)


# ------------------------------------------------------------------ 打标 + 封包


def test_zip_input_job_uses_global_ids(client, tmp_path, make_zip):
    import io

    from PIL import Image

    def png():
        buf = io.BytesIO()
        Image.new("RGB", (8, 8), (5, 5, 5)).save(buf, "PNG")
        return buf.getvalue()

    make_zip(tmp_path / "src.zip", {"alice/1.png": png(), "bob/1.png": png()})
    job_id = client.post("/api/jobs", json={
        "input_dir": str(tmp_path / "src.zip"),
        "out_dir": str(tmp_path / "out"),
        "pack": False,
        "artist": True,
    }).json()["id"]
    snap = _wait(client, job_id)

    assert snap["status"] == "done"
    # 打标阶段的 id 在封包模式下才是全局序号；不封包时沿用相对路径。
    arts = sorted(p.name for p in (tmp_path / "out" / "tags").rglob("*-tag.json"))
    assert len(arts) == 2


def test_job_with_pack_writes_shards_and_reports(client, tmp_path, make_zip):
    import io
    import json
    import zipfile

    from PIL import Image

    def png(color):
        buf = io.BytesIO()
        Image.new("RGB", (16, 12), color).save(buf, "PNG")
        return buf.getvalue()

    make_zip(tmp_path / "src.zip", {
        "alice/1.png": png((10, 10, 10)),
        "alice/2.png": png((20, 20, 20)),
        "bob/1.png": png((30, 30, 30)),
    })
    created = client.post("/api/jobs", json={
        "input_dir": str(tmp_path / "src.zip"),
        "out_dir": str(tmp_path / "out"),
        "pack": True,
        "formats": ["zip"],
        "jpeg_quality": 95,
        "jpeg_subsampling": 0,
        "artist": True,
        "layout": "flat",
        "max_records": 10,
        # 测试机的临时盘常常只剩十几 G，硬件保护的磁盘熔断会直接把封包停掉。
        # 这条测的是封包链路本身，盘位风险与它无关。
        "guard": False,
    })
    assert created.status_code == 202, created.text
    job_id = created.json()["id"]
    snap = _wait(client, job_id, timeout=20)

    assert snap["status"] == "done", snap
    assert snap["pack"]["enabled"] is True
    assert snap["pack"]["packed"] == 3
    assert snap["pack"]["packs"], "封包结果必须带每个分片的统计"
    assert snap["pack"]["packs"][0]["count"] == 3

    pack_file = next((tmp_path / "out").glob("pack-*.zip"))
    with zipfile.ZipFile(pack_file) as zf:
        members = zf.namelist()
        meta = json.loads(zf.read("alice-000001.json"))
    assert "alice-000001.jpg" in members
    assert meta["artist"] == "alice"


def test_pack_rejects_bad_quality_with_400(client, tmp_path, make_zip):
    make_zip(tmp_path / "src.zip", {"a/1.png": b"x"})
    resp = client.post("/api/jobs", json={
        "input_dir": str(tmp_path / "src.zip"),
        "pack": True,
        "jpeg_quality": 80,
    })
    assert resp.status_code == 400
    assert "90~100" in resp.json()["detail"]


def test_preview_reports_disk_estimate_with_formats(client, tmp_path, make_zip):
    """新建页要靠这个数字在"按下开始"之前拦住爆盘；口径必须含 20% 冗余。"""
    import io

    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", (64, 64), (7, 8, 9)).save(buf, "PNG")
    make_zip(tmp_path / "src.zip", {"alice/1.png": buf.getvalue()})

    data = client.get("/api/preview", params={
        "path": str(tmp_path / "src.zip"),
        "out_dir": str(tmp_path / "out"),
        "pack": "true",
        "formats": "parquet",
        "jpeg_quality": 95,
        "jpeg_subsampling": 0,
    }).json()

    est = data["estimate"]
    assert est["headroom"] == 0.2
    assert est["bytes"] > 0 and est["free"] > 0
    assert est["ok"] is (est["bytes"] <= est["free"])


def test_job_rejected_when_budget_exceeds_free_space(client, tmp_path, make_zip, monkeypatch):
    """装不下就不建任务：一张图不写，用户换块盘再来。"""
    make_zip(tmp_path / "src.zip", {"a/1.png": b"x"})
    monkeypatch.setattr(jobs_mod, "free_bytes", lambda _p: 1)

    resp = client.post("/api/jobs", json={
        "input_dir": str(tmp_path / "src.zip"),
        "out_dir": str(tmp_path / "out"),
        "pack": True,
        "formats": ["zip"],
    })
    assert resp.status_code == 400
    assert "20%" in resp.json()["detail"]
    assert not (tmp_path / "out" / "tags").exists()


def test_job_can_skip_space_check(client, tmp_path, make_zip, monkeypatch):
    """关掉空间检查就照跑——估算只是估算，别让它挡住知道自己在做什么的人。"""
    make_zip(tmp_path / "src.zip", {"a/1.png": b"x"})
    monkeypatch.setattr(jobs_mod, "free_bytes", lambda _p: 1)

    created = client.post("/api/jobs", json={
        "input_dir": str(tmp_path / "src.zip"),
        "out_dir": str(tmp_path / "out"),
        "pack": False,
        "check_space": False,
    })
    assert created.status_code == 202, created.text


def test_preview_artist_depth_picks_the_selected_level(client, tmp_path, make_zip):
    """画师层级是用户在界面上直接选的：选了第 2 层，预览的名字就得变。

    取错层的代价是整批 id 前缀全错（`2024-000001` 而不是 `alice-000001`），
    而这种错误在跑完之后才发现，只能重跑。
    """
    import io

    from PIL import Image

    def png():
        buf = io.BytesIO()
        Image.new("RGB", (8, 8), (3, 4, 5)).save(buf, "PNG")
        return buf.getvalue()

    make_zip(tmp_path / "src.zip", {"2024/alice/1.png": png()})

    first = client.get("/api/preview", params={
        "path": str(tmp_path / "src.zip"), "artist": "true",
        "artist_depth": 0, "layout": "flat", "pack": "true",
    }).json()
    second = client.get("/api/preview", params={
        "path": str(tmp_path / "src.zip"), "artist": "true",
        "artist_depth": 1, "layout": "flat", "pack": "true",
    }).json()

    assert first["samples"][0]["image_id"] == "2024-000001"
    assert second["samples"][0]["image_id"] == "alice-000001"
