"""下载队列（下载页的后端）：去重、空间排队、取消、断点状态恢复。

这里的每条都是"不报错但会出事"的形态——空间不拦会写爆盘，取消不生效会
让用户以为暂停了其实还在下，状态不恢复会让重启后的队列全趴着。
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from tagger import hf_source
from tagger.web.hf_downloads import HfDownloads


def _wait(pred, timeout: float = 5.0) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if pred():
            return True
        time.sleep(0.03)
    return pred()


def _fake_ok(repo, filename, dest_dir, **kw):
    path = Path(dest_dir) / Path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"x" * 100)
    progress = kw.get("on_progress")
    if progress is not None:
        progress(100, 100)
    return hf_source.HFShard(repo=repo, filename=filename, path=path, bytes=100)


@pytest.fixture
def mgr(tmp_path, monkeypatch):
    # 100 GB 可用：默认余量是 2 GB，给 1 GB 会一直卡在"空间不够"
    monkeypatch.setattr(hf_source, "free_bytes", lambda p: 100 * 1024 ** 3)
    m = HfDownloads(tmp_path / "cache", state_path=tmp_path / "state.json")
    yield m
    m.stop()


def test_submit_then_done(mgr, monkeypatch):
    monkeypatch.setattr(hf_source, "download_shard", _fake_ok)
    created = mgr.submit("org/ds", ["a.tar"], sizes={"a.tar": 100})
    assert [c["filename"] for c in created] == ["a.tar"]
    assert _wait(lambda: mgr.snapshot()["items"][0]["status"] == "done")
    item = mgr.snapshot()["items"][0]
    assert item["done"] == 100 and item["size"] == 100


def test_same_shard_is_not_queued_twice(mgr, monkeypatch):
    def slow(repo, filename, dest_dir, **kw):
        time.sleep(0.6)
        return _fake_ok(repo, filename, dest_dir, **kw)

    monkeypatch.setattr(hf_source, "download_shard", slow)
    first = mgr.submit("org/ds", ["a.tar"])
    second = mgr.submit("org/ds", ["a.tar"])
    assert len(first) == 1 and second == []


def test_no_space_keeps_it_queued(mgr, monkeypatch):
    monkeypatch.setattr(hf_source, "free_bytes", lambda p: 0)
    mgr.submit("org/ds", ["a.tar"], sizes={"a.tar": 10 ** 9})
    assert _wait(lambda: bool(mgr.snapshot()["items"][0]["message"]))
    item = mgr.snapshot()["items"][0]
    assert item["status"] == "queued"
    assert "空间不够" in item["message"]


def test_cancel_running_piece(mgr, monkeypatch):
    def blocking(repo, filename, dest_dir, **kw):
        stop = kw.get("should_stop")
        for _ in range(200):
            if stop is not None and stop():
                raise hf_source.HFCancelled("x")
            time.sleep(0.02)
        raise AssertionError("没等到取消")

    monkeypatch.setattr(hf_source, "download_shard", blocking)
    item_id = mgr.submit("org/ds", ["a.tar"], sizes={"a.tar": 100})[0]["id"]
    assert _wait(lambda: mgr.snapshot()["items"][0]["status"] == "running")
    assert mgr.cancel(item_id)
    assert _wait(lambda: mgr.snapshot()["items"][0]["status"] == "cancelled")


def test_cancel_queued_piece(mgr):
    mgr.set_reserve(0)
    id_ = mgr.submit("org/ds", ["a.tar"], sizes={"a.tar": 10 ** 12})[0]["id"]
    assert mgr.cancel(id_)
    item = mgr.snapshot()["items"][0]
    assert item["status"] == "cancelled"


def test_interrupted_state_requeues(tmp_path, monkeypatch):
    """上次进程退出时 status=running 的条目，重启后要重新排队（.part 还在）。"""
    monkeypatch.setattr(hf_source, "free_bytes", lambda p: 0)   # 只排队，不真下
    state = tmp_path / "state.json"
    state.write_text(json.dumps({"items": [{
        "id": "abc", "repo": "org/ds", "filename": "a.tar",
        "status": "running", "size": 10, "done": 0,
    }]}), encoding="utf-8")
    m = HfDownloads(tmp_path / "cache", state_path=state)
    try:
        item = m.snapshot()["items"][0]
        assert item["status"] == "queued"
        # 排队的原因可能是"空间不够"，但状态必须已经从 running 归零
        assert item["done"] == 0
    finally:
        m.stop()


def test_api_endpoints_roundtrip(tmp_path, monkeypatch):
    """端点层的字段名/路径拼错在管理器测试里看不出来，这里走一遍真请求。"""
    from fastapi.testclient import TestClient

    from tagger.web import app as app_mod

    monkeypatch.setattr(hf_source, "free_bytes", lambda p: 100 * 1024 ** 3)
    monkeypatch.setattr(hf_source, "download_shard", _fake_ok)
    m = HfDownloads(tmp_path / "cache", state_path=tmp_path / "state.json")
    monkeypatch.setattr(app_mod, "DOWNLOADS", m)
    client = TestClient(app_mod.create_app(ui_dist=tmp_path / "no-ui"))
    try:
        assert client.get("/api/downloads").status_code == 200
        res = client.post("/api/downloads/start", json={
            "repo": "org/ds", "files": ["a.tar"], "sizes": {"a.tar": 100}})
        assert res.status_code == 202, res.text
        assert len(res.json()["created"]) == 1
        assert _wait(lambda: client.get("/api/downloads").json()["items"][0][
            "status"] == "done")
        assert client.post("/api/downloads/clear").json()["removed"] == 1
        cached = client.get("/api/downloads/cached?repo=org/ds").json()
        assert [f["filename"] for f in cached["files"]] == ["a.tar"]
        # 空仓库名要 400，不是 500 也不是静默成功
        assert client.post("/api/downloads/start", json={"repo": "", "files": []}).status_code == 400
    finally:
        m.stop()


def test_cached_lists_ready_files_only(tmp_path, monkeypatch):
    monkeypatch.setattr(hf_source, "free_bytes", lambda p: 10 ** 9)
    m = HfDownloads(tmp_path / "cache", state_path=tmp_path / "state.json")
    try:
        base = hf_source.cache_dir_for("org/ds", tmp_path / "cache")
        (base / "sub").mkdir(parents=True)
        (base / "sub" / "part-0.parquet").write_bytes(b"x" * 10)
        (base / "a.tar.part").write_bytes(b"y" * 5)     # 半截文件不算就绪
        names = [f["filename"] for f in m.cached("org/ds")]
        assert names == ["sub/part-0.parquet"]
    finally:
        m.stop()
