"""产物溯源字段（文档 V0.2 §8）：`caption_language` / `tags_original` /
`annotation_model` / `annotation_version` / `source_revision`。

这些字段的价值全在"事后能查"，所以测试的重点不是"字段存在"，而是
**值与实际行为一致**：

1. `caption_language` 必须和真正用的那份指令一致（选中文却记 en 是最坏的错）；
2. 同一张图重跑得到同一个语言（否则断点续跑会拼出两批不一样的数据）；
3. `tags_original` 是原 Tag 全量，不是新生成的那份。
"""

from __future__ import annotations

import hashlib
from types import SimpleNamespace

from tagger.artist import ArtistRule
from tagger.client import StageTimer, TaggerClient, TaskRow
from tagger.config import OutputSpec
from tagger.quality import QualityGate, QualityPolicy


def _client(*, zh_ratio: float = 0.0) -> TaggerClient:
    return TaggerClient(
        base_url="http://127.0.0.1:1",      # 不会真的发请求
        model_name="tagger",
        output=OutputSpec(mode="both"),
        temperature=0.2, top_p=0.9, max_tokens=1024, timeout_s=1, max_attempts=1,
        gate=QualityGate(QualityPolicy(), verbose=False),
        prov_base={"model_id": "qwen-vl-8b", "model_revision": "rev123"},
        artist_rule=ArtistRule(),
        stage=StageTimer(),
        caption_zh_ratio=zh_ratio,
    )


def _task(**kw) -> TaskRow:
    kw.setdefault("shard", "shard-000001.tar")
    kw.setdefault("image_id", "8349000")
    kw.setdefault("file", "8349000.jpg")
    return TaskRow(**kw)


def test_语言字段与真正用的指令一致():
    en = _client(zh_ratio=0.0)
    assert en._wants_zh(_task()) is False          # 没有中文提示词就是英文
    assert en._annotation_meta(_task())["caption_language"] == "en"

    zh = _client(zh_ratio=1.0)
    assert zh._wants_zh(_task()) is True
    assert zh._annotation_meta(_task())["caption_language"] == "zh"


def test_同一张图重跑语言不变():
    """按 (seed, image_id) 抽签，不按处理顺序：续跑一次不能换一批图出中文。"""
    client = _client(zh_ratio=0.5)
    task = _task(image_id="8349001")
    first = client._wants_zh(task)
    assert all(client._wants_zh(task) is first for _ in range(5))

    # 换个 id 有机会翻转，否则这测试等于没测抽签
    seen = {client._wants_zh(_task(image_id=str(i))) for i in range(200)}
    assert seen == {True, False}


def test_原Tag全量落盘():
    task = _task(ref_tags=("1girl", "blue_hair", "sitting"))
    meta = _client(zh_ratio=0.0)._annotation_meta(task)
    assert meta["tags_original"] == ["1girl", "blue_hair", "sitting"]

    assert _client()._annotation_meta(_task())["tags_original"] == []


def test_模型与版本可溯源():
    """`annotation_version` = 模型 revision + prompt 指纹。

    prompt 只有一个版本，没有 v1/v2 这种编号了；要区分"哪套指令"靠
    内容哈希（改一个字就变），不靠人手记得去 bump 的数字。
    """
    c = _client(zh_ratio=0.0)
    meta = c._annotation_meta(_task())
    assert meta["annotation_model"] == "qwen-vl-8b"
    sha = hashlib.sha256(c.prompt.encode("utf-8")).hexdigest()[:12]
    assert meta["annotation_version"] == f"rev123+{sha}"


def test_来源revision跟着任务走():
    task = _task(source_revision="hf:abc1234")
    assert _client()._annotation_meta(task)["source_revision"] == "hf:abc1234"

    # 没给就留空，不编一个"unknown"出来——空表示"没记录"，unknown 会被当成值
    assert _client()._annotation_meta(_task())["source_revision"] == ""


def test_合并总表带上溯源字段(tmp_path):
    """分片产物里带着这五个字段，合并总表不能丢——文档 §8 验收的是最终表。"""
    import json

    from tagger.merge import build_rows, collect

    root = tmp_path / "shard"
    root.mkdir()
    payload = {
        "image_id": "a",
        "tag": "1girl, blue_hair",
        "caption": "一个蓝发女孩",
        "caption_language": "zh",
        "tags_original": ["1girl", "blue_hair"],
        "annotation_model": "qwen-vl-8b",
        "annotation_version": "rev123+p3",
        "source_revision": "hf:abc",
    }
    (root / "a-tag.json").write_text(
        json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    rows = list(build_rows(collect([root])))
    assert len(rows) == 1
    row = rows[0]
    assert row["caption_language"] == "zh"
    assert row["tags_original"] == ["1girl", "blue_hair"]
    assert row["annotation_model"] == "qwen-vl-8b"
    assert row["annotation_version"] == "rev123+p3"
    assert row["source_revision"] == "hf:abc"


def test_老产物缺字段时列仍在(tmp_path):
    """没有溯源字段的旧产物也要能合并：五列写空值，不省略键。

    jsonl 省略键还能读，转成 parquet 时各行键集合不同会直接失败。
    """
    import json

    from tagger.merge import build_rows, collect

    root = tmp_path / "old"
    root.mkdir()
    (root / "b-tag.json").write_text(
        json.dumps({"image_id": "b", "tag": "1girl"}), encoding="utf-8")

    row = next(build_rows(collect([root])))
    assert row["caption_language"] == ""
    assert row["tags_original"] == []
    assert row["annotation_model"] == ""


def test_nl产物带溯源字段():
    client = _client(zh_ratio=0.0)
    task = _task(ref_tags=("1girl",))
    verdict = SimpleNamespace(score=1.0, reasons=[])
    payload = client._nl_payload(task, "a girl sitting.", 3, 0.2, 12, 1, verdict)

    assert payload["caption_language"] == "en"
    assert payload["tags_original"] == ["1girl"]
    assert payload["annotation_model"] == "qwen-vl-8b"
    assert payload["source_revision"] == ""
