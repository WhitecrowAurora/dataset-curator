import { useCallback, useEffect, useState } from 'react'
import {
  Boxes,
  ChartSpline,
  Copy,
  Download,
  History,
  Layers,
  ListChecks,
  Merge,
  Package,
  PlayCircle,
  PlusCircle,
  Settings2,
  ShieldCheck,
  UploadCloud,
} from 'lucide-react'
import { api, type Health } from './lib/api'
import { applyTheme, readTheme, type Theme } from './lib/theme'
import { readProgressInterval, writeProgressInterval } from './lib/prefs'
import { AppShell } from './layout/AppShell'
import type { NavItem } from './layout/Sidebar'
import { NewJob } from './pages/NewJob'
import { RunJob } from './pages/RunJob'
import { Results } from './pages/Results'
import { History as HistoryPage } from './pages/History'
import { Stats } from './pages/Stats'
import { Packaging } from './pages/Packaging'
import { Upload } from './pages/Upload'
import { Dedup } from './pages/Dedup'
import { Models } from './pages/Models'
import { Downloads } from './pages/Downloads'
import { TagManage } from './pages/TagManage'
import { Deps } from './pages/Deps'
import { Settings } from './pages/Settings'
import { GlobalProgress } from './components/GlobalProgress'
import { SelfCheckDialog } from './components/SelfCheckDialog'
import { ResumeBanner } from './components/ResumeBanner'

// 手写 hash 路由：七个页面、零依赖，比引 react-router 更省事也更不容易踩版本。
// 用 hash 而不是 history 还有一个实际好处——右键"在新标签打开"不会 404。

type Route =
  | { name: 'new' }
  | { name: 'run'; id: string }
  | { name: 'results'; id: string }
  | { name: 'upload' }
  | { name: 'dedup' }
  | { name: 'packaging' }
  | { name: 'models' }
  | { name: 'downloads' }
  | { name: 'tag-manage' }
  | { name: 'stats' }
  | { name: 'history' }
  | { name: 'deps' }
  | { name: 'settings' }

const LAST_KEY = 'tagger-last-job'

function parseRoute(hash: string): Route {
  const path = hash.replace(/^#/, '') || '/'
  const match = path.match(/^\/(run|results)\/([\w-]+)$/)
  if (match) return { name: match[1] as 'run' | 'results', id: match[2] }
  if (path === '/history') return { name: 'history' }
  if (path === '/upload') return { name: 'upload' }
  if (path === '/dedup') return { name: 'dedup' }
  if (path === '/packaging') return { name: 'packaging' }
  if (path === '/models') return { name: 'models' }
  if (path === '/downloads') return { name: 'downloads' }
  if (path === '/tag-manage') return { name: 'tag-manage' }
  if (path === '/stats') return { name: 'stats' }
  if (path === '/deps') return { name: 'deps' }
  if (path === '/settings') return { name: 'settings' }
  return { name: 'new' }
}

function go(path: string) {
  location.hash = path
}

export default function App() {
  const [route, setRoute] = useState<Route>(() => parseRoute(location.hash))
  const [health, setHealth] = useState<Health | null>(null)
  const [theme, setTheme] = useState<Theme>(() => readTheme())
  // 自检是弹窗不是页面：它只回答"这台机器现在能不能干活"，
  // 没有需要反复回来看的状态，占一个路由位不值得。
  const [selfCheckOpen, setSelfCheckOpen] = useState(false)
  // 底部进度条的轮询间隔，存 localStorage：这是"看着舒服"的本机偏好，
  // 不该跟服务端配置漂移。默认 5s。
  const [progressInterval, setProgressInterval] = useState(() => readProgressInterval())
  const [lastJobId, setLastJobId] = useState<string>(() => {
    try {
      return localStorage.getItem(LAST_KEY) ?? ''
    } catch {
      return ''
    }
  })

  useEffect(() => {
    applyTheme(theme)
  }, [theme])

  useEffect(() => {
    const onChange = () => setRoute(parseRoute(location.hash))
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])

  useEffect(() => {
    const tick = () => api.health().then(setHealth).catch(() => setHealth(null))
    tick()
    const t = window.setInterval(tick, 15000)
    return () => window.clearInterval(t)
  }, [])

  // 记住最近一个任务：侧栏的"结果"和顶栏状态都靠它，刷新页面也还能回到上次的活儿。
  useEffect(() => {
    if (route.name !== 'run' && route.name !== 'results') return
    setLastJobId(route.id)
    try {
      localStorage.setItem(LAST_KEY, route.id)
    } catch {
      // 存不了就只在内存里记着，不影响使用
    }
  }, [route])

  const openJob = useCallback((id: string) => go(`/run/${id}`), [])

  const changeProgressInterval = useCallback((ms: number) => {
    setProgressInterval(ms)
    writeProgressInterval(ms)
  }, [])

  const runningId = health?.running_job ?? (route.name === 'run' ? route.id : '') ?? ''
  const resultsId = route.name === 'results' ? route.id : lastJobId

  const items: NavItem[] = [
    {
      key: 'new',
      label: '新建任务',
      icon: <PlusCircle size={15} />,
      active: route.name === 'new',
      onClick: () => go('/'),
    },
    {
      key: 'selfcheck',
      label: '部署自检',
      icon: <ShieldCheck size={15} />,
      active: selfCheckOpen,
      hint: '装完点一下：逐项验证环境、目录与服务，并真跑一张图',
      onClick: () => setSelfCheckOpen(true),
    },
    {
      key: 'deps',
      label: '依赖检测',
      icon: <Package size={15} />,
      active: route.name === 'deps',
      hint: '逐个查看依赖装没装、版本对不对，可单独装卸',
      onClick: () => go('/deps'),
    },
    {
      key: 'models',
      label: '模型管理',
      icon: <Layers size={15} />,
      active: route.name === 'models',
      hint: '增删可选模型（NL 的 Qwen-VL / tag 分类头）',
      onClick: () => go('/models'),
    },
    {
      key: 'downloads',
      label: '下载',
      icon: <Download size={15} />,
      active: route.name === 'downloads',
      hint: '提前把 HF 分片备到本地，打标任务直接复用、打完即删',
      onClick: () => go('/downloads'),
    },
    {
      key: 'tag-manage',
      label: '打标管理',
      icon: <Merge size={15} />,
      active: route.name === 'tag-manage',
      hint: '把多个 json 合成一个单体 json（tag/nl 按图配对、字段取并集）',
      onClick: () => go('/tag-manage'),
    },
    {
      key: 'run',
      label: '运行中',
      icon: <PlayCircle size={15} />,
      active: route.name === 'run',
      disabled: !runningId,
      hint: runningId ? '查看正在跑的任务' : '当前没有正在跑的任务',
      onClick: () => runningId && openJob(runningId),
    },
    {
      key: 'history',
      label: '历史任务',
      icon: <History size={15} />,
      active: route.name === 'history',
      onClick: () => go('/history'),
    },
    {
      key: 'stats',
      label: '统计',
      icon: <ChartSpline size={15} />,
      active: route.name === 'stats',
      hint: '通过率 / 失败率 / 质检分的分桶趋势',
      onClick: () => go('/stats'),
    },
    {
      key: 'dedup',
      label: '去重',
      icon: <Copy size={15} />,
      active: route.name === 'dedup',
      hint: '发分包前查重复图，产出排除清单',
      onClick: () => go('/dedup'),
    },
    {
      key: 'packaging',
      label: '数据打包',
      icon: <Boxes size={15} />,
      active: route.name === 'packaging',
      hint: '分包 / 拼接 / 封包，与打标分开走',
      onClick: () => go('/packaging'),
    },
    {
      key: 'upload',
      label: '回传',
      icon: <UploadCloud size={15} />,
      active: route.name === 'upload',
      hint: '把处理好的 parquet 传到汇总机',
      onClick: () => go('/upload'),
    },
    {
      key: 'results',
      label: '查看结果',
      icon: <ListChecks size={15} />,
      active: route.name === 'results',
      disabled: !resultsId,
      hint: resultsId ? '浏览最近一次任务的产物' : '还没有跑过任务',
      onClick: () => resultsId && go(`/results/${resultsId}`),
    },
    {
      key: 'settings',
      label: '设置',
      icon: <Settings2 size={15} />,
      active: route.name === 'settings',
      hint: '界面偏好：底栏刷新频率等',
      onClick: () => go('/settings'),
    },
  ]

  return (
    <AppShell
      items={items}
      health={health}
      theme={theme}
      onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
      footer={
        <p className="px-1 text-[10px] leading-relaxed text-lx-dim">
          本机服务 · 只监听 127.0.0.1
        </p>
      }
      statusBar={
        <GlobalProgress interval={progressInterval} onOpen={go} />
      }
    >
      {/* 放在所有页面之前：用户下次打开往往就是来接着昨天那个活儿的，
          不该先去某个页面里找一圈。 */}
      <ResumeBanner onOpen={openJob} />

      {/* 新建页常驻挂载，只是藏起来。卸载再挂载会把所有 useState 清零，
          用户去「模型管理」看一眼回来就得重填一遍路径和参数。 */}
      <div className={route.name === 'new' ? undefined : 'hidden'}>
        <NewJob
          active={route.name === 'new'}
          onStarted={openJob}
          onOpenModels={() => go('/models')}
        />
      </div>
      {route.name === 'models' && <Models />}
      {route.name === 'downloads' && <Downloads />}
      {route.name === 'tag-manage' && <TagManage />}
      {route.name === 'run' && (
        <RunJob
          jobId={route.id}
          onResults={() => go(`/results/${route.id}`)}
          onNew={() => go('/')}
        />
      )}
      {route.name === 'results' && (
        <Results jobId={route.id} onBack={() => go(`/run/${route.id}`)} />
      )}
      {route.name === 'history' && (
        <HistoryPage
          currentId={runningId || lastJobId}
          onOpenRun={openJob}
          onOpenResults={(id) => go(`/results/${id}`)}
        />
      )}
      {route.name === 'upload' && <Upload />}
      {route.name === 'dedup' && <Dedup />}
      {route.name === 'packaging' && <Packaging />}
      {route.name === 'stats' && <Stats />}
      {route.name === 'deps' && <Deps />}
      {route.name === 'settings' && (
        <Settings
          progressInterval={progressInterval}
          onProgressInterval={changeProgressInterval}
        />
      )}

      <SelfCheckDialog open={selfCheckOpen} onClose={() => setSelfCheckOpen(false)} />
    </AppShell>
  )
}
