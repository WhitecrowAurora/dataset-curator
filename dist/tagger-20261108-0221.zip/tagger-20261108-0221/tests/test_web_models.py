"""模型管理：清单读写 + 覆盖合并。

三条最值得钉的：
1. **覆盖只动两段**（models / tagging.models），分档（tiers）不该被连带改；
2. **只存差异**——配置里原样的条目一条都不写进覆盖文件，否则第一次保存就把
   tiers.yaml 冻结成快照，以后改配置永远不生效；
3. **分档在用的模型不许删**，否则要等到起服务时才炸，报错还指向别处。
"""

from __future__ import annotations

import json
import time

import pytest
from fastapi.testclient import TestClient

from tagger import config as config_mod
from tagger.web.app import create_app


@pytest.fixture()
def client(tmp_path, monkeypatch):
    # 覆盖文件指到临时目录：跑测试绝不能碰仓库里真实的 configs/models.json
    monkeypatch.setattr(config_mod, "MODEL_OVERLAY", str(tmp_path / "models.json"))
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def test_catalog_comes_from_config(client):
    data = client.get("/api/models").json()
    keys = {m["key"] for m in data["vlm"]}
    assert {"qwen3vl-4b", "qwen3vl-8b"} <= keys
    assert {m["key"]: m["source"] for m in data["vlm"]} == {
        m["key"]: "config" for m in data["vlm"]}
    assert data["tag"] and all(t["repo"] for t in data["tag"])
    # 分档在用的模型要标出来：页面据此禁用删除
    # 默认三档都指向无审查版（原版遇 NSFW 会整张拒答，等于漏标）
    by_key = {m["key"]: m for m in data["vlm"]}
    assert by_key["qwen3vl-8b-abliterated"]["tiers"] == ["high-32g"]
    assert by_key["qwen3vl-4b-abliterated"]["tiers"] == ["low-16g", "mid-24g"]
    assert by_key["qwen3vl-8b"]["tiers"] == []
    assert data["overlay_exists"] is False


def test_save_stores_only_diffs(client, tmp_path):
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm.append({
        "key": "my-4b", "path": "local/my-4b", "precision": "int4",
        "family": "qwen3vl", "revision": "", "quantized_path": "", "note": "自测用",
    })
    tag = [dict(t) for t in data["tag"]]
    got = client.put("/api/models", json={"vlm": vlm, "tag": tag}).json()
    assert "my-4b" in {m["key"] for m in got["vlm"]}

    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert list(doc["vlm"]) == ["my-4b"], "配置里原样的条目不该被复制进覆盖文件"
    assert doc["tag"] == {}
    assert doc["hidden"] == [] and doc["tag_hidden"] == []
    assert doc["notes"] == {"vlm:my-4b": "自测用"}

    # 合并后 CLI / 打标 / 起服务走的是同一个入口，都该看见这个模型
    table = config_mod.load_tier_table()
    assert "my-4b" in table["models"]
    # 新建任务页的下拉来自 /api/defaults，必须一起看见
    defaults = client.get("/api/defaults").json()
    assert "my-4b" in {m["key"] for m in defaults["vllm_models"]}
    assert {t["name"] for t in table["tiers"]} >= {"low-16g", "mid-24g", "high-32g"}
    assert config_mod.load_tier_table(overlay=False)["models"].get("my-4b") is None


def test_cannot_remove_model_referenced_by_tier(client):
    data = client.get("/api/models").json()
    vlm = [m for m in data["vlm"] if m["key"] != "qwen3vl-8b-abliterated"]
    r = client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    assert r.status_code == 400
    assert "不能删" in r.json()["detail"]


def test_tag_models_round_trip_and_hide(client, tmp_path):
    data = client.get("/api/models").json()
    tag = [dict(t) for t in data["tag"]]
    tag.append({"backend": "onnx", "repo": "local/onnx-tagger", "note": ""})
    tag = [t for t in tag if t["backend"] != "cl-tagger-v2"]      # 顺手藏掉一个
    client.put("/api/models", json={"vlm": data["vlm"], "tag": tag})

    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["tag"] == {"onnx": "local/onnx-tagger"}
    assert doc["tag_hidden"] == ["cl-tagger-v2"]

    got = client.get("/api/models").json()
    assert {t["backend"] for t in got["tag"]} == {"pixai", "wd-eva02", "onnx"}
    assert {t["backend"]: t["source"] for t in got["tag"]}["onnx"] == "managed"


def test_must_keep_at_least_one_nl_model(client):
    data = client.get("/api/models").json()
    r = client.put("/api/models", json={"vlm": [], "tag": data["tag"]})
    assert r.status_code == 400
    assert "至少保留一个" in r.json()["detail"]


def test_bad_vlm_entry_is_rejected(client):
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm.append({"key": "novalue", "path": ""})
    r = client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    assert r.status_code == 400
    assert "缺少权重路径" in r.json()["detail"]


# ---- 权重下载 / 删除 / 开目录


@pytest.fixture()
def dl_root(tmp_path, monkeypatch):
    """把"模型根目录"指到临时目录：真删真下都不会碰仓库里的 models/。"""
    from tagger.web import downloads as dl_mod

    root = tmp_path / "models"
    monkeypatch.setattr(dl_mod, "MODELS_ROOT", root)
    monkeypatch.setattr(dl_mod, "DOWNLOADS", dl_mod.DownloadManager(models_root=root))
    def unexpected_download(*args, **kwargs):
        raise AssertionError("测试必须模拟模型下载，不能访问真实仓库")
    monkeypatch.setattr(dl_mod, "_list_files", unexpected_download)
    return root


def test_uncensored_variants_are_shipped(client):
    """无审查版必须开箱可选，否则打 NSFW 图会整张漏标（模型拒答不报错）。"""
    keys = {m["key"] for m in client.get("/api/models").json()["vlm"]}
    assert {"qwen3vl-4b-abliterated", "qwen3vl-8b-abliterated"} <= keys


def test_local_state_and_download_repo(client, dl_root):
    data = client.get("/api/models").json()
    by_key = {m["key"]: m for m in data["vlm"]}
    entry = by_key["qwen3vl-4b"]
    # dl_root 把根目录指到了临时目录，所以这里只校验末两段
    from pathlib import Path

    assert Path(entry["local_dir"]).parts[-2:] == ("nl", "qwen3vl-4b")
    assert entry["exists"] is False and entry["local_bytes"] == 0
    assert entry["download_repo"] == "Qwen/Qwen3-VL-4B-Instruct"
    # tag 的默认目录对齐现有习惯：models/<backend>
    tag = {t["backend"]: t for t in data["tag"]}["wd-eva02"]
    assert Path(tag["local_dir"]).name == "wd-eva02"
    assert tag["download_repo"].startswith("ashen-sensored/")


def test_local_dir_is_persisted(client, tmp_path):
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm[0]["local_dir"] = "models/nl/custom-dir"
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["dirs"] == {f"vlm:{vlm[0]['key']}": "models/nl/custom-dir"}
    again = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}
    assert again[vlm[0]["key"]]["local_dir"] == "models/nl/custom-dir"


def test_download_reports_progress_then_shows_files(client, dl_root, monkeypatch):
    """下载完要能看出"已落地"：exists/local_bytes 是页面切到删除按钮的依据。"""
    from tagger.web import downloads as dl_mod

    monkeypatch.setattr(dl_mod, "_list_files", lambda repo, proxy="": [("config.json", 12)])
    seen: list[dict] = []

    def fake_fetch(task, name, size, done):
        (task.dest / name).parent.mkdir(parents=True, exist_ok=True)
        (task.dest / name).write_bytes(b"x" * size)
        task.tick(done + size)
        seen.append(task.state())
        return done + size

    monkeypatch.setattr(dl_mod, "_fetch", fake_fetch)
    key = "qwen3vl-4b"
    r = client.post("/api/models/download", json={"kind": "vlm", "key": key})
    assert r.status_code == 200
    for _ in range(200):
        state = dl_mod.DOWNLOADS.state_of("vlm", key)
        if state and state["status"] in ("done", "error"):
            break
        time.sleep(0.01)
    assert state and state["status"] == "done", state
    assert state["bytes_total"] == 12 and state["bytes_done"] == 12
    assert state["percent"] == 100.0
    assert (dl_root / "nl" / key / "config.json").is_file()
    entry = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}[key]
    assert entry["exists"] is True and entry["local_bytes"] == 12


def test_download_needs_a_repo(client, dl_root, tmp_path):
    """本地目录没有可下载的东西：要说清楚，而不是起个必然失败的任务。"""
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm[0]["path"] = str(tmp_path / "local-weights")
    vlm[0]["download_repo"] = ""
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    r = client.post("/api/models/download", json={"kind": "vlm", "key": vlm[0]["key"]})
    assert r.status_code == 400
    assert "仓库" in r.json()["detail"]


def test_delete_refuses_paths_outside_models_root(client, dl_root, tmp_path):
    """local_dir 填到素材目录上时，"删除模型"不能变成删素材。"""
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "keep.jpg").write_bytes(b"x")
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm[0]["local_dir"] = str(outside)
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    r = client.post("/api/models/localfiles/delete", json={"kind": "vlm", "key": vlm[0]["key"]})
    assert r.status_code == 400
    assert "不在模型目录" in r.json()["detail"]
    assert (outside / "keep.jpg").is_file(), "越界目录被删了"


# ---- 下载代理


def test_normalize_proxy_fills_scheme():
    from tagger.web.downloads import normalize_proxy, socks_ready

    assert normalize_proxy("") == ""
    assert normalize_proxy("  127.0.0.1:7890 ") == "http://127.0.0.1:7890"
    assert normalize_proxy("http://h:1") == "http://h:1"
    if socks_ready():
        assert normalize_proxy("socks5://h:1080") == "socks5://h:1080"
    with pytest.raises(ValueError):
        normalize_proxy("ftp://h:21")


def test_proxy_persists_and_survives_table_save(client, tmp_path):
    r = client.put("/api/models/proxy", json={"url": "127.0.0.1:7890"})
    assert r.status_code == 200
    assert r.json()["proxy"] == "http://127.0.0.1:7890"

    # 整表保存不能把代理抹掉：改一次模型清单就断网，用户会以为是网络坏了
    data = client.get("/api/models").json()
    client.put("/api/models", json={"vlm": data["vlm"], "tag": data["tag"]})
    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["proxy"] == "http://127.0.0.1:7890"
    assert client.get("/api/models").json()["proxy"] == "http://127.0.0.1:7890"

    # 清空 = 直连
    client.put("/api/models/proxy", json={"url": ""})
    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert "proxy" not in doc
    assert client.get("/api/models").json()["proxy"] == ""


def test_proxy_rejects_unknown_scheme(client):
    r = client.put("/api/models/proxy", json={"url": "ftp://1.2.3.4:21"})
    assert r.status_code == 400
    assert "不支持" in r.json()["detail"]


def test_proxy_test_returns_reason_instead_of_raising(client):
    r = client.post("/api/models/proxy/test", json={"url": "ftp://1.2.3.4:21"})
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is False and "不支持" in body["error"]


def test_delete_removes_downloaded_files(client, dl_root):
    key = "qwen3vl-4b"
    target = dl_root / "nl" / key
    target.mkdir(parents=True)
    (target / "model.safetensors").write_bytes(b"x" * 8)
    assert client.get("/api/models").json()  # 让 catalog 读到 exists
    r = client.post("/api/models/localfiles/delete", json={"kind": "vlm", "key": key})
    assert r.status_code == 200
    assert not target.exists()
    entry = {m["key"]: m for m in r.json()["vlm"]}[key]
    assert entry["exists"] is False and entry["local_bytes"] == 0
