"""打标管理：多 json 合并成一个单体 json。

最要紧的两条：tag 与 nl 两份产物要按 image_id 合成**一条**（不是两倍条数），
以及合并后写出的 json 必须能被 `json.load` 读回来（流式写逗号最容易写错）。
"""

from __future__ import annotations

import json

import pytest

from tagger import tag_manage as tm


def _tag(image_id: str, **kw) -> dict:
    row = {"image_id": image_id, "tag": "1girl, solo", "tags": [["1girl", 0.99]],
           "artist": "a", "provenance": {"model_id": "m"}, "ts": 1.0}
    row.update(kw)
    return row


def _nl(image_id: str, **kw) -> dict:
    row = {"image_id": image_id, "caption": "a girl alone", "score": 0.9,
           "artist": "a", "provenance": {"model_id": "m"}, "ts": 2.0}
    row.update(kw)
    return row


def test_load_records_accepts_three_shapes(tmp_path):
    arr = tmp_path / "a.json"
    arr.write_text(json.dumps([{"image_id": "1"}, {"image_id": "2"}]), encoding="utf-8")
    assert len(tm.load_records(arr)) == 2

    lines = tmp_path / "b.jsonl"
    lines.write_text('{"image_id":"3"}\n{"image_id":"4"}\n', encoding="utf-8")
    assert [r["image_id"] for r in tm.load_records(lines)] == ["3", "4"]

    one = tmp_path / "x-0001-tag.json"
    one.write_text(json.dumps({"image_id": "5", "tag": "t"}), encoding="utf-8")
    assert tm.load_records(one) == [{"image_id": "5", "tag": "t"}]

    # 包了一层壳的导出也认
    wrapped = tmp_path / "c.json"
    wrapped.write_text(json.dumps({"records": [{"image_id": "6"}]}), encoding="utf-8")
    assert tm.load_records(wrapped) == [{"image_id": "6"}]


def test_bad_json_reports_position(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text('{"image_id":"1"}\n{not json}\n', encoding="utf-8")
    with pytest.raises(ValueError, match="第 2 行"):
        tm.load_records(bad)


def test_tag_and_nl_merge_into_one_record():
    rows = [_tag("a-1"), _nl("a-1"), _tag("a-2")]
    table, stats = tm.merge_records(rows)
    assert sorted(table) == ["a-1", "a-2"]
    merged = table["a-1"]
    # 字段是并集：tag 侧的 tags 与 nl 侧的 caption 都要在
    assert merged["tag"] == "1girl, solo"
    assert merged["tags"] == [["1girl", 0.99]]
    assert merged["caption"] == "a girl alone"
    assert merged["score"] == 0.9
    assert stats["records_read"] == 3
    assert stats["duplicates"] == 1


def test_conflict_keeps_first_by_default_and_counts():
    rows = [_tag("a-1", artist="first"), _nl("a-1", artist="second")]
    table, stats = tm.merge_records(rows)
    assert table["a-1"]["artist"] == "first"
    assert stats["conflicts"] >= 1

    table, _ = tm.merge_records(rows, on_conflict="last")
    assert table["a-1"]["artist"] == "second"


def test_require_filters_incomplete_pairs():
    rows = [_tag("a-1"), _nl("a-1"), _tag("a-2")]
    table, stats = tm.merge_records(rows, require="both")
    assert "a-2" not in table          # 只有 tag、没有 caption
    assert stats["skipped"] == 1


def test_missing_key_is_skipped_not_crashed():
    table, stats = tm.merge_records([{"tag": "x"}, _tag("a-1")])
    assert list(table) == ["a-1"]
    assert stats["skipped"] == 1


def test_merge_files_writes_valid_json_array(tmp_path):
    tag_dir = tmp_path / "tags"
    tag_dir.mkdir()
    (tag_dir / "a-1-tag.json").write_text(json.dumps(_tag("a-1")), encoding="utf-8")
    (tag_dir / "a-1-nl.json").write_text(json.dumps(_nl("a-1")), encoding="utf-8")
    (tag_dir / "a-2-tag.json").write_text(json.dumps(_tag("a-2")), encoding="utf-8")

    out = tmp_path / "merged.json"
    files = [p["path"] for p in tm.scan(tag_dir)]
    report = tm.merge_files(files, out)

    assert report.records_out == 2
    assert report.inputs == 3
    assert report.bad_files == []
    rows = json.loads(out.read_text(encoding="utf-8"))
    assert isinstance(rows, list) and len(rows) == 2
    assert rows[0]["image_id"] == "a-1"
    assert rows[0]["caption"] == "a girl alone"
    assert report.bytes > 0
    assert "caption" in report.fields and "tag" in report.fields


def test_full_format_puts_core_fields_first(tmp_path):
    # nl 先读到（文件名排序），但输出里 image_id 仍该在最前——核对时要一眼看到
    src = tmp_path / "all.json"
    src.write_text(json.dumps([
        _nl("a-1") | {"image_path": "p"},
        _tag("a-1") | {"image_path": "p"},
    ]), encoding="utf-8")
    out = tmp_path / "merged.json"
    tm.merge_files([src], out)
    row = json.loads(out.read_text(encoding="utf-8"))[0]
    assert list(row)[:4] == ["image_id", "image_path", "caption", "tag"]


def test_train_format_keeps_only_four_fields(tmp_path):
    src = tmp_path / "all.json"
    src.write_text(json.dumps([_tag("a-1") | {"caption": "c"}]), encoding="utf-8")
    out = tmp_path / "train.json"
    tm.merge_files([src], out, fmt="train")

    row = json.loads(out.read_text(encoding="utf-8"))[0]
    assert set(row) == set(tm.TRAIN_FIELDS)
    assert row["image_path"] == ""      # 缺字段补空串，不写 null 让下游少一道判空


def test_jsonl_output_and_empty_input(tmp_path):
    src = tmp_path / "all.json"
    src.write_text(json.dumps([_tag("a-1")]), encoding="utf-8")
    out = tmp_path / "all.jsonl"
    tm.merge_files([src], out, as_jsonl=True)
    assert json.loads(out.read_text(encoding="utf-8").strip())["image_id"] == "a-1"

    empty = tmp_path / "empty.json"
    empty.write_text("[]", encoding="utf-8")
    out2 = tmp_path / "empty-out.json"
    report = tm.merge_files([empty], out2)
    assert report.records_out == 0
    assert json.loads(out2.read_text(encoding="utf-8")) == []


def test_all_inputs_bad_raises(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("{", encoding="utf-8")
    with pytest.raises(tm.TagManageError, match="没有一个文件能读"):
        tm.merge_files([bad, tmp_path / "missing.json"], tmp_path / "out.json")


def test_scan_reports_kind_and_empty(tmp_path):
    (tmp_path / "a-1-tag.json").write_text("{}", encoding="utf-8")
    (tmp_path / "a-1-nl.json").write_text("", encoding="utf-8")
    (tmp_path / "other.json").write_text("{}", encoding="utf-8")
    # 非 json 不该被扫进来
    (tmp_path / "a-1.jpg").write_bytes(b"x")
    rows = {r["name"]: r for r in tm.scan(tmp_path)}
    assert set(rows) == {"a-1-tag.json", "a-1-nl.json", "other.json"}
    assert rows["a-1-tag.json"]["kind"] == "tag"
    assert rows["a-1-nl.json"]["kind"] == "nl"
    assert rows["a-1-nl.json"]["empty"] is True


def test_image_root_overrides_path(tmp_path):
    src = tmp_path / "all.json"
    src.write_text(json.dumps([_tag("a-1") | {"caption": "c"}]), encoding="utf-8")
    out = tmp_path / "merged.json"

    # 留空：一个字都不许改，尤其不能凭空造一个 image_path 出来
    tm.merge_files([src], out)
    assert "image_path" not in json.loads(out.read_text(encoding="utf-8"))[0]

    tm.merge_files([src], out, image_root="/images/fanbox/")
    row = json.loads(out.read_text(encoding="utf-8"))[0]
    assert row["image_path"] == "/images/fanbox/a-1.jpg"   # 尾部斜杠不叠成 //

    # 扩展名不带点也能用
    tm.merge_files([src], out, image_root="/mnt/d/pony", image_ext="png")
    assert json.loads(out.read_text(encoding="utf-8"))[0]["image_path"] == "/mnt/d/pony/a-1.png"

    # train 口径同样生效（image_path 本来就是四项之一）
    tm.merge_files([src], out, fmt="train", image_root="/images/fanbox")
    assert json.loads(out.read_text(encoding="utf-8"))[0]["image_path"] == "/images/fanbox/a-1.jpg"


def test_preview_uses_same_rewrite(tmp_path):
    src = tmp_path / "all.json"
    src.write_text(json.dumps([_tag("a-1")]), encoding="utf-8")
    rows = tm.preview([src], image_root="/images/fanbox")
    assert rows[0]["image_path"] == "/images/fanbox/a-1.jpg"


def test_rel_path_restores_mirror_subdir(tmp_path):
    """mirror 布局的子目录靠产物里的 rel_path 还原，不能只剩扁平 id。"""
    src = tmp_path / "all.json"
    src.write_text(json.dumps([
        _tag("sakura-000123") | {"rel_path": "artist_a/sakura/0001.jpg"},
    ]), encoding="utf-8")
    out = tmp_path / "merged.json"
    tm.merge_files([src], out, image_root="/images/fanbox")
    assert (json.loads(out.read_text(encoding="utf-8"))[0]["image_path"]
            == "/images/fanbox/artist_a/sakura/sakura-000123.jpg")

    # image_id 自己就带目录（散图按相对路径命名）：不能再叠一层 rel_path 目录
    src2 = tmp_path / "b.json"
    src2.write_text(json.dumps([
        _tag("sub/001") | {"rel_path": "sub/001.png"},
    ]), encoding="utf-8")
    tm.merge_files([src2], out, image_root="/images/fanbox")
    assert (json.loads(out.read_text(encoding="utf-8"))[0]["image_path"]
            == "/images/fanbox/sub/001.jpg")

    # hf:// 形态的 rel_path 不当目录用，退回扁平
    assert tm.rel_dir_of("hf://datasets/org/ds/shard.tar#a.jpg") == ""
    assert tm.rel_dir_of("dist-1.zip::a/b.jpg") == ""
    assert tm.rel_dir_of("0001.jpg") == ""


def test_parquet_artifact_input(tmp_path):
    """`--artifact-format parquet` 的产物要能直接合，不能只认 json。"""
    pytest.importorskip("pyarrow")
    from tagger.artifacts import ParquetSink

    sink = ParquetSink(tmp_path / "arts", rows_per_file=1)
    sink.add("a-1", _tag("a-1"), _nl("a-1"))
    sink.close()
    parquet = sorted((tmp_path / "arts").glob("artifacts-*.parquet"))[0]

    scanned = tm.scan(tmp_path / "arts")
    assert [r["kind"] for r in scanned] == ["parquet"]

    out = tmp_path / "merged.json"
    report = tm.merge_files([str(parquet)], out)
    assert report.inputs == 1
    assert report.records_out == 1
    row = json.loads(out.read_text(encoding="utf-8"))[0]
    assert row["caption"] == "a girl alone" and row["tag"] == "1girl, solo"


def test_batch_mode_pairs_across_files(tmp_path):
    """分桶模式最容易错的点：同一个 id 的 tag 与 nl 在不同文件里，必须仍配对。

    这也正是"按文件分批各自合并再拼"做不到的事。
    """
    a = tmp_path / "a.json"
    b = tmp_path / "b.json"
    a.write_text(json.dumps([_tag("k-1"), _tag("k-2")]), encoding="utf-8")
    b.write_text(json.dumps([_nl("k-1"), _nl("k-2")]), encoding="utf-8")
    out = tmp_path / "merged.json"
    report = tm.merge_files([a, b], out, batch_size=2)

    assert report.batched is True and report.buckets >= 2
    rows = {r["image_id"]: r for r in json.loads(out.read_text(encoding="utf-8"))}
    assert len(rows) == 2                      # 不是 4：配对成功
    for rid in ("k-1", "k-2"):
        assert rows[rid]["caption"] == "a girl alone"
        assert rows[rid]["tag"] == "1girl, solo"


def test_progress_reports_both_stages(tmp_path):
    a = tmp_path / "a.json"
    a.write_text(json.dumps([_tag(f"k-{i}") for i in range(10)]), encoding="utf-8")
    b = tmp_path / "b.json"
    b.write_text(json.dumps([_nl("k-0")]), encoding="utf-8")
    seen: list[tuple[str, int, int]] = []
    tm.merge_files([a, b], tmp_path / "o.json", batch_size=2,
                   on_progress=lambda s, d, t: seen.append((s, d, t)))
    assert ("read", 2, 2) in seen
    assert any(s == "write" and d == 10 for s, d, _ in seen)


def test_check_paths_classifies(tmp_path):
    imgs = tmp_path / "imgs"
    imgs.mkdir()
    (imgs / "a-1.jpg").write_bytes(b"x")

    src = tmp_path / "all.json"
    src.write_text(json.dumps([
        _tag("a-1") | {"image_path": str(imgs / "a-1.jpg")},      # 存在
        _tag("a-2") | {"image_path": str(imgs / "nope.jpg")},     # 缺
        _tag("a-3") | {"image_path": "hf://datasets/x/y"},        # 远端，不查本地
        {"image_id": "a-4"},                                      # 没路径
    ]), encoding="utf-8")

    res = tm.check_paths([str(src)])
    assert res["total"] == 4
    assert res["ok"] == 1 and res["missing"] == 1
    assert res["remote"] == 1 and res["empty"] == 1
    assert res["samples"][0]["image_id"] == "a-2"

    # image_root 覆盖后一切都按 id 重拼（原来 labels 里的远端路径也被覆盖），
    # local_root 再把"训练机路径"映射到本机目录
    res2 = tm.check_paths([str(src)], image_root="/images/fanbox",
                          local_root=str(imgs))
    assert res2["ok"] == 1 and res2["missing"] == 3 and res2["remote"] == 0


def test_api_roundtrip(tmp_path):
    """端点层的字段名/路径拼错在模块测试里看不出来，这里走一遍真请求。"""
    from fastapi.testclient import TestClient

    from tagger.web import app as app_mod

    tags = tmp_path / "tags"
    tags.mkdir()
    (tags / "a-1-tag.json").write_text(json.dumps(_tag("a-1")), encoding="utf-8")
    (tags / "a-1-nl.json").write_text(json.dumps(_nl("a-1")), encoding="utf-8")

    client = TestClient(app_mod.create_app(ui_dist=tmp_path / "no-ui"))

    res = client.get("/api/tag-manage/scan", params={"dir": str(tags)})
    assert res.status_code == 200, res.text
    files = res.json()["files"]
    assert {f["kind"] for f in files} == {"tag", "nl"}
    paths = [f["path"] for f in files]

    res = client.post("/api/tag-manage/preview",
                      json={"files": paths, "limit": 5})
    assert res.status_code == 200, res.text
    rows = res.json()["rows"]
    assert len(rows) == 1 and rows[0]["caption"] == "a girl alone"

    out = tmp_path / "merged.json"
    res = client.post("/api/tag-manage/merge", json={
        "files": paths, "out_path": str(out), "format": "train",
        "as_jsonl": False, "key": "image_id",
        "on_conflict": "first", "require": "both", "indent": 2})
    # 合并是后台任务：立刻返回 task_id，前台轮询（几十万条时不能挂着 HTTP）
    assert res.status_code == 202, res.text
    report = _wait_task(client, res.json()["task_id"])
    assert report["records_out"] == 1 and report["inputs"] == 2
    assert set(json.loads(out.read_text(encoding="utf-8"))[0]) == set(
        tm.TRAIN_FIELDS)

    # 空路径 / 错扩展名要 400，而不是写出一个叫 merged.txt 的文件
    assert client.post("/api/tag-manage/merge",
                       json={"files": paths, "out_path": ""}).status_code == 400
    assert client.post("/api/tag-manage/merge", json={
        "files": paths, "out_path": str(tmp_path / "x.txt")}).status_code == 400


def _wait_task(client, task_id: str, timeout: float = 15.0) -> dict:
    """轮询到任务结束。超时直接失败，不让测试挂死。"""
    import time

    deadline = time.time() + timeout
    while time.time() < deadline:
        res = client.get(f"/api/tag-manage/merge/{task_id}")
        assert res.status_code == 200, res.text
        data = res.json()
        if data["status"] != "running":
            assert data["status"] == "done", data
            return data["report"]
        time.sleep(0.02)
    raise AssertionError("合并任务超时")


def test_preview_returns_merged_rows(tmp_path):
    src = tmp_path / "all.json"
    src.write_text(json.dumps([_tag("a-1"), _nl("a-1"), _tag("a-2")]), encoding="utf-8")
    rows = tm.preview([src], limit=2)
    assert len(rows) == 2
    assert rows[0]["caption"] == "a girl alone"
