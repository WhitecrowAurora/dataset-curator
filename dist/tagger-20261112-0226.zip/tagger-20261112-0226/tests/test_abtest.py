"""AB 变体的守卫。

三条硬规则：同一批输入、分目录落盘、只比数值。
测试对应的是：变体解析不能静默吞错、prompt 渲染不能悄悄丢约束、
对比表必须把"没产出"如实显示成 0 条而不是崩掉。
"""

from __future__ import annotations

import json

import pytest

from tagger.abtest import (Variant, compare_variants, parse_variants,
                           pick_variant, render_compare_markdown,
                           resolve_variants, write_compare)
from tagger.config import ConfigError


# ------------------------------------------------------------------ 解析


def test_parse_variants_from_mapping():
    variants = parse_variants({
        "base": {},
        "detail": {"prompt_note": "add colour", "temperature": 0.35,
                   "max_tokens": 900, "note": "细描"},
    })
    assert [v.name for v in variants] == ["base", "detail"]
    detail = variants[1]
    assert detail.prompt_note == "add colour"
    assert detail.temperature == 0.35
    assert detail.max_tokens == 900
    assert detail.note == "细描"
    assert not variants[0].overrides_prompt


def test_parse_variants_from_list():
    variants = parse_variants([{"name": "a"}, "b"])
    assert [v.name for v in variants] == ["a", "b"]


def test_parse_variants_rejects_duplicates():
    """重名变体一定会互相覆盖产物，必须在解析时就拦住。"""
    with pytest.raises(ConfigError):
        parse_variants([{"name": "a"}, {"name": "a"}])


def test_resolve_variants_keeps_order_and_dedupes():
    raw = {"a": {}, "b": {}, "c": {}}
    picked = resolve_variants(raw, ["c", "a", "c"])
    assert [v.name for v in picked] == ["c", "a"]


def test_resolve_variants_reports_unknown_names():
    with pytest.raises(ConfigError) as err:
        resolve_variants({"a": {}}, ["a", "typo"])
    assert "typo" in str(err.value)
    assert "a" in str(err.value)


def test_resolve_variants_without_config_explains_how():
    with pytest.raises(ConfigError) as err:
        resolve_variants({}, ["a"])
    assert "variants" in str(err.value)


def test_pick_variant_unknown():
    with pytest.raises(ConfigError):
        pick_variant({"a": {}}, "b")


# ------------------------------------------------------------------ 渲染


def test_render_prompt_default_keeps_base():
    assert Variant("base").render_prompt("BASE") == "BASE"


def test_render_prompt_appends_note():
    got = Variant("d", prompt_note="  add colour  ").render_prompt("BASE")
    assert got.startswith("BASE")
    assert got.endswith("add colour")
    assert got.count("BASE") == 1


def test_render_prompt_file_replaces_whole_prompt(tmp_path):
    p = tmp_path / "prompt.txt"
    p.write_text("CUSTOM", encoding="utf-8")
    assert Variant("raw", prompt_file=str(p)).render_prompt("BASE") == "CUSTOM"


def test_render_prompt_file_missing_raises(tmp_path):
    with pytest.raises(ConfigError):
        Variant("raw", prompt_file=str(tmp_path / "nope.txt")).render_prompt("BASE")


# ------------------------------------------------------------------ 对比


def test_compare_variants_metrics_and_delta(tmp_path, write_artifact):
    base = tmp_path / "base"
    detail = tmp_path / "detail"
    write_artifact(base, "a-000001", tag="red, blue", caption="two tags here")
    write_artifact(detail, "a-000001", tag="red, blue, green, yellow",
                   caption="four tags here, longer caption text")

    result = compare_variants(tmp_path, ["base", "detail"])
    assert result["baseline"] == "base"
    rows = {r["variant"]: r for r in result["variants"]}
    assert rows["base"]["avg_tag_count"] == 2.0
    assert rows["detail"]["avg_tag_count"] == 4.0
    assert rows["detail"]["delta_vs_base"]["avg_tag_count"] == 1.0
    # 基线行没有 delta（它就是基准）
    assert "delta_vs_base" not in rows["base"]
    assert result["columns"][0]["key"] == "avg_tag_count"


def test_compare_variants_missing_dir_is_not_fatal(tmp_path):
    """跑到一半被打断是常态：报告要显示"没产出"，而不是让命令失败。"""
    result = compare_variants(tmp_path, ["base", "detail"])
    rows = {r["variant"]: r for r in result["variants"]}
    assert rows["base"]["samples"] == 0
    assert result["unreadable"]
    assert not any("delta_vs_base" in r for r in result["variants"])


def test_render_compare_markdown(tmp_path, write_artifact):
    write_artifact(tmp_path / "base", "a-000001", tag="red", caption="hi")
    write_artifact(tmp_path / "detail", "a-000001", tag="red, blue",
                   caption="hello there")
    result = compare_variants(tmp_path, ["base", "detail"])
    md = render_compare_markdown(result)
    assert "变体对比" in md
    assert "`base`" in md and "`detail`" in md
    assert "+100%" in md  # tag 数翻倍


def test_write_compare(tmp_path, write_artifact):
    write_artifact(tmp_path / "base", "a-000001", tag="red", caption="hi")
    result = compare_variants(tmp_path, ["base"])
    json_out = tmp_path / "out" / "compare.json"
    md_out = tmp_path / "out" / "compare.md"
    written = write_compare(result, json_out=json_out, md_out=md_out)

    assert len(written) == 2
    data = json.loads(json_out.read_text(encoding="utf-8"))
    assert data["variants"][0]["variant"] == "base"
    assert "变体对比" in md_out.read_text(encoding="utf-8")
