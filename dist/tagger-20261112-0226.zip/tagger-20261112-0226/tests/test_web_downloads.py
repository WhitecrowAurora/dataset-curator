"""模型下载（`web/downloads.py`）的大文件分段入口。

这里守两件容易出事的事：大文件必须真的走多连接（不然 16G 就是一条 TCP 慢慢
爬），以及 hf_source 的内部文件（锁、分段状态）不能留在模型目录里。
"""

from __future__ import annotations

from pathlib import Path

from tagger import hf_source
from tagger.web import downloads as dl


def _task(tmp_path: Path) -> dl.Task:
    return dl.Task(kind="vlm", key="demo", repo="org/demo", dest=tmp_path)


def test_big_file_goes_segmented(tmp_path, monkeypatch):
    seen: dict[str, object] = {}

    def fake(repo, filename, dest_dir, **kw):
        seen.update(kw)
        seen["repo"] = repo
        seen["filename"] = filename
        path = Path(dest_dir) / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"z" * 32)
        kw["on_progress"](32, 32)
        return hf_source.HFShard(repo=repo, filename=filename, path=path, bytes=32)

    monkeypatch.setattr(hf_source, "download_shard", fake)
    monkeypatch.setattr(dl, "SEG_MIN_BYTES", 1)      # 32 字节也算"大文件"
    task = _task(tmp_path)
    # 升级前留下的半截文件：`download_shard` 见到非空同名文件会当成"下完了"，
    # 所以必须先把这份清掉，否则会拿到一个只有 5 字节的"完整"权重。
    (tmp_path / "w.safetensors").write_bytes(b"h" * 5)
    (tmp_path / "w.safetensors.download.lock").write_bytes(b"\0")

    assert dl._fetch(task, "w.safetensors", 32, 0) == 32
    assert seen["conns"] == dl._conns()
    assert str(seen["url"]).endswith("/org/demo/resolve/main/w.safetensors")
    assert task.bytes_done == 32
    assert not (tmp_path / "w.safetensors.download.lock").exists()


def test_wait_done_waits_for_worker_thread(tmp_path):
    """取消 ≠ 线程已经收工。删除目录前必须 join，否则 Windows 报 WinError 32。"""
    import threading
    import time

    mgr = dl.DownloadManager(models_root=tmp_path)
    task = dl.Task(kind="vlm", key="demo", repo="org/demo", dest=tmp_path)
    task.thread = threading.Thread(target=lambda: time.sleep(0.15), daemon=True)
    task.thread.start()
    mgr._tasks["vlm:demo"] = task

    assert mgr.wait_done("vlm", "demo", timeout=5) is True
    assert not task.thread.is_alive()
    assert mgr.wait_done("vlm", "没有这条") is True      # 没任务不叫"卡住"


def test_cancel_keeps_part(tmp_path, monkeypatch):
    def fake(repo, filename, dest_dir, **kw):
        (Path(dest_dir) / (filename + ".part")).write_bytes(b"p" * 4)
        raise hf_source.HFCancelled("取消")

    monkeypatch.setattr(hf_source, "download_shard", fake)
    monkeypatch.setattr(dl, "SEG_MIN_BYTES", 1)
    task = _task(tmp_path)

    # 取消不是错误：累计字节不推进，半成品必须留着续传
    assert dl._fetch(task, "w.safetensors", 32, 7) == 7
    assert (tmp_path / "w.safetensors.part").is_file()
