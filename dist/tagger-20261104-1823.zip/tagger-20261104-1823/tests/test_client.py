"""客户端文本层的守卫：解析与 prompt 生成。

这两处一改，产出会整体变形（tag 全带空格、caption 缺半段、prompt 少一句
数量约束），而它们都不会抛异常——只能靠断言挡住。
"""

from __future__ import annotations

from tagger.client import _prompt_for, normalize_caption, normalize_tags, parse_output
from tagger.config import OutputSpec


# ------------------------------------------------------------------ tag 清洗


def test_normalize_tags_basic():
    assert normalize_tags("Long Hair, looking at viewer") == [
        "long_hair", "looking_at_viewer"]


def test_normalize_tags_drops_quality_and_identity_words():
    got = normalize_tags("masterpiece, best quality, 8k, red, artist_name")
    assert got == ["red"]


def test_normalize_tags_dedupes_and_drops_noise():
    got = normalize_tags("red, RED, r, red, blue")
    # 单字符被丢弃（词表里没有意义），重复只留一份
    assert got == ["red", "blue"]


def test_normalize_tags_keeps_danbooru_punctuation():
    assert normalize_tags("hatsune_miku_(cosplay), 1girl") == [
        "hatsune_miku_(cosplay)", "1girl"]


# ------------------------------------------------------------------ caption


def test_normalize_caption_strips_prefix_and_markdown():
    got = normalize_caption("  Caption: **a red   square**  ")
    assert got == "a red square"


# ------------------------------------------------------------------ 解析


def test_parse_output_both_blocks():
    text = ("<TAGS>long_hair, red_dress</TAGS>\n"
            "<CAPTION>A woman with long hair.</CAPTION>")
    tags, caption = parse_output(text, "both")
    assert tags == ["long_hair", "red_dress"]
    assert caption == "A woman with long hair."


def test_parse_output_tolerates_missing_closing_tag():
    """截断是常态：开标记在就说明模型开始了这一段，不能整条判废。"""
    text = "<TAGS>long_hair, red_dress\n<CAPTION>A woman with"
    tags, caption = parse_output(text, "both")
    assert tags == ["long_hair", "red_dress"]
    assert caption == "A woman with"


def test_parse_output_both_without_markers_is_empty():
    """both 模式没有块标记时宁可判空进重试，也不要靠猜切分。"""
    assert parse_output("just some prose", "both") == ([], "")


def test_parse_output_single_mode_falls_back_to_whole_text():
    assert parse_output("long_hair, red_dress", "tag")[0] == [
        "long_hair", "red_dress"]
    assert parse_output("A woman.", "nl")[1] == "A woman."


def test_parse_output_empty():
    assert parse_output("", "both") == ([], "")


# ------------------------------------------------------------------ prompt


def test_prompt_carries_tag_floor():
    prompt = _prompt_for(OutputSpec(mode="both"))
    assert "12 to 160 tags" in prompt
    assert "<TAGS>" in prompt and "<CAPTION>" in prompt


def test_prompt_tag_only_has_no_caption_block():
    prompt = _prompt_for(OutputSpec(mode="tag"))
    assert "<TAGS>" in prompt
    assert "<CAPTION>" not in prompt


def test_prompt_nl_only_has_no_tag_block():
    prompt = _prompt_for(OutputSpec(mode="nl"))
    assert "<CAPTION>" in prompt
    assert "<TAGS>" not in prompt


def test_prompt_length_guidance_follows_token_budget():
    short = _prompt_for(OutputSpec(mode="nl", nl_min_tokens=32, nl_max_tokens=64))
    long = _prompt_for(OutputSpec(mode="nl", nl_min_tokens=32, nl_max_tokens=256))
    # char_lo 固定 400，char_hi 取 nl_max_tokens*4 并与 600 取大、1200 封顶
    assert "400-600 characters" in short
    assert "400-1024 characters" in long


# ------------------------------------------------------------------ 溯源

class _FakeTagger:
    """只带 _tag_payload 需要的三个字段。"""

    def __init__(self, name="wd-eva02", precision="bf16", batch_size=4):
        self.name = name
        self.precision = precision
        self.batch_size = batch_size


def _client(tag_backend):
    from tagger.artist import ArtistRule
    from tagger.client import StageTimer, TaggerClient
    from tagger.quality import QualityGate, QualityPolicy

    return TaggerClient(
        base_url="http://127.0.0.1:9",
        model_name="bench",
        output=OutputSpec(mode="both", tag_min_count=1, tag_max_count=10),
        temperature=0.2, top_p=0.9, max_tokens=64, timeout_s=5, max_attempts=1,
        gate=QualityGate(QualityPolicy(min_chars=1, max_chars=5000,
                                       min_tag_coverage=0.0,
                                       nl_min_tokens=0, nl_max_tokens=1000),
                         verbose=False),
        prov_base={"model_id": "bench", "precision": "bf16"},
        artist_rule=ArtistRule(),
        tag_backend=tag_backend,
        stage=StageTimer(),
    )


def test_tag_payload_records_backend_and_precision():
    """tag 产物的 provenance 必须带上后端与精度。

    这两个字段以前只写在 payload 顶层（tag_backend），merge 读的却是
    provenance 里那份 —— 于是 tag_backend 这一维永远是"(缺失)"，
    "这批 tag 是谁出的、跑的是什么精度"根本查不出来。
    """
    from tagger.client import TaskRow

    client = _client(_FakeTagger())
    prov = client._tag_payload(TaskRow(shard="s", image_id="i1", file="i1.png"),
                               [("1girl", 0.9)], 0.2, 10, 1)["provenance"]
    assert prov["tag_backend"] == "wd-eva02"
    assert prov["tag_precision"] == "bf16"
    # VLM 的 precision 不能被 tag 精度顶掉（两者含义不同）
    assert prov["precision"] == "bf16"


def test_nl_payload_has_no_tag_fields():
    from tagger.client import TaskRow

    client = _client(_FakeTagger())
    prov = client._provenance(0.2)
    assert "tag_backend" not in prov
    assert "tag_precision" not in prov


def test_vlm_tagging_marks_backend_as_vlm():
    from tagger.client import TaskRow

    client = _client(None)
    prov = client._tag_payload(TaskRow(shard="s", image_id="i1", file="i1.png"),
                               [("1girl", 1.0)], 0.2, 10, 1)["provenance"]
    assert prov["tag_backend"] == "vlm"
    assert prov["tag_precision"] == "vlm"
