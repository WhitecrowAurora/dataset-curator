"""本地打标引擎。

这里测的不是数值（那是 verify_dtype / golden 的事），而是四条会静默出错的
纪律：扫描顺序稳定、跳过口径是 `ok`、坏图不连坐、中止只在块边界。

另有一条隐形但很贵的：**交给后端的块必须大于 batch_size**。等于 batch_size
时 `_predict_many` 只切出一块，解码预取被这条边界关掉——不报错，只是慢
1.75×。这条只能靠断言调用形状来守。
"""

from __future__ import annotations

import json

import pytest

from tagger.cpu_tagger import TagPrediction
from tagger.local_tag import (TagStats, artifact_path, config_fingerprint,
                              read_artifact, scan_images, tag_items)


class _FakeBackend:
    name = "fake"
    precision = "bf16"

    def __init__(self, batch_size=2, bad=(), rating=None):
        self.batch_size = batch_size
        self.bad = set(bad)          # 这些路径会让整块推理抛
        self.rating = rating or {}
        self.last_timings = {"total": 0, "decode": 0, "forward": 0}
        self.calls: list[list[str]] = []

    def predict_batch(self, images):
        self.calls.append(list(images))
        if any(str(p) in self.bad for p in images):
            raise RuntimeError("decode failed: 坏图")
        self.last_timings = {"total": 10, "decode": 4, "forward": 3}
        return [TagPrediction(tags=[("red", 0.9), ("sky", 0.4)],
                              backend="fake", rating=dict(self.rating))
                for _ in images]


def _write_images(root, names):
    for n in names:
        p = root / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"\x89PNG\r\n\x1a\n")     # 内容无所谓：后端是假的


def test_scan_is_sorted_and_ids_drop_extension(tmp_path):
    _write_images(tmp_path, ["b.png", "a.jpg", "sub/c.PNG", "notes.txt"])
    items = scan_images(tmp_path)
    assert [i.rel for i in items] == ["a.jpg", "b.png", "sub/c.PNG"]
    assert [i.image_id for i in items] == ["a", "b", "sub/c"]


def test_scan_respects_non_recursive_and_limit(tmp_path):
    _write_images(tmp_path, ["a.png", "b.png", "sub/c.png"])
    assert [i.rel for i in scan_images(tmp_path, recursive=False)] == ["a.png", "b.png"]
    assert len(scan_images(tmp_path, limit=2)) == 2


def test_chunk_is_larger_than_batch_size(tmp_path):
    """块必须 > batch_size，否则解码预取被关掉（1.75× 静默丢失）。"""
    _write_images(tmp_path, [f"{i}.png" for i in range(20)])
    backend = _FakeBackend(batch_size=2)
    tag_items(backend, scan_images(tmp_path), out_dir=tmp_path / "out")
    assert len(backend.calls) == 2            # 20 张 / 每块 16 张
    assert [len(c) for c in backend.calls] == [16, 4]


def test_writes_payload_with_expected_fields(tmp_path):
    _write_images(tmp_path, ["a.png", "b.png"])
    items = scan_images(tmp_path)
    backend = _FakeBackend(rating={"general": 0.71, "explicit": 0.02})
    stats = tag_items(backend, items, out_dir=tmp_path / "out")

    assert (stats.total, stats.done, stats.failed) == (2, 2, 0)
    art = read_artifact(tmp_path / "out", items[0])
    assert art["image_id"] == "a"
    assert art["tag"] == "red, sky"
    assert art["tags"][0] == ["red", 0.9]
    assert art["ok"] is True
    assert art["tag_backend"] == "fake"
    assert art["provenance"]["tag_precision"] == "bf16"
    assert art["rating"]["general"] == 0.71
    # 分级分数不并进 tag 串
    assert "general" not in art["tag"]


def test_skip_rule_is_ok_not_empty_tag(tmp_path):
    """一张零 tag 的图也是有效结果，重跑必须跳过——否则每次都白算。"""
    _write_images(tmp_path, ["a.png"])
    item = scan_images(tmp_path)[0]
    backend = _FakeBackend()
    path = artifact_path(tmp_path / "out", item)
    path.parent.mkdir(parents=True)
    # 有效的零 tag 结果同样算完成。
    path.write_text(json.dumps({"image_id": "a", "tag": "", "ok": True,
                                "config_fingerprint": config_fingerprint(backend)}),
                    encoding="utf-8")

    stats = tag_items(backend, [item], out_dir=tmp_path / "out")
    assert (stats.skipped, stats.done) == (1, 0)
    assert backend.calls == []


def test_artifact_without_fingerprint_is_skipped(tmp_path):
    """旧产物有效就跳过；只有强制重做才更新。"""
    _write_images(tmp_path, ["a.png"])
    item = scan_images(tmp_path)[0]
    path = artifact_path(tmp_path / "out", item)
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({"image_id": "a", "tag": "old", "ok": True}),
                    encoding="utf-8")

    backend = _FakeBackend()
    stats = tag_items(backend, [item], out_dir=tmp_path / "out")
    assert (stats.skipped, stats.done) == (1, 0)
    art = read_artifact(tmp_path / "out", item)
    assert art["tag"] == "old"
    assert backend.calls == []


def test_fingerprint_changes_with_thresholds(tmp_path):
    """阈值变化保留在指纹中，但默认仍跳过已有图片。"""
    _write_images(tmp_path, ["a.png"])
    item = scan_images(tmp_path)[0]
    backend = _FakeBackend()
    tag_items(backend, [item], out_dir=tmp_path / "out")
    art = read_artifact(tmp_path / "out", item)
    fp1 = art["config_fingerprint"]

    backend.thresholds = {"default": 0.5}
    assert config_fingerprint(backend) != fp1
    # 用新配置重跑仍跳过；强制重做才写入新指纹。
    stats = tag_items(backend, [item], out_dir=tmp_path / "out")
    assert (stats.skipped, stats.done) == (1, 0)
    assert read_artifact(tmp_path / "out", item)["config_fingerprint"] == fp1
    stats = tag_items(backend, [item], out_dir=tmp_path / "out", force=True)
    assert (stats.skipped, stats.done) == (0, 1)
    assert read_artifact(tmp_path / "out", item)["config_fingerprint"] == config_fingerprint(backend)


def test_force_ignores_existing_artifacts(tmp_path):
    _write_images(tmp_path, ["a.png"])
    item = scan_images(tmp_path)[0]
    path = artifact_path(tmp_path / "out", item)
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({"image_id": "a", "tag": "old", "ok": True}),
                    encoding="utf-8")

    backend = _FakeBackend()
    tag_items(backend, [item], out_dir=tmp_path / "out", force=True)
    assert read_artifact(tmp_path / "out", item)["tag"] == "red, sky"


def test_broken_image_does_not_take_down_the_chunk(tmp_path):
    _write_images(tmp_path, ["a.png", "bad.png", "c.png"])
    items = scan_images(tmp_path)
    backend = _FakeBackend(bad=[str(tmp_path / "bad.png")])
    stats = tag_items(backend, items, out_dir=tmp_path / "out")

    assert (stats.done, stats.failed) == (2, 1)
    # by_reason 按 "<异常类型>: 详情" 的第一段聚合（与 client 的口径一致）
    assert "RuntimeError" in stats.by_reason
    assert read_artifact(tmp_path / "out", items[0])["ok"] is True
    assert read_artifact(tmp_path / "out", items[1]) is None


def test_should_stop_breaks_at_chunk_boundary(tmp_path):
    _write_images(tmp_path, [f"{i}.png" for i in range(40)])   # 40 张 = 2 块多
    backend = _FakeBackend(batch_size=2)                       # 每块 16 张
    calls = {"n": 0}

    def stop():
        calls["n"] += 1
        return calls["n"] > 1          # 第一块跑完就喊停

    stats = tag_items(backend, scan_images(tmp_path), out_dir=tmp_path / "out",
                      should_stop=stop)
    assert stats.stopped is True
    assert stats.done == 16            # 正好一块，不会多跑
    assert len(backend.calls) == 1


def test_timings_accumulate_and_progress_kinds_are_reported(tmp_path):
    _write_images(tmp_path, [f"{i}.png" for i in range(10)])
    items = scan_images(tmp_path)
    events: list[tuple[str, str]] = []

    # batch_size=1 → 每块 8 张，10 张正好两次调用
    stats = tag_items(_FakeBackend(batch_size=1), items, out_dir=tmp_path / "out",
                      on_progress=lambda kind, item, extra, st:
                      events.append((kind, item.image_id)))

    assert [k for k, _ in events] == ["done"] * 10
    assert stats.decode_ms == 8 and stats.forward_ms == 6   # 两次调用各 4/3


def test_broken_hook_does_not_abort(tmp_path):
    _write_images(tmp_path, ["a.png"])

    def boom(kind, item, extra, stats):
        raise RuntimeError("UI 炸了")

    stats = tag_items(_FakeBackend(), scan_images(tmp_path),
                      out_dir=tmp_path / "out", on_progress=boom)
    assert stats.done == 1


def test_summary_lines_are_human_readable():
    lines = TagStats(total=4, done=2, skipped=1, failed=1, wall_ms=2000
                     ).summary_lines()
    assert any(l.startswith("完成") for l in lines)
    assert any("平均耗时" in l for l in lines)


def test_scan_rejects_non_directory(tmp_path):
    with pytest.raises(NotADirectoryError):
        scan_images(tmp_path / "nope")
