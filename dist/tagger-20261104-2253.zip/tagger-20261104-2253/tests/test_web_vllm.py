"""NL 模式：产出模式映射 + 本机 vLLM 服务。

三件必须钉住的事：

1. **单模式强制关本地后端**。`run_client` 的语义是"后端在场就由后端出 tag"，
   所以 `tag` 模式下后端在场会直接抛 ConfigError（VLM 没有活干），
   `nl` 模式后端在场会偷偷多写一份没人要的 tag 文件。两条都在映射层堵死。
2. **模式在 create 时校验**。跑进线程才失败的话，HTTP 已经回了 202，
   页面上显示"任务失败"，而实际上是表单填错了。
3. **服务状态可读**。首次加载几分钟，没有状态页就只有一个转不完的圈；
   环境不满足时（Windows / 无卡 / 缺 vllm）要当场拒绝，而不是 202 后翻 failed。
4. **停止要能掐断启动**。服务起来前的那几秒是最容易"杀了进程还在等"的窗口。
"""

from __future__ import annotations

import threading
import time
import types

import pytest
from fastapi.testclient import TestClient

from tagger import config as cfg_mod
from tagger import model_loader
from tagger.config import ConfigError
from tagger.web import jobs as jobs_mod
from tagger.web import vllm_service
from tagger.web.app import create_app
from tagger.web.jobs import JobManager, JobSpec, vlm_backend_for
from tagger.web.vllm_service import FINGERPRINT_PATH, VllmService


@pytest.fixture
def client(tmp_path):
    jobs_mod.MANAGER._jobs.clear()
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def _vlm_spec(tmp_path, **kw) -> JobSpec:
    kw.setdefault("out_dir", str(tmp_path / "out"))
    return JobSpec(engine="vlm", **kw)


# ------------------------------------------------------------------ 模式映射

def test_backend_none_for_single_modes():
    """nl / tag 一律关后端：一个会多写 tag，一个会让 run_client 直接拒绝。"""
    assert vlm_backend_for("nl", "pixai") == "none"
    assert vlm_backend_for("tag", "pixai") == "none"
    assert vlm_backend_for("tag", "wd-eva02") == "none"
    # 大小写与空白不影响判定（表单值来自输入框）
    assert vlm_backend_for(" TAG ", " pixai ") == "none"


def test_backend_kept_for_both():
    assert vlm_backend_for("both", "pixai") == "pixai"
    assert vlm_backend_for("both", "wd-eva02") == "wd-eva02"
    # 空串 / vlm 都是"VLM 自己出 tag"
    assert vlm_backend_for("both", "") == "none"
    assert vlm_backend_for("both", "vlm") == "none"


def test_run_vlm_tag_mode_reaches_run_client(tmp_path, monkeypatch):
    """tag 模式要以 mode=tag + 后端 none 进 run_client，否则要么被拒、要么出双份。"""
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        seen["mode"] = args.mode
        seen["backend"] = args.tag_backend
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False,
                               output_mode="tag", backend="pixai"))
    mgr._run(job)
    assert (seen["mode"], seen["backend"]) == ("tag", "none")
    assert job.status == "done"


def test_create_rejects_unknown_output_mode(tmp_path):
    mgr = JobManager()
    with pytest.raises(ValueError, match="output_mode"):
        mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", output_mode="caption"))


def test_create_accepts_all_three_modes(tmp_path):
    # 每次一个全新的 JobManager：同一个簿子里建完不跑，下一个会被"已有任务在跑"挡住。
    for mode in ("nl", "tag", "both"):
        job = JobManager().create(_vlm_spec(tmp_path, hf_repo="org/r", output_mode=mode))
        assert job.spec.output_mode == mode


# ------------------------------------------------------------------ 服务状态

def test_capability_endpoint_answers_per_engine(client, monkeypatch):
    """引擎下拉一改，页面就该知道这台机器认不认它。

    vLLM 在 Windows 上永远不可用、llama.cpp 又不需要 Python 环境，
    两者的答案不能共用一格缓存——否则切过去还是上一个引擎的结论。
    """
    seen: list[str] = []
    monkeypatch.setattr(
        VllmService, "local_capability",
        lambda self, engine="vllm": (seen.append(engine) or (engine == "llamacpp"),
                                     "原因-" + engine))

    llama = client.get("/api/vllm/capability?engine=llamacpp").json()
    assert llama == {"engine": "llamacpp", "ok": True, "reason": "原因-llamacpp"}
    vllm = client.get("/api/vllm/capability?engine=vllm").json()
    assert vllm["ok"] is False and "原因-vllm" in vllm["reason"]
    assert seen == ["llamacpp", "vllm"]        # 两次都真去探了，没有吃旧缓存


def test_vllm_status_is_readable_when_idle(client):
    data = client.get("/api/vllm").json()
    assert data["status"] == "stopped"
    assert data["url"].startswith("http://127.0.0.1:")   # 没起来也给出会绑的地址
    assert data["local_reason"]          # 页面靠它解释"为什么不能在本机起"
    assert data["fingerprint_path"].endswith("fingerprint.json")


def test_vllm_start_refuses_without_a_usable_environment(client, monkeypatch):
    """环境不满足就 400 + 原因，不能回 202 再翻 failed——后者看起来像服务崩了。"""
    svc = vllm_service.VLLM
    monkeypatch.setattr(VllmService, "_probe_capability",
                        staticmethod(lambda engine="vllm": (False, "没有检测到 NVIDIA 显卡")))
    svc._cap = None
    try:
        resp = client.post("/api/vllm/start", json={"port": 8011})
        assert resp.status_code == 400
        assert "NVIDIA" in resp.json()["detail"]
        assert svc.status == "stopped"    # 没被置成 starting
    finally:
        svc._cap = None


def test_vllm_start_rejects_bad_port(client, monkeypatch):
    svc = vllm_service.VLLM
    monkeypatch.setattr(VllmService, "_probe_capability",
                        staticmethod(lambda engine="vllm": (True, "")))
    svc._cap = None
    try:
        resp = client.post("/api/vllm/start", json={"port": 80})
        assert resp.status_code == 400
        assert "端口" in resp.json()["detail"]
    finally:
        svc._cap = None


def test_vllm_probe_reports_unreachable_address(client):
    """填错地址与"服务挂了"在页面上长得一样，探测结果要能区分。"""
    data = client.get("/api/vllm/probe", params={"url": "http://127.0.0.1:1"}).json()
    assert data["ok"] is False
    assert "连不上" in data["error"]


def test_vllm_probe_without_url(client):
    data = client.get("/api/vllm/probe").json()
    assert data["ok"] is False
    assert "没有填" in data["error"]


def test_fingerprint_path_is_the_one_clients_read():
    """Web 侧写的指纹必须与 run_client 读的是同一个路径，否则永远是"缺失"。"""
    assert FINGERPRINT_PATH == vllm_service.Path("run") / "fingerprint.json"


def test_stop_when_idle_is_a_noop(client):
    data = client.post("/api/vllm/stop").json()
    assert data["status"] == "stopped"
    assert data["error"] == ""


# ------------------------------------------------------------------ 启动窗口

class _FakeProc:
    pid = 4242
    returncode = None

    def poll(self):
        return None


class _FakeHandle:
    def __init__(self, port: int):
        self.process = _FakeProc()
        self.base_url = f"http://127.0.0.1:{port}"
        self.port = port
        self.profile = None
        self.vllm_version = None
        self.stopped = False

    def stop(self):
        self.stopped = True


def test_stop_while_starting_reaps_the_process(monkeypatch):
    """起进程的那几秒里点停止：进程刚建出来就得被收掉。

    这里是"status 已经 stopped、进程却还在后台占显存"的唯一窗口：
    stop() 时 handle 还不存在，只能靠启动线程自己发现令牌已作废。
    """
    entered = threading.Event()
    gate = threading.Event()
    spawned: dict[str, _FakeHandle] = {}

    def fake_start(profile, *, port, log_path, wait, served_name="tagger",
                   data_root=None, engine="vllm"):
        assert wait is False          # 等就绪必须由本层轮询，否则停止掐不断
        entered.set()
        gate.wait(3)
        spawned["handle"] = _FakeHandle(port)
        return spawned["handle"]

    def fake_wait(*_a, **_kw):        # 走到这里说明没被叫停，用例本身就是失败
        raise AssertionError("停止后不该再进入等待就绪")

    monkeypatch.setattr(model_loader, "start_server", fake_start)
    monkeypatch.setattr(model_loader, "wait_ready", fake_wait)
    monkeypatch.setattr(model_loader, "check_environment", lambda: None)
    monkeypatch.setattr("tagger.hardware.query_gpus", lambda: [object()])
    monkeypatch.setattr(cfg_mod, "load_tier_table", lambda *a, **kw: {})
    monkeypatch.setattr(
        cfg_mod, "resolve_profile",
        lambda *a, **kw: types.SimpleNamespace(summary=lambda: "tier test"),
    )
    monkeypatch.setattr(VllmService, "_probe_capability",
                        staticmethod(lambda engine="vllm": (True, "")))

    svc = VllmService()
    svc._cap = None
    try:
        # 显式引擎：这个用例测的是 vLLM 的启停窗口，而默认引擎现在是
        # llama.cpp（走 llamacpp 分支会在 resolve_weights 就停住）。
        svc.start(port=8033, engine="vllm")
        assert svc.snapshot()["status"] == "starting"
        assert entered.wait(2)

        svc.stop()                    # handle 此时还没建出来
        gate.set()
        svc._thread.join(3)           # 让启动线程跑完它的收尾

        assert spawned["handle"].stopped is True, "进程建出来后必须被收掉"
        snap = svc.snapshot()
        assert snap["status"] == "stopped"
        assert snap["error"] == ""
    finally:
        gate.set()
        svc._cap = None


def test_start_refused_while_already_starting(monkeypatch):
    """重复点启动不能起第二个进程（单卡两个 vLLM 互相抢显存）。"""
    gate = threading.Event()

    def fake_start(profile, *, port, log_path, wait, served_name="tagger",
                   data_root=None, engine="vllm"):
        gate.wait(3)
        return _FakeHandle(port)

    def fake_wait(*_a, **_kw):
        # 这个用例不关心就绪；不让它真的去连 8034 等 900 秒
        raise RuntimeError("测试结束")

    monkeypatch.setattr(model_loader, "start_server", fake_start)
    monkeypatch.setattr(model_loader, "wait_ready", fake_wait)
    monkeypatch.setattr(model_loader, "check_environment", lambda: None)
    monkeypatch.setattr("tagger.hardware.query_gpus", lambda: [object()])
    monkeypatch.setattr(cfg_mod, "load_tier_table", lambda *a, **kw: {})
    monkeypatch.setattr(
        cfg_mod, "resolve_profile",
        lambda *a, **kw: types.SimpleNamespace(summary=lambda: "tier test"),
    )
    monkeypatch.setattr(VllmService, "_probe_capability",
                        staticmethod(lambda engine="vllm": (True, "")))

    svc = VllmService()
    svc._cap = None
    try:
        svc.start(port=8034)
        with pytest.raises(RuntimeError, match="已在运行或启动中"):
            svc.start(port=8034)
    finally:
        gate.set()
        time.sleep(0.1)
        svc._cap = None


# ------------------------------------------------------------------ 批调度参数

def _svc_with_fake_start(monkeypatch, captured: dict):
    def fake_start(profile, *, port, log_path, wait, served_name="tagger",
                   data_root=None, engine="vllm"):
        captured["profile"] = profile
        captured["served_name"] = served_name
        captured["data_root"] = data_root
        captured["handle"] = _FakeHandle(port)
        return captured["handle"]

    def fake_wait(*_a, **_kw):
        raise RuntimeError("测试结束")

    monkeypatch.setattr(model_loader, "start_server", fake_start)
    monkeypatch.setattr(model_loader, "wait_ready", fake_wait)
    monkeypatch.setattr(model_loader, "check_environment", lambda: None)
    monkeypatch.setattr("tagger.hardware.query_gpus", lambda: [object()])
    monkeypatch.setattr(cfg_mod, "load_tier_table", lambda *a, **kw: {})
    monkeypatch.setattr(VllmService, "_probe_capability",
                        staticmethod(lambda engine="vllm": (True, "")))
    svc = VllmService()
    svc._cap = None
    return svc


def test_start_rejects_impossible_batching_values():
    """并发参数在 create 时就校验：2048 以下一步放不下一张图的 prefill，
    0.98 以上 vLLM 自己就拿不到启动显存。这些错要当场说出人话。"""
    svc = VllmService()
    for kwargs in ({"max_num_seqs": 0}, {"max_num_seqs": 1000},
                   {"max_num_batched_tokens": 1024},
                   {"gpu_mem": 1.5}):
        with pytest.raises(ValueError):
            svc.start(port=8035, **kwargs)


def test_start_passes_batching_overrides_to_profile(monkeypatch):
    """三个参数必须真正走到 resolve_profile，而不是只存在 UI 状态里。"""
    captured: dict = {}
    seen: dict = {}

    def fake_resolve(table, gpu, **kw):
        seen.update(kw)
        return types.SimpleNamespace(summary=lambda: "tier test")

    monkeypatch.setattr(cfg_mod, "resolve_profile", fake_resolve)
    svc = _svc_with_fake_start(monkeypatch, captured)
    try:
        svc.start(port=8036, max_num_seqs=24, max_num_batched_tokens=32768,
                  gpu_mem=0.9)
        for _ in range(50):
            if seen:
                break
            time.sleep(0.02)
    finally:
        svc.stop()
        svc._cap = None
    assert seen["max_num_seqs_override"] == 24
    assert seen["max_num_batched_tokens_override"] == 32768
    assert seen["gpu_mem_override"] == 0.9


def test_overrides_are_visible_in_snapshot():
    """面板要能显示"现在跑的是默认值还是我调过的值"——改了没重启最难查。"""
    svc = VllmService()
    assert svc.snapshot()["overrides"] == {
        "engine": None,
        "model": None, "tier": None, "precision": None, "served_name": None,
        "max_num_seqs": None, "max_num_batched_tokens": None, "gpu_mem": None,
        "local_media_root": None}


# ------------------------------------------------------------------ 换模型

def test_defaults_exposes_both_model_axes(client):
    """页面上的两个下拉都由配置生成：VLM 权重（models）与 tag 分类头（tagging.models）。

    写死在组件里的话，配置加一个新模型页面还是那几项——"换模型只能去
    命令行"就是这么来的。
    """
    data = client.get("/api/defaults").json()
    keys = {m["key"] for m in data["vllm_models"]}
    assert {"qwen3vl-4b", "qwen3vl-8b"} <= keys
    assert all(m["path"] for m in data["vllm_models"])
    assert {t["name"] for t in data["vllm_tiers"]} >= {"low-16g", "mid-24g", "high-32g"}
    # tag 分类头的仓库按后端分组：混在一起就会把 pixai 的名字喂给 wd-eva02
    assert data["tag_models"]["pixai"].startswith("pixai-labs/")


def test_plan_preview_does_not_start_service(client):
    """预览只解析参数：点开页面不该顺手把服务拉起来。"""
    svc = vllm_service.VLLM
    before = svc.status
    data = client.get("/api/vllm/plan", params={"model": "qwen3vl-8b"}).json()
    assert data["ok"] is True
    assert data["model"] == "qwen3vl-8b"
    assert data["max_model_len"] >= 1024
    assert svc.status == before


def test_plan_error_is_one_sentence(client):
    """解析失败要是一句人话，不能带 ConfigError 这种类名。"""
    data = client.get("/api/vllm/plan", params={"tier": "no-such-tier"}).json()
    assert data["ok"] is False
    assert "no-such-tier" in data["error"]
    assert "ConfigError" not in data["error"]


def test_start_passes_model_and_tier_to_profile(monkeypatch):
    """选了 8B / 指定档位必须真正走到 resolve_profile，而不是只存在 UI 状态里。"""
    captured: dict = {}
    seen: dict = {}

    def fake_resolve(table, gpu, **kw):
        seen.update(kw)
        return types.SimpleNamespace(summary=lambda: "tier test")

    monkeypatch.setattr(cfg_mod, "resolve_profile", fake_resolve)
    svc = _svc_with_fake_start(monkeypatch, captured)
    monkeypatch.setattr(
        cfg_mod, "load_tier_table",
        lambda *a, **kw: {"models": {"qwen3vl-8b": {"path": "Qwen/Qwen3-VL-8B-Instruct"}},
                          "tiers": [{"name": "high-32g"}]})
    try:
        svc.start(port=8037, model="qwen3vl-8b", tier="high-32g")
        for _ in range(50):
            if seen:
                break
            time.sleep(0.02)
    finally:
        svc.stop()
        svc._cap = None
    assert seen["model_override"] == "qwen3vl-8b"
    assert seen["tier_override"] == "high-32g"


def test_start_passes_precision_to_profile(monkeypatch):
    """页面选的精度必须真的走到 resolve_profile。

    只存在 UI 状态里等于没生效：页面显示 FP8、服务却按分档表的 int4 起，
    而这批数据的 provenance 会写成另一个 model_id。
    """
    captured: dict = {}
    seen: dict = {}

    def fake_resolve(table, gpu, **kw):
        seen.update(kw)
        return types.SimpleNamespace(summary=lambda: "tier test")

    monkeypatch.setattr(cfg_mod, "resolve_profile", fake_resolve)
    svc = _svc_with_fake_start(monkeypatch, captured)
    try:
        svc.start(port=8041, precision="fp8")
        for _ in range(50):
            if seen:
                break
            time.sleep(0.02)
        assert svc.snapshot()["overrides"]["precision"] == "fp8"
    finally:
        svc.stop()
        svc._cap = None
    assert seen["precision_override"] == "fp8"


def test_start_rejects_unknown_precision():
    """写错的精度档位要当场拒绝，不能起进程后才发现。"""
    svc = VllmService()
    with pytest.raises(ConfigError, match="未知精度"):
        svc.start(port=8042, precision="int8")
    assert svc.status == "stopped"


def test_start_rejects_unknown_model_before_spawning(monkeypatch):
    """key 写错要在点启动的那一下就拒绝，不能等线程里抛 traceback。"""
    svc = _svc_with_fake_start(monkeypatch, {})
    monkeypatch.setattr(
        cfg_mod, "load_tier_table",
        lambda *a, **kw: {"models": {"qwen3vl-4b": {"path": "x"}},
                          "tiers": [{"name": "low-16g"}]})
    try:
        with pytest.raises(ValueError, match="未知模型"):
            svc.start(port=8038, model="qwen3vl-99b")
        with pytest.raises(ValueError, match="未知分档"):
            svc.start(port=8038, tier="ultra-99g")
        assert svc.status == "stopped"
    finally:
        svc._cap = None


def test_served_name_reaches_the_command_line(monkeypatch):
    """表单里的「模型名」必须真的成为 --served-model-name，否则请求报"模型不存在"。"""
    captured: dict = {}
    monkeypatch.setattr(
        cfg_mod, "resolve_profile",
        lambda *a, **kw: types.SimpleNamespace(summary=lambda: "tier test"))
    svc = _svc_with_fake_start(monkeypatch, captured)
    try:
        svc.start(port=8039, served_name="my-tagger", engine="vllm")
        for _ in range(50):
            if captured.get("served_name"):
                break
            time.sleep(0.02)
    finally:
        svc.stop()
        svc._cap = None
    assert captured["served_name"] == "my-tagger"


# ------------------------------------------------------------------ 页内量化
#
# 量化是几十分钟的长任务，接口只负责透传与错误映射；真正的状态机在
# tests/test_quantize.py。这里钉的是"页面发了、后端收到了"。

def _patch_quant(monkeypatch, *, error: Exception | None = None):
    from tagger.web import app as app_mod

    seen: dict = {}

    class _FakeQuant:
        def snapshot(self, model=None):
            seen["snapshot"] = model
            return {"model": model or "", "available": True, "task": None}

        def start(self, **kw):
            seen["start"] = kw
            if error is not None:
                raise error
            return {"status": "running", **kw}

        def cancel(self):
            seen["cancel"] = True
            return {"status": "canceled"}

    monkeypatch.setattr(app_mod, "QUANT", _FakeQuant())
    return seen


def test_quantize_routes_pass_through(client, monkeypatch):
    seen = _patch_quant(monkeypatch)

    data = client.get("/api/vllm/quantize", params={"model": "qwen3vl-8b"}).json()
    assert data["model"] == "qwen3vl-8b"
    assert seen["snapshot"] == "qwen3vl-8b"

    resp = client.post("/api/vllm/quantize/start",
                       json={"model": "qwen3vl-8b",
                             "out_dir": "models/nl/qwen3vl-8b-w4a16",
                             "method": "awq"})
    assert resp.status_code == 202
    assert seen["start"] == {"model_key": "qwen3vl-8b",
                             "out_dir": "models/nl/qwen3vl-8b-w4a16",
                             "method": "awq"}
    assert client.post("/api/vllm/quantize/cancel").json()["status"] == "canceled"


def test_quantize_start_maps_errors_to_http(client, monkeypatch):
    """路径越界/依赖缺失是 400，已在跑是 409——页面据此决定显示什么。"""
    _patch_quant(monkeypatch, error=ValueError("拒绝写入：不在模型目录之内"))
    assert client.post("/api/vllm/quantize/start", json={}).status_code == 400

    _patch_quant(monkeypatch, error=RuntimeError("已经在跑"))
    assert client.post("/api/vllm/quantize/start", json={}).status_code == 409


# ------------------------------------------------------------------ 表单漏项
#
# 这三项在 CLI 里都是有的，但 web 侧不传就等于静默失效：页面上看得见、
# 改了没反应，比没有这一项更难查。

def test_local_shard_is_passed_as_a_list(tmp_path, monkeypatch):
    """本地分片必须以**列表**进 run_client。

    JobSpec.input_dir 是字符串；collect_shards / classify_local_inputs 都按序列
    遍历，传裸字符串会逐字符解析成"分片不存在: D"——本地 VLM 输入曾因此必坏，
    而错误看起来像是路径填错了。
    """
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        seen["shard"] = args.shard
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    shards = str(tmp_path / "shards")
    job = mgr.create(_vlm_spec(tmp_path, input_dir=shards, guard=False))
    mgr._run(job)
    assert seen["shard"] == [shards]


def test_failure_cap_and_artist_toggle_reach_run_client(tmp_path, monkeypatch):
    """失败上限与画师注入必须进 run_client —— 一个影响重跑浪费，一个改文本内容。"""
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        seen["max_failures"] = args.max_failures
        seen["artist_enabled"] = ops.artist_rule().enabled
        seen["artist_inject"] = ops.artist_rule().inject_caption
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False,
                               max_failures=7, artist=True,
                               artist_inject=False))
    mgr._run(job)
    assert seen["max_failures"] == 7
    # 启用但要求"只进 JSON 字段"：enabled 必须是 True，否则连字段都没有
    assert seen["artist_enabled"] is True
    assert seen["artist_inject"] is False


def test_quality_thresholds_reach_the_policy(tmp_path, monkeypatch):
    """质检三条线在页面上可调，就必须真的走到 QualityPolicy。

    pass/drop/attempts 决定每张图打几次，是 30M 量级下最贵的旋钮之一；
    表单发了、后端不接，症状是"调了没反应"，比没有这一项更难查。
    """
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        p = ops.quality_policy()
        seen["pass"] = p.pass_score
        seen["drop"] = p.drop_score
        seen["attempts"] = p.max_attempts
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False,
                               quality_pass_score=4.2, quality_drop_score=2.4,
                               quality_max_attempts=1))
    mgr._run(job)
    assert (seen["pass"], seen["drop"], seen["attempts"]) == (4.2, 2.4, 1)


def test_quality_zero_means_follow_config(tmp_path, monkeypatch):
    """0 = 用配置默认。显式传 0 不能把判定线真的压到 0——那会让所有样本都放行。"""
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        p = ops.quality_policy()
        seen.update(pass_=p.pass_score, drop=p.drop_score, attempts=p.max_attempts)
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False))
    mgr._run(job)
    assert seen["pass_"] > 0 and seen["drop"] > 0 and seen["attempts"] >= 1


def test_artist_off_keeps_config_default_off(tmp_path, monkeypatch):
    """表单关掉画师时，配置里的 enabled 也不能把它翻回来——否则页面上那个开关是摆设。"""
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        seen["artist_enabled"] = ops.artist_rule().enabled
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False,
                               artist=False, artist_inject=False))
    mgr._run(job)
    assert seen["artist_enabled"] is False
