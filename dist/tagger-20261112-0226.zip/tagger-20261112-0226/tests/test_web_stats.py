"""统计页的分桶统计：细桶累加 / 合并 / VLM 桥接 / 端点契约。

用假后端与假 run_client，不碰真权重。要钉住的契约：
1. 细桶每 100 张一卷，合并成 500/1000/5000 是纯加法，total 对得上 counts；
2. attempts 区分首过与重试过，score 只进直方图（阈值在前端现算）；
3. 旧任务没有逐项数据时用 counts 兜底成单桶，端点不炸。
"""

from __future__ import annotations

import time

import pytest
from fastapi.testclient import TestClient

from tagger.client import ClientStats, Outcome, TaskRow
from tagger.local_tag import TagStats
from tagger.web import jobs as jobs_mod
from tagger.web.app import create_app
from tagger.web.jobs import (SCORE_BINS, STAT_FINE, Job, JobManager, JobSpec,
                             _ROW_LEN, merge_buckets)


def _row(settled=0, done_first=0, done_retry=0, skipped=0,
         blacklisted=0, failed=0, score_sum=0, hist=None) -> list[int]:
    row = [settled, done_first, done_retry, skipped, blacklisted,
           failed, score_sum] + [0] * SCORE_BINS
    if hist:
        for bin_, n in hist.items():
            row[len(row) - SCORE_BINS + bin_] = n
    assert len(row) == _ROW_LEN
    return row


# ------------------------------------------------------------------ 纯函数

def test_merge_buckets_sums_and_closes_end():
    rows = [_row(settled=STAT_FINE, done_first=90, failed=10)
            for _ in range(5)]                       # 500 张
    rows.append(_row(settled=40, done_first=35, skipped=5))   # 尾桶不满
    out = merge_buckets(rows, 1000)
    assert len(out) == 1
    b = out[0]
    assert b["start"] == 0
    assert b["end"] == 539                           # 按真实结算数收口
    assert b["settled"] == 540
    assert b["done_first"] == 485 and b["failed"] == 50 and b["skipped"] == 5
    assert b["score_n"] == 0


def test_merge_buckets_splits_on_width():
    rows = [_row(settled=STAT_FINE, done_first=STAT_FINE) for _ in range(7)]
    out = merge_buckets(rows, 500)
    assert [b["settled"] for b in out] == [500, 200]
    assert [b["start"] for b in out] == [0, 500]
    assert [b["end"] for b in out] == [499, 699]


def test_merge_buckets_histogram_and_score_sum():
    hist = {10: 3, 32: 2}                            # 2.0×3 + 4.2×2
    rows = [_row(settled=STAT_FINE, done_first=STAT_FINE,
                 score_sum=3 * 200 + 2 * 420, hist=hist)]
    out = merge_buckets(rows, 100)
    b = out[0]
    assert b["score_n"] == 5
    assert b["score_hist"][10] == 3 and b["score_hist"][32] == 2
    assert b["score_sum"] == pytest.approx(14.4)


def test_job_note_item_rolls_fine_buckets():
    job = Job("t", JobSpec(input_dir="x"), None)
    for i in range(STAT_FINE + 3):
        job.note_item("done" if i % 2 else "failed")
    assert len(job._fine) == 2
    assert job._fine[0][0] == STAT_FINE and job._fine[1][0] == 3
    st = job.stats_buckets(100)
    assert st["settled"] == STAT_FINE + 3
    assert st["buckets"][0]["failed"] == 50
    assert st["buckets"][0]["done_first"] == 50
    assert st["buckets"][1]["failed"] == 2 and st["buckets"][1]["done_first"] == 1


def test_job_note_item_score_histogram_and_avg():
    job = Job("t", JobSpec(input_dir="x"), None)
    job.note_item("done", score=4.2)
    job.note_item("done", score=2.0)
    job.note_item("done", score=9.0)                 # 越界截到 5.0
    b = job.stats_buckets(1000)["buckets"][0]
    assert b["score_n"] == 3
    assert b["score_hist"][32] == 1 and b["score_hist"][10] == 1
    assert b["score_hist"][SCORE_BINS - 1] == 1      # 9.0 → 5.0 格
    assert b["score_sum"] == pytest.approx(4.2 + 2.0 + 5.0)


def test_job_note_item_attempts_split():
    job = Job("t", JobSpec(input_dir="x"), None)
    job.note_item("done", attempts=1)
    job.note_item("done", attempts=3)
    job.note_item("skipped")
    job.note_item("blacklisted")
    st = job.stats_buckets(1000)
    t = st["totals"]
    assert (t["done_first"], t["done_retry"], t["skipped"],
            t["blacklisted"]) == (1, 1, 1, 1)
    assert t["settled"] == 4


def test_job_stats_truncates_zero_hist_tail():
    job = Job("t", JobSpec(input_dir="x"), None)
    job.note_item("done", score=3.1)
    st = job.stats_buckets(1000)
    assert len(st["buckets"][0]["score_hist"]) == 22   # 3.1 → 第 21 格，截到这
    assert st["totals"]["score_hist"] == st["buckets"][0]["score_hist"]


def test_job_stats_old_job_falls_back_to_single_bucket():
    """统计功能上线前的旧任务：没有细桶数据，用当前计数合成单桶。"""
    job = Job("t", JobSpec(input_dir="x"), None)
    job.stats.done, job.stats.skipped, job.stats.total = 4, 1, 5
    st = job.stats_buckets(1000)
    assert len(st["buckets"]) == 1
    b = st["buckets"][0]
    assert b["settled"] == 5 and b["end"] == 4
    assert b["done_first"] == 4 and b["skipped"] == 1
    assert b["score_n"] == 0
    assert st["totals"]["settled"] == 5


def test_job_stats_empty_job_returns_empty_buckets():
    job = Job("t", JobSpec(input_dir="x"), None)
    st = job.stats_buckets(1000)
    assert st["buckets"] == [] and st["settled"] == 0 and st["total"] == 0


# ------------------------------------------------------------------ VLM 桥接

def test_run_vlm_feeds_stats_buckets(tmp_path, monkeypatch):
    script = [
        ("done", Outcome("a-1", True, tag={"tags": [["red", 0.9]]},
                         nl={"score": 4.2}, attempts=1)),
        ("done", Outcome("a-2", True, tag={"tags": [["blue", 0.8]]},
                         nl={"score": 2.0}, attempts=2)),
        ("done", Outcome("a-3", True, attempts=1)),            # tag-only，无分
        ("failed", Outcome("a-4", False, error="坏图", attempts=2)),
        ("skipped", None),
        ("blacklisted", None),
    ]

    def fake_run_client(args, ops, table, on_progress=None, should_stop=None,
                        on_log=None, guard=None, paused=None):
        stats = ClientStats()
        for kind, outcome in script:
            image_id = outcome.image_id if outcome else f"x-{len(stats.by_reason)}"
            task = TaskRow(shard="hf://r/s#m", image_id=image_id,
                           file=f"{image_id}.jpg")
            on_progress(kind, task, outcome, stats)
        stats.total, stats.done, stats.failed = 6, 3, 1
        stats.skipped, stats.blacklisted = 1, 1
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(JobSpec(engine="vlm", hf_repo="org/repo",
                             out_dir=str(tmp_path / "out")))
    mgr._run(job)
    assert job.status == "done"

    st = job.stats_buckets(1000)
    assert st["settled"] == 6 and st["total"] == 6
    t = st["totals"]
    assert t["done_first"] == 2 and t["done_retry"] == 1
    assert t["failed"] == 1 and t["skipped"] == 1 and t["blacklisted"] == 1
    assert t["score_n"] == 2
    b = st["buckets"][0]
    assert b["score_hist"][32] == 1 and b["score_hist"][10] == 1
    # done 的 item 事件带上了 score（tag-only 的不带）
    items = [e for e in job.events_since(0) if e["kind"] == "item"]
    assert next(e for e in items if e["image_id"] == "a-1")["score"] == 4.2
    assert "score" not in next(e for e in items if e["image_id"] == "a-3")


# ------------------------------------------------------------------ 端点

class _FakeBackend:
    name = "fake"
    precision = "bf16"
    batch_size = 1

    def __init__(self):
        self.last_timings = {"total": 5, "decode": 2, "forward": 2}

    def load(self):
        return None

    def predict_batch(self, images):
        from tagger.cpu_tagger import TagPrediction
        return [TagPrediction(tags=[("red", 0.9)], backend="fake",
                              rating={"general": 0.6}) for _ in images]


@pytest.fixture
def client(monkeypatch, tmp_path):
    jobs_mod.MANAGER._jobs.clear()
    monkeypatch.setattr(jobs_mod, "build_backend", lambda *a, **kw: _FakeBackend())
    monkeypatch.setattr(jobs_mod, "resolve_device", lambda s: "cpu")
    monkeypatch.setattr(jobs_mod.JobManager, "_make_guard", lambda self, job: None)
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def _images(tmp_path, n=4):
    src = tmp_path / "in"
    src.mkdir()
    for i in range(n):
        (src / f"{i}.png").write_bytes(b"\x89PNG\r\n\x1a\n")
    return src


def _wait(client, job_id, timeout=8.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        snap = client.get(f"/api/jobs/{job_id}").json()
        if snap["status"] in ("done", "failed", "stopped"):
            return snap
        time.sleep(0.05)
    raise AssertionError(f"任务没在 {timeout}s 内结束：{snap}")


def test_stats_endpoint_local_job(client, tmp_path):
    src = _images(tmp_path, 4)
    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}).json()["id"]
    snap = _wait(client, job_id)

    data = client.get(f"/api/jobs/{job_id}/stats").json()
    assert data["status"] == "done"
    assert data["bucket"] == 1000
    assert data["settled"] == 4 == snap["counts"]["settled"]
    b = data["buckets"][0]
    assert b["start"] == 0 and b["end"] == 3 and b["settled"] == 4
    assert b["done_first"] == 4 and b["done_retry"] == 0   # 本地引擎全是首过
    assert b["score_n"] == 0                               # 没有质检分
    t = data["totals"]
    assert t["done_first"] == 4 and t["failed"] == 0


def test_stats_endpoint_validates_bucket(client, tmp_path):
    src = _images(tmp_path, 1)
    job_id = client.post("/api/jobs", json={"input_dir": str(src),
                                            "out_dir": str(tmp_path / "out")}).json()["id"]
    _wait(client, job_id)
    assert client.get(f"/api/jobs/{job_id}/stats?bucket=333").status_code == 400
    assert client.get(f"/api/jobs/{job_id}/stats?bucket=50").status_code == 400
    assert client.get(f"/api/jobs/{job_id}/stats?bucket=60000").status_code == 400
    assert client.get(f"/api/jobs/{job_id}/stats?bucket=500").status_code == 200
    assert client.get("/api/jobs/nope/stats").status_code == 404
