"""结果缓存与续跑校验。

这两处的失效方式都很安静：
- 缓存 key 漏一项 → 换 seed 重跑拿到旧结果，产物却标成新参数；
- 续跑只看"文件非空" → 换模型重跑会静默复用上一代模型的产出。
所以这里钉的是"参数一变就不许命中 / 不许跳过"。
"""

from __future__ import annotations

import json

from tagger.artist import ArtistRule
from tagger.client import TaskRow, TaggerClient, _existing_ok
from tagger.config import OutputSpec
from tagger.quality import QualityGate, QualityPolicy
from tagger.result_cache import ResultCache


def _client(tmp_path, *, cache=None, seed=None, temperature: float = 0.2,
            prompt_text: str | None = None) -> TaggerClient:
    return TaggerClient(
        base_url="http://127.0.0.1:1",      # 命中路径不会发请求
        model_name="tagger",
        output=OutputSpec(mode="both"),
        temperature=temperature,
        top_p=0.9,
        max_tokens=1024,
        timeout_s=1,
        max_attempts=2,
        gate=QualityGate(QualityPolicy(), verbose=False),
        prov_base={"model_id": "m", "model_revision": "rev",
                   "precision": "fp16", "max_pixels": 589824,
                   "quantization": None, "caption_chars": None},
        artist_rule=ArtistRule(),
        seed=seed,
        prompt_text=prompt_text,
        cache=cache,
    )


def _record(**kw) -> dict:
    base = {
        "temperature": 0.2, "attempts": 1, "tokens": 321, "escalated": False,
        "tag": {"tags": [["red", 1.0], ["square", 0.9]], "rating": {"g": 0.8}},
        "nl": {"caption": "a red square", "score": 4.1,
               "reasons": [], "tag_count": 2},
    }
    base.update(kw)
    return base


# ------------------------------------------------------------------ 库本身


def test_cache_roundtrip(tmp_path):
    c = ResultCache(tmp_path / "c.sqlite3")
    assert c.get("nope") is None
    c.put("k", {"a": 1})
    assert c.get("k") == {"a": 1}
    assert c.hits == 1 and c.misses == 1
    c.close()


def test_cache_evicts_oldest_when_over_limit(tmp_path):
    c = ResultCache(tmp_path / "c.sqlite3", max_bytes=64 * 1024,
                    evict_every=50)
    for i in range(1200):
        c.put(f"k{i}", {"body": "x" * 200})
    info = c.describe()
    assert info["rows"] < 1200
    assert info["evicted"] > 0
    c.close()


# ------------------------------------------------------------------ 命中


def test_cache_hit_skips_inference_and_marks_provenance(tmp_path):
    cache = ResultCache(tmp_path / "c.sqlite3")
    client = _client(tmp_path, cache=cache)
    data = b"fake-image-bytes"
    task = TaskRow(shard="", image_id="img-1", file="img-1.jpg")
    cache.put(client._cache_key(data, task), _record())
    out = client.process(task, data=data)

    assert out.ok and out.cached
    assert out.attempts == 1 and out.tokens == 0    # 本次没花 token
    assert out.tag["tag"] == "red, square"
    assert out.nl["caption"] == "a red square"
    # 两条路都要标出来：顶层给清洗脚本，provenance 给对账
    assert out.tag["cache_hit"] is True
    assert out.nl["provenance"]["cache_hit"] is True
    # ts 必须是本次的，不是缓存里那次的
    assert out.nl["ts"] > 0
    cache.close()


def test_cache_miss_falls_through(tmp_path):
    cache = ResultCache(tmp_path / "c.sqlite3")
    client = _client(tmp_path, cache=cache)
    assert client.process(TaskRow(shard="", image_id="img-2", file="a.jpg"),
                          data=b"other-bytes").ok is False
    assert cache.hits == 0
    cache.close()


# ------------------------------------------------------------------ 指纹


def test_fingerprint_separates_run_params(tmp_path):
    base = _client(tmp_path, cache=ResultCache(tmp_path / "a.db"))
    other_seed = _client(tmp_path, cache=ResultCache(tmp_path / "b.db"), seed=7)
    other_temp = _client(tmp_path, cache=ResultCache(tmp_path / "c.db"),
                         temperature=0.7)
    other_prompt = _client(tmp_path, cache=ResultCache(tmp_path / "d.db"),
                           prompt_text="completely different instructions")
    assert len({base.cache_prefix, other_seed.cache_prefix,
                other_temp.cache_prefix, other_prompt.cache_prefix}) == 4


def test_fingerprint_is_stable_for_same_params(tmp_path):
    a = _client(tmp_path, cache=ResultCache(tmp_path / "a.db"))
    b = _client(tmp_path, cache=ResultCache(tmp_path / "b.db"))
    assert a.cache_prefix == b.cache_prefix


# ------------------------------------------------------------------ 续跑校验


def test_existing_ok_rechecks_provenance(tmp_path):
    p = tmp_path / "x.tag.json"
    p.write_text(json.dumps({"tag": "red",
                             "provenance": {"model_id": "old",
                                            "max_pixels": 589824}}),
                 encoding="utf-8")
    assert _existing_ok(p, "tag", {"model_id": "old"})
    # 换了模型：不许跳过
    assert not _existing_ok(p, "tag", {"model_id": "new"})
    # 类型差异不算"参数变了"（int vs str）
    assert _existing_ok(p, "tag", {"max_pixels": "589824"})
    # 老产物没有这个字段：按无法判定放行，否则升级后要整批重打
    assert _existing_ok(p, "tag", {"precision": "fp16"})


def test_existing_ok_still_requires_content(tmp_path):
    p = tmp_path / "x.nl.json"
    p.write_text(json.dumps({"caption": "  ", "provenance": {}}),
                 encoding="utf-8")
    assert not _existing_ok(p, "caption")
