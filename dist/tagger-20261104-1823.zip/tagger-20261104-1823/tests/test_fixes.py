"""本轮 bug 修复的针对性回归。

每条对应一个"以前静默出错、现在要么做对要么报错"的点：

    - 客户端像素预算：基线缩图只在该出手时出手；重试提分辨率要真的把
      原始字节按抬高后的预算重新发出去
    - FTP 续传：先对尾巴再 APPE，对不上就整体重传；远端目录要停对位置
    - 分包序号溢出：静默扩位 → 显式报错
    - 报告完整率口径：require 语义统一（any/both/tag/nl）
    - 扩展名：没见过的保留原样并警告一次，不再偷偷兜成 .jpg
    - onnx 词表：四种形态都能读，空名字占位不错位
    - HF 列分片：跟随 Link 头翻页，不丢第 1000 条之后的分片
    - merge：多出的产出记进 extra_ids，不再混进"读不了"
    - parquet 分片序号：取现存最大号 + 1，不因人工删片而撞号
"""

from __future__ import annotations

import base64
import ftplib
import io
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from PIL import Image

from tagger import hf_source
from tagger.client import TaskRow, TaggerClient, _resize_to_budget
from tagger.config import ConfigError, OutputSpec
from tagger.cpu_tagger import _read_vocab
from tagger.distribute import DistItem, assign_ids
from tagger.merge import check, collect
from tagger.naming import normalize_ext
from tagger.report import collect_points
from tagger.upload import FtpConfig, FtpUploader


# ------------------------------------------------------------------ 客户端像素预算

GOOD_TEXT = "<TAGS>red</TAGS>\n<CAPTION>A red square.</CAPTION>"


class _FakeHTTP:
    """记录每次请求里图片的实际像素，回一段两块齐全的文本。"""

    def __init__(self):
        self.sizes: list[tuple[int, int]] = []

    def post(self, url, json=None):
        part = json["messages"][1]["content"][0]
        b64 = part["image_url"]["url"].split(",", 1)[1]
        im = Image.open(io.BytesIO(base64.b64decode(b64)))
        self.sizes.append(im.size)
        body = {"choices": [{"message": {"content": GOOD_TEXT}}],
                "usage": {"completion_tokens": 5}}
        return SimpleNamespace(status_code=200, text="", json=lambda: body)

    def close(self):
        pass


class _ScriptGate:
    """按 attempt 回放 verdict，并记下每次质检收到的像素预算。"""

    def __init__(self, script):
        self.script = script
        self.seen_max_pixels: list[int] = []

    def evaluate(self, ann, *, attempt=0, image=None, temperature=0.2,
                 max_pixels=0):
        self.seen_max_pixels.append(max_pixels)
        return self.script[min(attempt, len(self.script) - 1)]


def _client(http, gate, *, base_pixels: int, pixel_cap: int) -> TaggerClient:
    from tagger.artist import ArtistRule
    from tagger.client import StageTimer

    client = TaggerClient(
        base_url="http://127.0.0.1:9", model_name="bench",
        output=OutputSpec(mode="both", tag_min_count=1, tag_max_count=10),
        temperature=0.2, top_p=0.9, max_tokens=64, timeout_s=5, max_attempts=2,
        gate=gate,
        prov_base={"model_id": "bench", "precision": "bf16",
                   "max_pixels": base_pixels},
        artist_rule=ArtistRule(), tag_backend=None, stage=StageTimer(),
        pixel_cap=pixel_cap,
    )
    client._http = http
    return client


def test_retry_escalation_sends_original_bytes(make_png):
    """重试提分辨率：attempt 0 按基线缩，重试按抬高后的预算发原始字节。"""
    data = make_png(size=(100, 100))                   # 10000 px，远超基线 1000
    retry = SimpleNamespace(level="retry", score=0.1, reasons=["太糊"],
                            retry=SimpleNamespace(temperature=0.7,
                                                  max_pixels=4000))
    ok = SimpleNamespace(level="pass", score=1.0, reasons=[], retry=None)
    gate = _ScriptGate([retry, ok])
    http = _FakeHTTP()
    client = _client(http, gate, base_pixels=1000, pixel_cap=4000)

    outcome = client.process(TaskRow(shard="s", image_id="i1", file="i1.png"),
                             data=data)
    client.close()

    assert outcome.ok is True
    assert outcome.attempts == 2
    # 质检收到的是逐次抬高的预算，不是恒定的基线
    assert gate.seen_max_pixels == [1000, 4000]
    w0, h0 = http.sizes[0]
    assert w0 * h0 <= 1000                             # attempt 0：客户端压到基线内
    assert http.sizes[1] == (100, 100)                 # 重试：原始字节（服务端会钳到 cap）


def test_no_client_resize_when_budget_meets_server_cap(make_png):
    """预算已到服务端钳制：客户端不再缩（服务端会做同一件事），发原图。"""
    data = make_png(size=(100, 100))
    ok = SimpleNamespace(level="pass", score=1.0, reasons=[], retry=None)
    gate = _ScriptGate([ok])
    http = _FakeHTTP()
    client = _client(http, gate, base_pixels=4000, pixel_cap=4000)

    outcome = client.process(TaskRow(shard="s", image_id="i2", file="i2.png"),
                             data=data)
    client.close()

    assert outcome.ok is True
    assert http.sizes == [(100, 100)]


def test_resize_to_budget_flattens_alpha_and_keeps_aspect(
        make_png, make_rgba_png):
    small = make_png(size=(8, 8))
    assert _resize_to_budget(small, 10_000) == small   # 已在预算内：原样返回

    rgba = make_rgba_png(alpha=0)                      # 全透明红
    out = _resize_to_budget(rgba, 16)                  # 8×8=64 → 约 4×4
    im = Image.open(io.BytesIO(out))
    assert im.mode == "RGB"                            # alpha 压平成白底
    assert im.size[0] * im.size[1] <= 16
    assert im.getpixel((0, 0)) == (255, 255, 255)


# ------------------------------------------------------------------ FTP 上传


class _FakeFTP:
    """只实现 FtpUploader 用到的调用，远端文件状态留在内存里。"""

    def __init__(self):
        self.files: dict[str, bytes] = {}
        self.events: list[str] = []
        self.corrupt_tail = False

    def voidcmd(self, cmd):
        self.events.append(cmd)

    def sendcmd(self, cmd):
        self.events.append(cmd)

    def delete(self, name):
        self.events.append(f"DELETE {name}")
        self.files.pop(name, None)

    def size(self, name):
        data = self.files.get(name)
        return len(data) if data is not None else None

    def retrbinary(self, cmd, cb, blocksize=8192, rest=0):
        name = cmd.split(None, 1)[1]
        data = self.files[name][rest:]
        if self.corrupt_tail:
            data = b"\x00" * len(data)
        cb(data)

    def storbinary(self, cmd, f, blocksize=8192):
        op, name = cmd.split(None, 1)
        data = f.read()
        if op == "APPE":
            self.files[name] = self.files.get(name, b"") + data
        else:
            self.files[name] = data
        self.events.append(op)


def _uploader(fake) -> FtpUploader:
    up = FtpUploader(FtpConfig(host="h", user="u", password="p"),
                     verbose=False)
    up._ftp = fake
    return up


def test_upload_matching_tail_resumes_with_appe(tmp_path):
    local = bytes(range(256)) * 400                    # 102400 字节
    path = tmp_path / "x.zip"
    path.write_bytes(local)

    fake = _FakeFTP()
    fake.files["x.zip.part"] = local[:50000]           # 半截且内容接得上
    res = _uploader(fake)._upload_once(path, "x.zip.part", allow_resume=True)

    assert res.ok is True and res.resumed is True
    assert res.bytes_sent == len(local) - 50000
    assert fake.files["x.zip.part"] == local           # 缝出来正好是原文件
    assert "APPE" in fake.events and "STOR" not in fake.events


def test_upload_mismatched_tail_falls_back_to_full_stor(tmp_path):
    """远端残骸内容对不上（可能是另一个文件的 .part）：必须整体重传。"""
    local = bytes(range(256)) * 400
    path = tmp_path / "x.zip"
    path.write_bytes(local)

    fake = _FakeFTP()
    fake.files["x.zip.part"] = local[:50000]
    fake.corrupt_tail = True
    res = _uploader(fake)._upload_once(path, "x.zip.part", allow_resume=True)

    assert res.ok is True and res.resumed is False
    assert any(e.startswith("DELETE") for e in fake.events)   # 先清掉残骸
    assert "STOR" in fake.events
    assert fake.files["x.zip.part"] == local           # 不是缝出来的拼接物


class _DirFakeFTP:
    def __init__(self, missing: set[str] | None = None):
        self.cwd_history: list[str] = []
        self.made: list[str] = []
        self._missing = missing or set()

    def cwd(self, path):
        if path in self._missing and path not in self.made:
            raise ftplib.error_perm("550 no such directory")
        self.cwd_history.append(path)

    def mkd(self, path):
        self.made.append(path)


def test_ensure_remote_dir_parks_connection_in_target_dir():
    fake = _DirFakeFTP()
    up = FtpUploader(FtpConfig(host="h", user="u", password="p",
                               remote_dir="bucket/runs"), verbose=False)
    up._ftp = fake
    up._ensure_remote_dir()
    # 连接要停在 remote_dir 里。以前最后一句 cwd("/") 让它白停在根目录，
    # 后续裸文件名的 storbinary 全落根目录。
    assert fake.cwd_history == ["bucket", "bucket/runs"]
    assert fake.made == []


def test_ensure_remote_dir_creates_missing_levels():
    fake = _DirFakeFTP(missing={"bucket"})
    up = FtpUploader(FtpConfig(host="h", user="u", password="p",
                               remote_dir="bucket/runs"), verbose=False)
    up._ftp = fake
    up._ensure_remote_dir()
    assert fake.made == ["bucket"]
    assert fake.cwd_history == ["bucket", "bucket/runs"]


# ------------------------------------------------------------------ 分包序号


def _dist_items(n: int, artist: str = "alice") -> list[DistItem]:
    return [DistItem(source="a.zip", member=f"{i}.jpg", rel_path=f"{i}.jpg",
                     artist=artist, size=1, ext=".jpg") for i in range(n)]


def test_assign_ids_overflow_raises_instead_of_silent_widening():
    # 1 位序号只能表示 1~9。以前第 10 张起 f"{n:01d}" 静默变成 2 位，
    # 字典序全乱，merge 的区间对账跟着失真，且 id 已发出去改不回来。
    with pytest.raises(ConfigError):
        assign_ids(_dist_items(10), seq_width=1)


def test_assign_ids_within_width_still_numbered():
    items = assign_ids(_dist_items(9), seq_width=1)
    assert [i.image_id for i in items] == [f"alice-{n}" for n in range(1, 10)]


# ------------------------------------------------------------------ 报告口径


def test_collect_points_require_any_vs_both(tmp_path, write_artifact):
    root = tmp_path / "member"
    write_artifact(root, "ok-000001", tag="red", caption="A red square.",
                   tag_count=1, chars=13)
    write_artifact(root, "tagonly-000002", tag="blue", tag_count=1)

    pts = {p.image_id: p for p in collect_points([root], require="any")}
    assert pts["ok-000001"].ok is True
    assert pts["tagonly-000002"].ok is True            # tag-only 也算完整

    pts2 = {p.image_id: p for p in collect_points([root], require="both")}
    assert pts2["ok-000001"].ok is True
    assert pts2["tagonly-000002"].ok is False          # nl 缺失 → 不完整


def test_collect_points_require_tag_and_nl(tmp_path, write_artifact):
    root = tmp_path / "member"
    write_artifact(root, "tagonly-000001", tag="red", tag_count=1)
    write_artifact(root, "nlonly-000002", caption="A red square.", chars=13)

    pts = {p.image_id: p for p in collect_points([root], require="tag")}
    assert pts["tagonly-000001"].ok is True
    assert pts["nlonly-000002"].ok is False

    pts = {p.image_id: p for p in collect_points([root], require="nl")}
    assert pts["tagonly-000001"].ok is False
    assert pts["nlonly-000002"].ok is True


# ------------------------------------------------------------------ 扩展名


def test_normalize_ext_unknown_kept_and_warned_once(capsys):
    from tagger import naming

    naming._WARNED_EXTS.clear()
    assert normalize_ext("x.JPG") == ".jpg"            # 已知映射照常归一
    assert normalize_ext("y.avif") == ".avif"          # 保留，不再兜成 .jpg
    assert ".avif" in capsys.readouterr().out
    assert normalize_ext("z.avif") == ".avif"
    assert capsys.readouterr().out == ""               # 同格式只警告一次
    assert normalize_ext("noext") == ".jpg"            # 无扩展名兜 .jpg


# ------------------------------------------------------------------ onnx 词表


def _vocab(tmp_path: Path, obj, name="selected_tags.json"):
    p = tmp_path / name
    p.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
    return _read_vocab(p)


def test_read_vocab_four_shapes(tmp_path):
    names, cats = _vocab(tmp_path, ["1girl", "red"])
    assert (names, cats) == (["1girl", "red"], ["general", "general"])

    names, cats = _vocab(tmp_path, [
        {"name": "1girl", "category": 0},
        {"name": "red", "category": "general"},
        {"name": "hatsune_miku", "category": 4},
        {"name": "masterpiece", "category": 9},
    ])
    assert names == ["1girl", "red", "hatsune_miku", "masterpiece"]
    assert cats == ["general", "general", "character", "rating"]

    names, _ = _vocab(tmp_path, {"tags": ["1girl", "red"]})
    assert names == ["1girl", "red"]

    names, cats = _vocab(tmp_path, {"0": "1girl", "1": "red"})
    assert names == ["1girl", "red"]
    assert cats == ["general", "general"]


def test_read_vocab_keeps_empty_name_as_placeholder(tmp_path):
    """空名字占位不丢弃：丢一个，后面所有 tag 与分类头输出整体错位一格。"""
    names, cats = _vocab(tmp_path, [
        {"name": "1girl", "category": 0},
        {"name": "", "category": 4},
        {"name": "red"},
    ])
    assert names == ["1girl", "", "red"]
    assert cats == ["general", "character", "general"]


# ------------------------------------------------------------------ HF 列分片


def test_list_shards_follows_link_pagination(monkeypatch):
    pages = [
        [{"path": "shards/shard-00000.tar", "type": "file"},
         {"path": "README.md", "type": "directory"}],
        [{"path": "shards/shard-00001.tar", "type": "file"}],
    ]
    seen: list = []

    class _Resp:
        def __init__(self, entries, nxt=None):
            self._entries = entries
            self.status_code = 200
            self.links = {"next": {"url": nxt}} if nxt else {}

        def json(self):
            return self._entries

        def raise_for_status(self):
            pass

    class _Client:
        def __init__(self, **kw):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def get(self, url, headers=None, params=None):
            seen.append(params)
            if len(seen) == 1:
                base = url.split("?")[0]
                return _Resp(pages[0], nxt=f"{base}?cursor=abc")
            return _Resp(pages[1])

    monkeypatch.setattr(hf_source.httpx, "Client", _Client)
    got = hf_source.list_shards("org/ds", pattern="*.tar")

    assert got == ["shards/shard-00000.tar", "shards/shard-00001.tar"]
    assert seen[0] == {"recursive": "true"}
    assert seen[1] is None     # 翻页后不带原参数（next url 里已含游标）


# ------------------------------------------------------------------ merge 多出产出


def test_extra_outputs_go_to_extra_ids_not_unreadable(tmp_path, write_artifact):
    root = tmp_path / "member"
    write_artifact(root, "x-000002", tag="red", caption="A red square.",
                   tag_count=1, chars=13)
    write_artifact(root, "surprise-000009", tag="blue", caption="Blue.",
                   tag_count=1, chars=5)

    records = collect([root])
    stats = check(records, expected_ids=["x-000002"], require="any")

    assert stats.extra_ids == ["surprise-000009"]      # 多出的产出，单列
    assert "surprise-000009" not in stats.unreadable   # 不再混进"读不了"
    assert "surprise-000009" not in stats.missing_ids
    summary = "\n".join(stats.summary_lines())
    assert "不在分发表" in summary


# ------------------------------------------------------------------ parquet 序号


def test_parquet_sink_seq_continues_after_deleted_middle_shard(tmp_path):
    """中间一片被人工删掉后，新分片号必须接在现存最大号后面，不许撞号。"""
    pytest.importorskip("pyarrow")
    from tagger.artifacts import ParquetSink

    out = tmp_path / "out"
    out.mkdir()
    (out / "artifacts-000000.parquet").write_bytes(b"stub")
    (out / "artifacts-000002.parquet").write_bytes(b"stub")

    sink = ParquetSink(out, rows_per_file=2)
    assert sink._seq == 3      # 取最大号+1；按文件个数算是 2，会覆盖 000002


# ------------------------------------------------------------------ 溯源清单


def test_provenance_schema_matches_real_payload_keys():
    """schema 的 Provenance 清单必须与产物里真实的 provenance 键一一对应。

    Provenance 是 Annotation.from_jsonl 读回产物的构造器：清单漏一个键，
    读回就在 Provenance(**prov) 上炸 TypeError；多一个键就是文档撒谎。
    """
    from tagger.client import _prov_base
    from tagger.schema import Provenance

    fp = {"model_id": "qwen3vl-8b@abc123", "model_path": "models/qwen",
          "model_revision": "main", "precision": "bf16", "max_pixels": 589824,
          "vllm_version": "0.6.3", "device": "NVIDIA RTX 4090"}
    ok = SimpleNamespace(level="pass", score=1.0, reasons=[], retry=None)
    client = _client(_FakeHTTP(), _ScriptGate([ok]), base_pixels=589824,
                     pixel_cap=0)
    client.prov_base = _prov_base(fp, model_id=fp["model_id"],
                                  max_pixels=589824, tier="mid-24g")

    slots = set(Provenance.__slots__)
    # NL 产物：没有 tag 专属的三个字段；variant / cache_hit 是条件写入的
    assert set(client._provenance(0.2)) == slots - {
        "variant", "tag_backend", "tag_precision", "tag_preprocess", "cache_hit"}
    # tag 产物：多出 tag_backend / tag_precision / tag_preprocess
    assert set(client._provenance(0.2, tag=True)) == slots - {
        "variant", "cache_hit"}
    # AB 变体启用时 variant 也要在清单里
    client.variant = "b"
    assert set(client._provenance(0.2, tag=True)) == slots - {"cache_hit"}
    # 命中缓存时才写 cache_hit
    assert "cache_hit" in client._provenance(0.2, cache_hit=True)

    # 真实键位必须能原样构造并读回（from_jsonl 的前提）
    prov = Provenance(**client._provenance(0.2, tag=True))
    assert prov.model_id == fp["model_id"]
    assert prov.prompt_sha                       # 客户端实际在写，清单以前漏了
    assert prov.tag_backend == "vlm"
