"""测试共用的小工具。

刻意不引入额外依赖：造图只用 Pillow，造包只用标准库 zipfile/tarfile。
测试要能在任何一台成员机上跑起来——如果测试本身要求装了 pyarrow，
那它就不是安全网，而是又一道门槛。
"""

from __future__ import annotations

import io
import json
import os
import tempfile
import zipfile
from pathlib import Path

import pytest
from PIL import Image

# 必须在 tagger.web.jobs 被 import 之前设好（conftest 是最先加载的）。
# 用环境变量而不是只靠 monkeypatch：测试里拉起子进程时，子进程不继承
# monkeypatch，但继承环境变量。
os.environ.setdefault(
    "TAGGER_RESUME_PATH",
    str(Path(tempfile.gettempdir()) / "tagger-test-resume.json"),
)


@pytest.fixture(autouse=True)
def _isolate_resume_file(tmp_path, monkeypatch):
    """测试不许写真实的 run/resume.json。

    任务被 stop 时会顺手写一份续做记录，而测试里的任务用的是 pytest 的临时
    目录。不隔离的话，跑一次测试就会把用户页面上「上次的任务没跑完，继续？」
    换成一条指向临时目录的假记录（临时目录还没被清掉时它会真的可点）。
    """
    from tagger.web import jobs as jobs_mod

    monkeypatch.setattr(jobs_mod, "RESUME_PATH", tmp_path / "resume.json")


@pytest.fixture
def make_png():
    """造 PNG 字节。mode/color 直接对应要测的分支。"""

    def _make(
        *,
        mode: str = "RGB",
        size: tuple[int, int] = (8, 8),
        color: tuple[int, ...] = (10, 20, 30),
    ) -> bytes:
        im = Image.new(mode, size, color)
        buf = io.BytesIO()
        im.save(buf, "PNG")
        return buf.getvalue()

    return _make


@pytest.fixture
def make_rgba_png():
    """带真 alpha 的 PNG。alpha=0 的区域压平后应当是白色。"""

    def _make(alpha: int = 0, rgb: tuple[int, int, int] = (255, 0, 0)) -> bytes:
        im = Image.new("RGBA", (8, 8), (*rgb, alpha))
        buf = io.BytesIO()
        im.save(buf, "PNG")
        return buf.getvalue()

    return _make


@pytest.fixture
def make_palette_png():
    """调色板 + transparency 的 PNG。这是最容易被漏掉的一支 alpha 变体。"""

    def _make() -> bytes:
        im = Image.new("P", (8, 8), 0)
        palette = [255, 0, 0] + [0] * (256 * 3 - 3)
        im.putpalette(palette)
        buf = io.BytesIO()
        im.save(buf, "PNG", transparency=0)
        return buf.getvalue()

    return _make


@pytest.fixture
def make_zip():
    """把 {成员名: bytes} 打成 zip。"""

    def _make(path: Path, members: dict[str, bytes]) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, "w") as zf:
            for name, data in members.items():
                zf.writestr(name, data)
        return path

    return _make


@pytest.fixture
def write_artifact():
    """写一份成员产物（<id>-tag.json / <id>-nl.json）。"""

    def _write(
        root: Path,
        image_id: str,
        *,
        tag: str | None = None,
        caption: str | None = None,
        tag_count: int | None = None,
        chars: int | None = None,
        nl_tokens: int = 0,
        score: float = 0.0,
        flags: list[str] | None = None,
        ts: float = 0.0,
    ) -> None:
        root.mkdir(parents=True, exist_ok=True)
        if tag is not None:
            payload = {
                "image_id": image_id,
                "tag": tag,
                "tags": [[t, 1.0] for t in tag.split(",") if t.strip()],
                "ok": True,
                "ts": ts,
            }
            (root / f"{image_id}-tag.json").write_text(
                json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        if caption is not None:
            payload = {
                "image_id": image_id,
                "caption": caption,
                "tag_count": tag_count if tag_count is not None else 0,
                "chars": chars if chars is not None else len(caption),
                "nl_tokens": nl_tokens,
                "score": score,
                "flags": flags or [],
                "ok": True,
                "ts": ts,
            }
            (root / f"{image_id}-nl.json").write_text(
                json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    return _write
