"""命令行参数面的守卫。

abtest 是继承 client 参数拼出来的，继承一旦断了（父解析器改动、
defaults 被覆盖），症状是"参数看着对但没生效"，很难在代码里看出来。
所以这里直接断言解析结果。
"""

from __future__ import annotations

from tagger.cli import build_parser


def test_report_defaults_come_from_command_line_and_config():
    args = build_parser().parse_args(["report", "--roots", "r1", "r2"])
    assert args.roots == ["r1", "r2"]
    assert args.batch_size == 0          # 0 = 交给配置决定
    assert args.order is None
    assert args.json_out.endswith("report.json")


def test_report_batch_size_override():
    args = build_parser().parse_args(["report", "--batch-size", "250"])
    assert args.batch_size == 250


def test_every_subcommand_help_renders():
    """help 文本里的 `%` 会被 argparse 当格式符。

    写的时候一句 "约 0.9% 会翻面" 就能让 `tagger client --help` 抛
    ValueError: unsupported format character —— 而 --help 崩了，
    用户连参数都看不到。所以每个子命令都真的渲染一遍。
    """
    parser = build_parser()
    for action in parser._subparsers._group_actions:  # noqa: SLF001
        for name, sub in action.choices.items():
            text = sub.format_help()
            assert name and text


def test_tag_precision_and_batch_default_to_unset():
    """默认不写死：交给 client 里的配置兜底（tf32 / 1），
    这样配置文件也能管这两项。"""
    args = build_parser().parse_args(["client", "--shard", "work/dist"])
    assert args.tag_precision is None
    assert args.tag_batch is None


def test_tag_precision_choices():
    import pytest

    args = build_parser().parse_args(
        ["client", "--shard", "work/dist", "--tag-precision", "bf16", "--tag-batch", "4"])
    assert args.tag_precision == "bf16"
    assert args.tag_batch == 4
    with pytest.raises(SystemExit):
        build_parser().parse_args(
            ["client", "--shard", "work/dist", "--tag-precision", "int8"])


def test_abtest_inherits_client_arguments_and_overrides_out_dir():
    args = build_parser().parse_args([
        "abtest", "--variants", "base", "detail",
        "--shard", "work/dist", "--limit", "50", "--concurrency", "4",
    ])
    assert args.variants == ["base", "detail"]
    assert args.shard == ["work/dist"]
    assert args.limit == 50
    assert args.concurrency == 4
    # 变体必须落在各自的子目录下，所以默认根目录不能沿用 client 的 work/out
    assert args.out_dir == "work/ab"
    assert args.func.__name__ == "cmd_abtest"


def test_client_accepts_variant():
    args = build_parser().parse_args(["client", "--shard", "x.zip",
                                      "--variant", "detail"])
    assert args.variant == "detail"
    assert args.func.__name__ == "cmd_client"


def test_merge_accepts_shard_table():
    args = build_parser().parse_args(["merge", "--roots", "m1", "--table",
                                      "work/shards.json"])
    assert args.table == "work/shards.json"


def test_verify_mode_defaults_to_config_and_can_be_overridden():
    """tag 模式的批次按 both 复核会把每条都判成"缺 nl"——那不是数据坏了。"""
    args = build_parser().parse_args(["verify", "--out-dir", "work/out"])
    assert args.mode is None             # None = 用配置的 output.mode

    args = build_parser().parse_args(["verify", "--out-dir", "work/out",
                                      "--mode", "tag"])
    assert args.mode == "tag"
