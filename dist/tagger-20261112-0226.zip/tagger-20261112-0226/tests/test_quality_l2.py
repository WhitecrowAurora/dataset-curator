"""质检 L2 / 重试升级 / file:// 传图：三条以前只能改配置文件或命令行的链路。

这三个开关的共同点是"打开之后行为会变，而且变错了不报错"：
CLIP 打开却收不到图 → 分数永远缺失；升级配了却不生效 → 全是小模型的产物；
file:// 放行目录没覆盖产物目录 → 每张图 400。所以每条都要钉住它真的接上了。
"""

from __future__ import annotations

import base64
import io
import types
from types import SimpleNamespace

import pytest
from PIL import Image

from tagger.client import TaskRow, TaggerClient
from tagger.config import OutputSpec
from tagger.model_loader import build_command
from tagger.web.jobs import JobManager, JobSpec

GOOD_TEXT = "<TAGS>red</TAGS>\n<CAPTION>A red square on a white background.</CAPTION>"


class _FakeHTTP:
    """记录每个端点上收到的图片，回一段两块齐全的文本。"""

    def __init__(self, text: str = GOOD_TEXT):
        self.text = text
        self.urls: list[str] = []

    def post(self, url, json=None):
        self.urls.append(url)
        body = {"choices": [{"message": {"content": self.text}}],
                "usage": {"completion_tokens": 5}}
        return SimpleNamespace(status_code=200, text="", json=lambda: body)

    def close(self):
        pass


class _Gate:
    """可脚本化的质检门，同时记下 CLIP 收到的图片与像素预算。"""

    def __init__(self, script, clip=None):
        self.script = script
        self.clip = clip
        self.seen_images: list[object] = []
        self.seen_max_pixels: list[int] = []

    def evaluate(self, ann, *, attempt=0, image=None, temperature=0.2,
                 max_pixels=0):
        self.seen_images.append(image)
        self.seen_max_pixels.append(max_pixels)
        return self.script[min(attempt, len(self.script) - 1)]


class _FakeClip:
    available = True
    reason = ""

    def score(self, image, caption):
        return 0.9


def _pass():
    return SimpleNamespace(level="pass", score=4.2, reasons=[], retry=None)


def _retry(**kw):
    plan = SimpleNamespace(temperature=0.7, max_pixels=0, model_hint="same")
    for k, v in kw.items():
        setattr(plan, k, v)
    return SimpleNamespace(level="retry", score=2.0, reasons=["太糊"], retry=plan)


def _client(gate, *, http=None, base_pixels=0, pixel_cap=0, **kw) -> TaggerClient:
    from tagger.artist import ArtistRule
    from tagger.client import StageTimer

    client = TaggerClient(
        base_url="http://127.0.0.1:9", model_name="bench",
        output=OutputSpec(mode="both", tag_min_count=1, tag_max_count=10),
        temperature=0.2, top_p=0.9, max_tokens=64, timeout_s=5, max_attempts=2,
        gate=gate,
        prov_base={"model_id": "bench", "precision": "bf16",
                   "max_pixels": base_pixels},
        artist_rule=ArtistRule(), tag_backend=None, stage=StageTimer(),
        pixel_cap=pixel_cap, **kw,
    )
    if http is not None:
        client._http = http
    return client


# ------------------------------------------------------------------ L2 接线

def test_clip_receives_the_image(make_png):
    """开启 CLIP 后质检必须真的拿到图——否则 L2 永远出不了分。"""
    data = make_png(size=(16, 16))
    gate = _Gate([_pass()], clip=_FakeClip())
    client = _client(gate, http=_FakeHTTP())

    outcome = client.process(TaskRow(shard="s", image_id="i1", file="i1.png"),
                             data=data)
    client.close()

    assert outcome.ok
    img = gate.seen_images[0]
    assert isinstance(img, Image.Image)
    assert img.size == (16, 16)


def test_clip_off_does_not_decode_the_image(make_png):
    """没开 CLIP 时不该为质检多解一次码：那是每张图都付的成本。"""
    gate = _Gate([_pass()], clip=None)
    client = _client(gate, http=_FakeHTTP())

    client.process(TaskRow(shard="s", image_id="i2", file="i2.png"),
                   data=make_png())
    client.close()

    assert gate.seen_images == [None]


def test_clip_unavailable_degrades_to_l1():
    """缺 open_clip 时 ClipScorer 不抛异常，只把自己标成不可用并给出原因。"""
    from tagger.quality import ClipScorer

    scorer = ClipScorer("ViT-L-14", "openai")
    if scorer.available:
        pytest.skip("本机装了 open_clip，这条只验证缺依赖时的降级")
    assert scorer.reason
    assert "pip install open_clip_torch" in scorer.reason
    assert scorer.score(object(), "x") is None


# ------------------------------------------------------------------ 重试升级

def test_escalation_hits_the_second_endpoint():
    """model_hint=escalate 时必须打到第二个地址，而不是继续问主服务。"""
    main, big = _FakeHTTP(), _FakeHTTP()
    gate = _Gate([_retry(model_hint="escalate"), _pass()])
    client = _client(gate, http=main, escalate_url="http://127.0.0.1:8001",
                     escalate_model="tagger-8b")
    client._escalate_http = big

    outcome = client.process(TaskRow(shard="s", image_id="i3", file="i3.png"),
                             data=b"\x89PNG-not-really")
    client.close()

    assert outcome.ok
    assert len(main.urls) == 1 and len(big.urls) == 1
    assert big.urls[0].startswith("http://127.0.0.1:8001/")


def test_escalation_is_recorded_in_provenance():
    """升级出来的样本要能被清洗侧整批挑出来——两套权重不能当同一批数据。"""
    main, big = _FakeHTTP(), _FakeHTTP()
    gate = _Gate([_retry(model_hint="escalate"), _pass()])
    client = _client(gate, http=main, escalate_url="http://127.0.0.1:8001",
                     escalate_model="tagger-8b")
    client._escalate_http = big

    outcome = client.process(TaskRow(shard="s", image_id="i4", file="i4.png"),
                             data=b"\x89PNG-not-really")
    client.close()

    prov = outcome.nl["provenance"]
    assert prov["escalated"] is True
    assert prov["escalated_model"] == "tagger-8b"


def test_no_escalation_endpoint_keeps_main_model():
    """没配第二个服务时，model_hint=escalate 也只打主服务，且不留升级标记。"""
    main = _FakeHTTP()
    gate = _Gate([_retry(model_hint="escalate"), _pass()])
    client = _client(gate, http=main)

    outcome = client.process(TaskRow(shard="s", image_id="i5", file="i5.png"),
                             data=b"\x89PNG-not-really")
    client.close()

    assert len(main.urls) == 2
    assert "escalated" not in outcome.nl["provenance"]


def test_escalation_needs_both_url_and_model(capsys):
    """只配一半时明确警告并保持关闭：静默不生效比报错更难查。"""
    client = _client(_Gate([_pass()]), escalate_url="http://127.0.0.1:8001")
    try:
        assert client._escalate_http is None
        assert client.escalate_model == ""
        assert "只有一半" in capsys.readouterr().err
    finally:
        client.close()


# ------------------------------------------------------------------ file:// 放行

def test_allowed_local_media_path_reaches_the_command(tmp_path):
    """放行目录必须变成 --allowed-local-media-path，否则 file:// 每张都 400。"""
    from tagger.config import load_tier_table, resolve_profile
    from tagger.hardware import query_gpus

    gpus = query_gpus()
    if not gpus:
        pytest.skip("没有 NVIDIA 卡，分档解析不出来")
    profile = resolve_profile(load_tier_table("configs/tiers.yaml"), gpus[0])
    cmd = build_command(profile, port=8000, data_root=str(tmp_path))
    flag = cmd.index("--allowed-local-media-path")
    assert cmd[flag + 1] == str(tmp_path.resolve())
    # 不给就不该出现：默认只收 base64
    assert "--allowed-local-media-path" not in build_command(profile, port=8000)


def test_media_root_is_rejected_when_missing(tmp_path):
    """放行一个不存在的目录：vLLM 起得来但每张都 400，必须在启动前拦住。"""
    from tagger.web.vllm_service import VllmService

    svc = VllmService()
    with pytest.raises(ValueError, match="放行目录不存在"):
        svc.start(port=8037, local_media_root=str(tmp_path / "nope"))


# ------------------------------------------------------------------ 表单 → 配置

def _run_vlm_ops(monkeypatch, tmp_path, **kw) -> dict:
    """跑一次 VLM 任务，把传给 run_client 的 ops 抓出来。"""
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw2):
        seen["ops"] = ops
        seen["args"] = args
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    spec = JobSpec(engine="vlm", out_dir=str(tmp_path / "out"), hf_repo="org/r",
                   guard=False, **kw)
    mgr._run(mgr.create(spec))
    return seen


def test_retry_ladder_reaches_the_policy(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path, quality_retry_temp_step=0.25,
                        quality_retry_temp_cap=0.9,
                        quality_retry_pixels_scale=2.0,
                        quality_retry_pixels_cap=2097152)
    q = seen["ops"].quality
    assert q["retry_temp_step"] == 0.25
    assert q["retry_temp_cap"] == 0.9
    assert q["retry_pixels_scale"] == 2.0
    assert q["retry_pixels_cap"] == 2097152


def test_retry_ladder_zero_means_follow_config(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path)
    q = seen["ops"].quality
    assert "retry_temp_step" not in q or q["retry_temp_step"] == 0.15


def test_clip_toggle_and_threshold_reach_the_policy(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path, quality_enable_clip=True,
                        quality_clip_min_score=0.3)
    q = seen["ops"].quality
    assert q["enable_clip"] is True
    assert q["clip_min_score"] == 0.3


def test_escalate_endpoint_reaches_args_and_enables_hint(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path,
                        escalate_url="http://127.0.0.1:8001",
                        escalate_model="tagger-8b")
    assert seen["args"].escalate_url == "http://127.0.0.1:8001"
    assert seen["args"].escalate_model == "tagger-8b"
    # 质检的 RetryPlan 只有在配置里放开 escalate_model 时才会给出 model_hint
    assert seen["ops"].quality["escalate_model"] is True


def test_file_url_toggle_reaches_args(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path, use_file_url=True)
    assert seen["args"].use_file_url is True


def test_defaults_expose_quality_numbers(tmp_path):
    """页面上的"0 = 用配置的 3.4"里那个数必须来自配置，不能写死在组件里。"""
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    client = TestClient(create_app(ui_dist=tmp_path / "no-ui"))
    q = client.get("/api/defaults").json()["quality"]
    assert q["pass_score"] == pytest.approx(3.4)
    assert q["drop_score"] == pytest.approx(1.8)
    assert q["max_attempts"] == 2
    assert q["clip_model"]
    # 重试阶梯也要在，否则页面只能写死默认值
    assert q["retry_temp_step"] > 0
    assert q["retry_pixels_cap"] > 0


def test_job_request_mirrors_job_spec():
    """JobRequest 漏字段 = 表单发了、任务收不到，而且不会有任何报错。"""
    from dataclasses import fields

    from tagger.web.app import JobRequest

    spec_keys = {f.name for f in fields(JobSpec)}
    missing = spec_keys - set(JobRequest.model_fields)
    assert not missing, f"JobRequest 少了这些字段：{sorted(missing)}"


# ------------------------------------------------------------------ L1 规则层与闭环旋钮

def test_l1_thresholds_reach_the_policy(monkeypatch, tmp_path):
    """L1 四个阈值：0 是合法值，所以用 None 当"没填"的哨兵。"""
    seen = _run_vlm_ops(monkeypatch, tmp_path, quality_min_chars=0,
                        quality_max_chars=900, quality_min_tag_coverage=0.8,
                        quality_max_repeat_ratio=0.0)
    q = seen["ops"].quality
    assert q["min_chars"] == 0            # 0 = 不设下限，必须真的写进去
    assert q["max_chars"] == 900
    assert q["min_tag_coverage"] == 0.8
    assert q["max_repeat_ratio"] == 0.0


def test_l1_none_means_follow_config(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path)
    q = seen["ops"].quality
    # 一个都没写：配置里的默认值原样保留
    assert q.get("min_chars") != 0
    assert "min_chars" not in q or q["min_chars"] == 140


def test_clip_model_and_pretrained_reach_the_policy(monkeypatch, tmp_path):
    seen = _run_vlm_ops(monkeypatch, tmp_path, quality_enable_clip=True,
                        quality_clip_model="ViT-B-32",
                        quality_clip_pretrained="laion2b_s34b_b79k")
    q = seen["ops"].quality
    assert q["clip_model"] == "ViT-B-32"
    assert q["clip_pretrained"] == "laion2b_s34b_b79k"


def test_min_greater_than_max_is_rejected_at_create(tmp_path):
    """最短 > 最长不会报错，只会让每条都被判过长、通过率 0。要在建任务时拦住。"""
    mgr = JobManager()
    with pytest.raises(ValueError, match="不能大于"):
        mgr.create(JobSpec(engine="vlm", out_dir=str(tmp_path / "o"),
                           hf_repo="org/r", guard=False,
                           quality_min_chars=800, quality_max_chars=100))


def test_guard_knobs_include_closed_loop_params():
    """闭环细调上页面：白名单里必须有这几项，否则表单发了后端会默默丢掉。"""
    from tagger.web.jobs import GUARD_KNOBS, normalize_guard_policy

    for k in ("kp", "ki", "temp_deadband_c", "min_duty", "max_sleep_s"):
        assert k in GUARD_KNOBS
    got = normalize_guard_policy({"kp": 0.08, "ki": 0.01, "min_duty": 0.1})
    assert got == {"kp": 0.08, "ki": 0.01, "min_duty": 0.1}
    # 区间外的夹回来，而不是报错
    assert normalize_guard_policy({"kp": 5.0})["kp"] == 1.0
    assert normalize_guard_policy({"min_duty": 0.0})["min_duty"] == 0.02


def test_defaults_expose_l1_and_closed_loop(tmp_path):
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    body = TestClient(create_app(ui_dist=tmp_path / "no-ui")).get("/api/defaults").json()
    q = body["quality"]
    assert q["min_chars"] == 140
    # max_chars 是 token 线的字符兜底（英文约 4.4 字符/token），必须跟着
    # nl_max_tokens 一起改。钉死具体数字会在每次调预算时误报，所以校验的是
    # 两条线是否自洽：字符线不得比 token 线能装下的更紧，否则合格的图会被
    # 判成"caption 过长"白扣分。
    from tagger.config import load_ops, load_tier_table

    nl_max_tokens = load_ops(load_tier_table()).output_spec().nl_max_tokens
    assert q["max_chars"] >= nl_max_tokens * 4.4 * 0.95
    assert q["clip_pretrained"] == "openai"
    g = body["guard"]
    for k in ("kp", "ki", "temp_deadband_c", "min_duty", "max_sleep_s"):
        assert k in g
