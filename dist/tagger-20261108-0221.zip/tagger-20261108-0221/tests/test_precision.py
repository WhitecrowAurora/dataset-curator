"""VLM 权重精度三档（BF16 / FP8 / W4A16）的口径守卫。

三档在 vLLM 上是三条不同的路，最容易犯的错是"把意图当成能力"：
选了 W4A16 但手上只有 bf16 权重，还照样传 --quantization awq，服务
启动时报的是形状/键名不匹配——离真正原因（权重没量化）很远。
"""

from __future__ import annotations

import pytest

from tagger.config import (ConfigError, load_tier_table,
                           normalize_quant_precision, resolve_profile)
from tagger.hardware import GPUInfo
from tagger.model_loader import build_command


def _gpu(cc: tuple[int, int] = (8, 9), vram: float = 16.0) -> GPUInfo:
    return GPUInfo(index=0, name="test", vram_gb=vram, compute_cap=cc)


def _profile(precision: str | None = None):
    return resolve_profile(load_tier_table("configs/tiers.yaml"), _gpu(),
                           precision_override=precision)


def _cmd(profile) -> list[str]:
    return build_command(profile, port=8000)


def test_precision_aliases_normalize():
    assert normalize_quant_precision(None) is None
    assert normalize_quant_precision("") is None
    assert normalize_quant_precision("BF16") == "bf16"
    assert normalize_quant_precision("bfloat16") == "bf16"
    assert normalize_quant_precision("fp8_e4m3") == "fp8"
    assert normalize_quant_precision("int4") == "w4a16"
    assert normalize_quant_precision("awq") == "w4a16"
    with pytest.raises(ConfigError, match="未知精度"):
        normalize_quant_precision("int8")


def test_default_precision_never_passes_quantization_flag():
    p = _profile("bf16")
    assert p.precision == "bf16"
    assert p.quantization is None
    assert "--quantization" not in _cmd(p)


def test_fp8_maps_to_vllm_quantization_flag():
    p = _profile("fp8")
    assert p.precision == "fp8"
    assert p.quantization == "fp8"
    cmd = _cmd(p)
    assert cmd[cmd.index("--quantization") + 1] == "fp8"


def test_w4a16_without_weights_does_not_fake_quantization():
    """没有量化权重就不传，也不假装已是 4bit。"""
    p = _profile("w4a16")
    assert p.precision == "w4a16"
    assert p.quantization is None
    assert "--quantization" not in _cmd(p)
    assert any("quantized_path" in w for w in p.warnings)


def test_w4a16_with_awq_weights_names_the_method():
    table = load_tier_table("configs/tiers.yaml")
    models = dict(table["models"])
    # 覆盖的必须是分档实际引用的那条：默认档位已切到破限版，
    # 改 qwen3vl-4b 不会影响 low-16g 解析出来的权重。
    models["qwen3vl-4b-abliterated"] = {
        **models["qwen3vl-4b-abliterated"],
        "quantized_path": "local/models/Qwen3-VL-4B-Instruct-AWQ",
        "precision": "awq",
    }
    p = resolve_profile({**table, "models": models}, _gpu(),
                        precision_override="w4a16")
    assert p.weights_path.endswith("AWQ")
    assert p.quantization == "awq"
    cmd = _cmd(p)
    assert cmd[cmd.index("--quantization") + 1] == "awq"


def test_bf16_keeps_original_weights_even_when_quantized_exists():
    """有量化权重不等于这次要用它。

    否则页面上选 BF16、实际加载 4bit，等于换了一代数据还看不出来——
    量化完成后点"取消"就会被这个坑咬到。
    """
    table = load_tier_table("configs/tiers.yaml")
    models = dict(table["models"])
    models["qwen3vl-4b-abliterated"] = {
        **models["qwen3vl-4b-abliterated"],
        "quantized_path": "models/nl/qwen3vl-4b-w4a16",
        "precision": "gptq",
    }
    p = resolve_profile({**table, "models": models}, _gpu(),
                        precision_override="bf16")
    assert p.weights_path == models["qwen3vl-4b-abliterated"]["path"]
    assert p.weight_quantized is True  # 有量化权重，只是这次不用

    q = resolve_profile({**table, "models": models}, _gpu(),
                        precision_override="w4a16")
    assert q.weights_path == "models/nl/qwen3vl-4b-w4a16"


def test_fp8_rejected_on_pre_ada():
    """FP8 是硬件能力问题，不做静默降级：当场报错并说清门槛。"""
    with pytest.raises(ConfigError, match="FP8"):
        resolve_profile(load_tier_table("configs/tiers.yaml"), _gpu(cc=(8, 6)),
                        precision_override="fp8")


def test_unknown_precision_fails_before_starting():
    with pytest.raises(ConfigError, match="未知精度"):
        _profile("int8")


def test_precision_override_wins_over_tier_table():
    """tiers.yaml 写的是 int4；界面显式选 bf16 必须盖过它。"""
    p = _profile("bf16")
    assert p.model.key == "qwen3vl-4b-abliterated"
    assert p.precision == "bf16"
    # 指纹里带精度：换档等于换一代数据，事后要能按它分组
    assert p.model_id.endswith("/bf16")
