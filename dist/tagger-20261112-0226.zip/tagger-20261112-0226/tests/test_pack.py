"""pack 是整条流水线唯一碰图片字节的地方，也是唯一会静默破坏数据的地方。

这里守四件事：
  1. 带 alpha 的图必须转成 JPEG，并且铺白底（不是黑底、不是留透明）
  2. 扩展名必须跟着实际字节改（叫 .png 的 JPEG 会喂错解码器）
  3. 封口结果里图片 + json + nl/tag 四个成员同名
  4. 断点续做只认 key，不重复处理
"""

from __future__ import annotations

import io
import json
import tarfile
import zipfile
from pathlib import Path

from PIL import Image

from tagger.pack import (FlatNamer, PackOptions, PackState, Packer,
                         discover_inputs, read_item_bytes, transcode_to_jpeg)
from tagger.pipeline import plan_inputs


# ------------------------------------------------------------------ 转码


def _open_jpeg(data: bytes) -> Image.Image:
    return Image.open(io.BytesIO(data)).convert("RGB")


def test_transcode_rgba_flattens_to_white(make_rgba_png):
    data = transcode_to_jpeg(make_rgba_png(alpha=0), quality=95, subsampling=2)
    im = _open_jpeg(data)
    r, g, b = im.getpixel((4, 4))
    # JPEG 有量化噪声，不要求精确 255。
    assert r > 245 and g > 245 and b > 245, f"透明区应当压平成白底，实际 {(r, g, b)}"


def test_transcode_semi_alpha_composites_over_white(make_rgba_png):
    data = transcode_to_jpeg(make_rgba_png(alpha=128, rgb=(255, 0, 0)),
                             quality=95, subsampling=0)
    r, g, b = _open_jpeg(data).getpixel((4, 4))
    # 红 128/255 叠白底 ≈ (255, 127, 127)
    assert r > 240
    assert 100 < g < 155 and 100 < b < 155, f"半透明红叠白底结果不对: {(r, g, b)}"


def test_transcode_palette_transparency_flattens(make_palette_png):
    data = transcode_to_jpeg(make_palette_png(), quality=95, subsampling=2)
    r, g, b = _open_jpeg(data).getpixel((4, 4))
    assert r > 245 and g > 245 and b > 245


def test_transcode_returns_real_jpeg(make_png):
    data = transcode_to_jpeg(make_png(), quality=95, subsampling=2)
    assert data[:3] == b"\xff\xd8\xff"


def test_transcode_keeps_requested_quality_effect(make_png):
    """q95 的字节数应当明显大于 q90——参数没被静默吞掉。"""
    lo = transcode_to_jpeg(make_png(color=(200, 30, 60)), quality=90)
    hi = transcode_to_jpeg(make_png(color=(200, 30, 60)), quality=100)
    assert len(hi) >= len(lo)


# ------------------------------------------------------------------ 打包


def _drain(tar_path):
    names = []
    with tarfile.open(tar_path, "r") as tf:
        for m in tf:
            names.append(m.name)
    return names


def test_packer_converts_alpha_png_and_renames(tmp_path, make_rgba_png):
    """下游不支持 alpha：带 alpha 的 PNG 必须变成 .jpg，且不能再出现 .png。"""
    opts = PackOptions(max_records=1, formats=("webdataset",))
    packer = Packer(tmp_path, opts, verbose=False)
    sealed = packer.add(
        flat_name="artist-000001.png",
        image_bytes=make_rgba_png(alpha=0),
        meta={"width": 8, "height": 8},
        nl="a red square",
        tag_text="red, square",
    )
    assert sealed is not None

    names = _drain(tmp_path / sealed.name)
    assert "artist-000001.jpg" in names
    assert "artist-000001.png" not in names
    assert "artist-000001.json" in names
    assert "artist-000001.nl" in names
    assert "artist-000001.tag" in names

    with tarfile.open(tmp_path / sealed.name, "r") as tf:
        data = tf.extractfile("artist-000001.jpg").read()
    assert data[:3] == b"\xff\xd8\xff"


def test_packer_non_jpeg_mode_keeps_existing_jpeg(tmp_path, make_png):
    """non_jpeg 只转非 JPEG；已经是 JPEG 的必须原字节搬走（不能再压一次）。"""
    jpeg_bytes = transcode_to_jpeg(make_png(), quality=95)
    opts = PackOptions(max_records=1, formats=("zip",), reencode_mode="non_jpeg")
    packer = Packer(tmp_path, opts, verbose=False)
    packer.add(flat_name="a.jpg", image_bytes=jpeg_bytes,
               meta={"width": 8, "height": 8})
    packer.close()

    pack = next(tmp_path.glob("*.zip"))
    with zipfile.ZipFile(pack) as zf:
        assert zf.read("a.jpg") == jpeg_bytes
        assert zf.read("a.json")  # meta 必须写进去


def test_packer_non_jpeg_mode_converts_png(tmp_path, make_png):
    opts = PackOptions(max_records=1, formats=("zip",), reencode_mode="non_jpeg")
    packer = Packer(tmp_path, opts, verbose=False)
    packer.add(flat_name="a.png", image_bytes=make_png(),
               meta={"width": 8, "height": 8})
    packer.close()

    with zipfile.ZipFile(next(tmp_path.glob("*.zip"))) as zf:
        names = zf.namelist()
        assert "a.jpg" in names
        assert "a.png" not in names


def test_packer_zip_index_records_entries(tmp_path, make_png):
    opts = PackOptions(max_records=2, formats=("zip",))
    packer = Packer(tmp_path, opts, verbose=False)
    for i in (1, 2):
        packer.add(flat_name=f"a-{i:06d}.png", image_bytes=make_png(),
                   meta={"width": 8, "height": 8},
                   nl="caption", tag_text="red")
    sealed = packer.close()[0]

    with zipfile.ZipFile(tmp_path / sealed.name) as zf:
        index = json.loads(zf.read("index.json"))
    assert index["count"] == 2
    assert len(index["entries"]) == 2
    entry = index["entries"][0]
    assert entry["name"].endswith(".jpg")
    assert entry["has_nl"] is True and entry["has_tag"] is True
    assert entry["wh"] == [8, 8]


def test_packer_meta_gets_name_and_key(tmp_path, make_png):
    opts = PackOptions(max_records=1, formats=("zip",))
    packer = Packer(tmp_path, opts, verbose=False)
    packer.add(flat_name="b-000007.png", image_bytes=make_png(),
               meta={"width": 8, "height": 8})
    sealed = packer.close()[0]
    with zipfile.ZipFile(tmp_path / sealed.name) as zf:
        meta = json.loads(zf.read("b-000007.json"))
    assert meta["name"] == "b-000007.jpg"
    assert meta["key"] == "b-000007"


def test_packer_seals_by_record_count(tmp_path, make_png):
    opts = PackOptions(max_records=2, formats=("zip",))
    packer = Packer(tmp_path, opts, verbose=False)
    first = packer.add(flat_name="a-1.png", image_bytes=make_png(), meta={})
    assert first is None
    second = packer.add(flat_name="a-2.png", image_bytes=make_png(), meta={})
    assert second is not None and second.count == 2
    # 续写要落到下一个序号，不能覆盖刚封口的那包
    third = packer.add(flat_name="a-3.png", image_bytes=make_png(), meta={})
    assert third is None
    packer.close()
    names = sorted(p.name for p in tmp_path.glob("*.zip"))
    assert len(names) == 2
    assert names[0].endswith("00000.zip") and names[1].endswith("00001.zip")


# ------------------------------------------------------------------ 发现


def test_discover_inputs_loose_and_zip(tmp_path, make_png, make_zip):
    (tmp_path / "artist_a").mkdir()
    (tmp_path / "artist_a" / "001.png").write_bytes(make_png())
    make_zip(tmp_path / "shard-0001.zip", {
        "artist_b/002.png": make_png(),
        "artist_b/003.jpg": transcode_to_jpeg(make_png(), 95),
        # 这两个必须被跳过：一个是别的工具的索引，一个是隐藏文件
        "manifest.jsonl": b"{}",
        "_meta/meta.jsonl": b"{}",
    })

    items = discover_inputs(tmp_path)
    names = sorted(i.flat_name for i in items)
    assert names == ["001.png", "002.png", "003.jpg"]
    kinds = {i.flat_name: i.kind for i in items}
    assert kinds["002.png"] == "zip_member"
    assert kinds["001.png"] == "loose_file"


def _make_tar(path: Path, members: dict[str, bytes]) -> Path:
    """把 {成员名: bytes} 打成 tar —— HF 上下的数据集就是这个形状。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(path, "w") as tf:
        for name, data in members.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    return path


def test_discover_inputs_reads_tar_members(tmp_path, make_png):
    """webdataset 分片是 .tar：只认 zip 的话它们会整包消失（扫到 0 张）。"""
    png = make_png()
    _make_tar(tmp_path / "shard-0001.tar", {
        "000001.png": png,
        # webdataset 的样本描述与我们的索引都不是图片，必须跳过
        "000001.json": b'{"caption": "x"}',
        "meta.jsonl": b"{}",
    })

    items = discover_inputs(tmp_path, include_loose=False)
    assert [i.member for i in items] == ["000001.png"]
    assert items[0].kind == "tar_member"
    assert items[0].is_member
    assert items[0].logical_path == "000001.png"
    assert items[0].size == len(png)
    # 取图走的是句柄缓存那条路，字节要和写进 tar 的一模一样
    assert read_item_bytes(items[0]) == png


def test_discover_inputs_accepts_single_tar_path(tmp_path, make_png):
    """直接指一个 .tar 文件也要能用（单包素材的常见形态）。"""
    tar = _make_tar(tmp_path / "pack.tar", {"a/001.png": make_png()})
    items = discover_inputs(tar, include_loose=False)
    assert len(items) == 1
    assert items[0].rel_path == "pack.tar::a/001.png"


def test_plan_inputs_tar_member_id_strips_container_suffix(tmp_path, make_png):
    """只打标（不封包）时 id 用「包名/成员名」，包名要去掉 .tar。"""
    _make_tar(tmp_path / "shard-0009.tar", {"000001.png": make_png()})
    plan = plan_inputs(tmp_path, include_loose=False, assign_ids=False)
    assert len(plan.items) == 1
    assert plan.items[0].image_id == "shard-0009/000001"


def test_discover_inputs_limit(tmp_path, make_png):
    for i in range(5):
        (tmp_path / f"{i}.png").write_bytes(make_png())
    items = discover_inputs(tmp_path, limit=2)
    assert len(items) == 2


def test_flat_namer_resolves_collision():
    namer = FlatNamer()
    a = namer.make("dir1/001.png")
    b = namer.make("dir2/001.png")
    assert a == "001.png"
    assert b != a and b.startswith("001_")


def test_packstate_resumes(tmp_path):
    state = PackState(tmp_path / ".packstate.jsonl")
    assert not state.done("k1")
    state.mark("k1", note="done")
    again = PackState(tmp_path / ".packstate.jsonl")
    assert again.done("k1")
    assert again.count == 1
    # 重复 mark 不该写第二行
    again.mark("k1")
    assert (tmp_path / ".packstate.jsonl").read_text(encoding="utf-8").count("\n") == 1


def test_packstate_survives_truncated_line(tmp_path):
    """断电时最后一行可能只写了一半，不能因此让整个状态文件作废。"""
    p = tmp_path / ".packstate.jsonl"
    p.write_text('{"key": "k1", "ts": 1}\n{"key": "k2"', encoding="utf-8")
    state = PackState(p)
    assert state.done("k1")
    assert state.count == 1


# ------------------------------------------------------------------ 并行


def _samples(make_png, n: int) -> list[dict]:
    return [
        {
            "flat_name": f"a-{i:06d}.png",
            "image_bytes": make_png(color=(i * 7 % 256, i * 11 % 256, 60)),
            "meta": {"width": 8, "height": 8, "image_id": f"a-{i:06d}"},
            "nl": f"caption {i}",
            "tag_text": "red, square",
        }
        for i in range(1, n + 1)
    ]


def test_pack_stream_matches_sequential(tmp_path, make_png):
    """并行只是换执行方式，产物必须逐字节一致。

    一旦并行版写出来的包和串行版不同，就说明"准备"和"写"之间还藏着共享状态，
    那是最难查的一类错——两边都不报错，只是内容悄悄不一样。
    """
    from tagger.pack import pack_stream

    samples = _samples(make_png, 6)
    dirs = {}
    for tag, workers in (("seq", 1), ("par", 4)):
        out = tmp_path / tag
        packer = Packer(out, PackOptions(max_records=4, formats=("zip",)),
                        verbose=False)
        list(pack_stream(packer, samples, workers=workers))
        packer.close()
        dirs[tag] = out

    names = sorted(p.name for p in dirs["seq"].glob("*.zip"))
    assert names == sorted(p.name for p in dirs["par"].glob("*.zip"))
    assert len(names) == 2

    for name in names:
        with zipfile.ZipFile(dirs["seq"] / name) as za, \
                zipfile.ZipFile(dirs["par"] / name) as zb:
            assert sorted(za.namelist()) == sorted(zb.namelist())
            for member in za.namelist():
                if member == "index.json":
                    # index.json 里记着封口时刻，两次跑必然不同；比内容不比时间。
                    ia = json.loads(za.read(member))
                    ib = json.loads(zb.read(member))
                    ia.pop("ts", None)
                    ib.pop("ts", None)
                    assert ia == ib
                    continue
                assert za.read(member) == zb.read(member), member


def test_pack_stream_preserves_input_order(tmp_path, make_png):
    """包内顺序必须与输入一致：顺序号是写进包名的，乱了就没法复现对账。"""
    from tagger.pack import pack_stream

    samples = _samples(make_png, 5)
    packer = Packer(tmp_path, PackOptions(max_records=10, formats=("zip",)),
                    verbose=False)
    list(pack_stream(packer, samples, workers=4))
    packer.close()

    with zipfile.ZipFile(next(tmp_path.glob("*.zip"))) as zf:
        index = json.loads(zf.read("index.json"))
    assert [e["key"] for e in index["entries"]] == [f"a-{i:06d}" for i in range(1, 6)]


def test_pack_stream_single_worker_uses_add(tmp_path, make_png):
    """workers<=1 走原始路径：没有线程池开销，行为与 add 完全一致。"""
    from tagger.pack import pack_stream

    packer = Packer(tmp_path, PackOptions(max_records=10, formats=("zip",)),
                    verbose=False)
    list(pack_stream(packer, _samples(make_png, 2), workers=1))
    packer.close()
    with zipfile.ZipFile(next(tmp_path.glob("*.zip"))) as zf:
        assert "a-000001.jpg" in zf.namelist()
