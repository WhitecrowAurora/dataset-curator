# 数据集构建进度留档

> 执行机：`anlia@121.225.25.33`（Xeon Platinum 8470QL，104 逻辑核 / 255 GB）
> 工具机：本地 `S:\tools`（脚本） + 远端 `C:\Users\anlia\AppData\Local\Temp`（执行体）

这份文档记录两批数据集的构建过程、产物位置、踩过的坑和待办。目的是让后来者（或上下文丢失后的自己）不用从盘上重新猜。

---

## 0. 速读

| | 第一批（素材配对打包） | 第二批（danbooru 768） |
|---|---|---|
| 状态 | **已完成** | **进行中**（失联前 51/1000） |
| 输入 | `I:\anlia2\2025.05TG` + `I:\anlia2\6月更新`（931 个 rar/zip） | HF `deepghs/danbooru2024-webp-4Mpixel` 前 1000 个源分片 |
| 768 产物 | `K:\anlia\anlia2_wds`（30 片 tar，52.18 GB，344,440 张） | `K:\anlia\danbooru2024_768`（滚动写入） |
| 2MP 产物 | `K:\anlia\anlia2_flat_2mp`（344,440 文件，165.7 GB） | 无 |
| 脚本 | `%TEMP%\build_wds.py` + `run_wds.cmd` | `%TEMP%\danbooru_build.py` + `run_danbooru_loop.cmd` |
| 日志 | `K:\anlia\build_wds.log` / `.err.log` | `K:\anlia\danbooru_build.log` / `.err.log` |

**第二批有两份产物，用途不同（重要）**
- `K:\anlia\danbooru2024_768`（0.54 MP）= **分发打包**给其他人用
- `K:\anlia\danbooru2024_2mp`（2 MP）= **自己训练用**（训练机带不动 4 MP 源）
- `I:\anlia2\danbooru\images\*.tar`（4 MP webp）= 原始下载原料，不要当训练数据用

---

## 1. 第一批：素材配对打包（已完成）

**产物**（两版同步生成，不是跑两遍）

| 目录 | 内容 | 数量 | 体积 | 平均 |
|---|---|---|---|---|
| `K:\anlia\anlia2_wds` | `shard-XXXXXX.tar`（1750 MB 封口）+ `manifest.jsonl` | 30 片 | 52,181.5 MB（文件）／51,722.6 MB（768 payload） | 153.8 KB/张 |
| `K:\anlia\anlia2_flat_2mp` | 按画师分目录（mirror 布局） | 344,440 文件 | 165,718.4 MB | 492.7 KB/张 |

- **最终张数 344,440**，`manifest.jsonl` 行数与 `flat_2mp` 文件数**完全一致**
- `manifest.jsonl` 每行同时带 `bytes_768` 与 `bytes_2mp`，证明同一张图解码一次、同时产出两版
- 各分片 mtime 逐片递增，说明是**滚动封口**（满 1750 MB 就关一个换下一个）；最后一片 `shard-000029.tar` 只有 980.2 MB，收尾不满也封口
- 日志收尾：`768 total = 51722.6 MB` / `2mp total = 165718.4 MB`
- 素材侧噪声：个别 rar 内图片损坏（`broken PNG`）、`skip(no images)`、`DecompressionBombWarning`，均为单包跳过，不影响整体

**用户口径差异**：用户记的是「367,445 张」，实际跑出 344,440 张，差 23,005 —— 大概率是坏包/空包被跳过。**如果要凑满 367,445，需要回头查那 931 个包里被 skip 的清单。**

---

## 2. 第二批：danbooru 768 分包（进行中）

**目标**：把 danbooru 素材统一成「面积预算 768²」的 JPEG，封成 1750 MB 的 tar 分片 + 逐图 `manifest.jsonl`。

**规则（`danbooru_build.py` 内实现）**
- `target_size()`：`面积 <= MAX_PIXELS` → 原样保留（`asis`，**不放大**）；长宽比接近某个预设桶 → 用桶尺寸（`bucket`）；否则按面积缩放并向下对齐 32（`freeratio`）
- 输出宽高尽量为 32 的倍数（SD VAE 要求），但 **`asis` 那批不保证**
- JPEG：`quality=QUALITY, subsampling=0（4:4:4）, optimize=True, progressive=True`
- 每片 1750 MB 封口，封口后有约 7.28 MB 的 tar 头/填充开销，正常

**断点续跑机制**
- 状态：`I:\anlia2\danbooru\_state.json`（`sealed` / `done` / `done_mark` / `manifest_bytes`）
- 启动时丢弃编号 ≥ `sealed` 的未封口分片，并把 `manifest.jsonl` 截断回 `manifest_bytes`
- 源分片缓存：`I:\anlia2\danbooru\images\*.tar`（处理完**不删**），下载中落在 `_cache\*.part`

**失联前进度**

```
46 片 / 77.22 GB
累计 225,142 张
src = 51~52 / 1000，bad = 0
144 img/s，manifest 约 417,564 行
```

**速率实测**
- 独占机器时：出图 144~330 img/s（取决于缓存里有没有备货）
- 有备货时能冲到 272~330 img/s；纯等下载时被压到下载决定的速度（18 MB/s ÷ 0.21 MB/图 ≈ 86 img/s）
- 下载：`WDS_DL=3` → 9~15 MB/s；`=6` → 18 MB/s；`=10` → 36 MB/s 但分片失败率升到约 8%
- `WDS_ENC=48` 已能让 104 核跑到 97%，**不要再加编码并发**
- 修正后预估：剩余约 12~16 小时

---

## 3. 运维速查

所有外部命令都走执行器 `S:\tools\rc.ps1`（SSH 到执行机执行）。

**执行机地址只有一个地方要改：`S:\tools\rc.host`（一行 `user@host`）。**
写 IP 就直连；写域名会先查 A 记录拿到 IP 再直连（连接本身不走域名，无速度损失），解析到 IP 时会多打印一行 `TARGET ...`。已加 `StrictHostKeyChecking=accept-new`，换 IP 后首次连接不会卡在指纹确认。
（后续可选：在 Cloudflare 侧挂 DDNS，服务器每 5 分钟把 A 记录更新成当前公网 IP，TTL 设 60 秒；本地这边不用改任何东西。）

用法：

```
powershell -ExecutionPolicy Bypass -File S:/tools/rc.ps1 -Run <远端临时目录里的脚本名> -Timeout <秒> -Tag <标签>
powershell -ExecutionPolicy Bypass -File S:/tools/rc.ps1 -Path <本地脚本路径> -Timeout <秒> -Tag <标签>
```

- `-Run`：执行**执行机** `C:\Users\anlia\AppData\Local\Temp\<名字>`，脚本须先上传
- `-Path`：把本地脚本内容 base64 塞进命令行执行，**不用上传，但有约 8 KB 命令行长度的硬上限**，超了会报「命令行太长」
- 上传：`powershell -ExecutionPolicy Bypass -File S:\tools\upload.ps1 -Files <单个路径>`（一次只传一个，逗号列表参数会被当成一个路径）

**可用脚本清单**

| 脚本 | 作用 |
|---|---|
| `status_danbooru.ps1` | 进程数 / state / 缓存与产出体积 / 日志尾 |
| `rate_danbooru.ps1` | 采样 180 秒算真实下载 MB/s 与出图 img/s（日志里的 `dl=` 不可信） |
| `count_fail.ps1` | `[FAIL]` 计数与缺失源分片编号 |
| `audit_danbooru.ps1` | 首片与 manifest 字节级对账、抽样解码、源 tar 可读性、剩余空间 |
| `verify_768.py` | 全量终检（manifest 行数 vs tar 成员数、id 唯一、32 对齐、体积分布），末行 `VERDICT OK/FAIL` |
| `relaunch_loop.ps1` / `start_dbr.ps1` | 杀进程树 + 写循环启动器 + 后台拉起（`start_dbr.ps1` 会注入 `HF_TOKEN`） |
| `diag_danbooru.ps1` | 进程树 / 文件时间，判断是否卡死 |
| `check_wds.ps1` | 第一批产物与日志状态 |
| `write_readme.ps1` | 往各数据目录写 README（中文内容与路径都走 base64） |

---

## 4. 踩过的坑（按重要性）

### 4.1 ★ 数据集是 gated，必须注入 HF_TOKEN
`deepghs/danbooru2024-webp-4Mpixel` 是 **`gated:"auto"`**：**匿名请求一律 403**（`Access to dataset ... is restricted and you are not in the authorized list`），带 token 才 302 放行。token 在 `C:\Users\anlia\.cache\huggingface\token`（`ruilynx`，read 权限，有效）。

程序里虽有 `load_token()`（先读 `HF_TOKEN` 环境变量，再读 `~/.cache/huggingface/token`），但曾出现跑着跑着下载全部变 0 字节的情况。**修法：在启动器里显式 `set HF_TOKEN=<token>`**，别只依赖 `Path.home()`。

**故障症状（静默空转，最坑）**：`_cache/*.part` 全是 0 字节、日志**不打印 `[FAIL]`**、`imgs` 冻结、CPU 掉到 2~3%、`_state.json` 的 mtime 不再更新。缓存耗尽后就是纯空转，6 轮循环会白跑。

**诊断三板斧（30 秒定性）**
1. 带 token 手测：`curl -sSL --fail -C - -m 40 -o t.part -w "%{http_code}|%{size_download}" -H "Authorization: Bearer $tok" <resolve URL>` —— 正常应 40 秒约 838 MB / 22 MB/s；不带 token 对照必是 403
2. 看 `_cache/*.part` 的**精确字节数**（`Round /1MB` 会把几十 KB 显示成 0，要打印 `Length`）
3. 看 `_state.json` 的 mtime 是否在动

### 4.2 ★ 怎么判断"卡死"（连续误判过三次，务必按这个来）
`download()` 先写 `_cache/XXXX.tar.part`，用 `-C -` 续传，0 字节就等于从 0 开始；下完 `part.replace(final)` 改名进 `images/`。

**先记住三件事，否则一定会误判：**
1. **缓存耗尽时 `images/` 和 `manifest.jsonl` 会长时间冻住**。这一步要等整个源分片（~1.7 GB）下完才会继续出图，冻结十几分钟完全正常。**不能拿 `imgs` 不动当卡死证据。**
2. **`Get-ChildItem` 返回的 `Length` 有元数据缓存**，刚创建的文件可能长时间显示 0 或旧值。要看真实大小必须用 `[System.IO.FileInfo]::new($p).Length`／`[System.IO.Directory]::GetFiles()`，或者干脆用 `Measure-Object` 重新枚举。
3. **`curl` 进程存在 ≠ 在下载**。换 IP / 断网后连接会变成半开，`-m 3600` 会让它一直挂着不返回也不报错（实测挂 6~20 分钟）。

**唯一可靠判据**：用 .NET API 对 `_cache\*.part` 求和，隔 25 秒再求一次，看增量。
- 有增量（实测正常在 12~218 MB/s 之间）→ 健康，等着就行
- 增量为 0 且 `images/`、`manifest` 也都不动 → 才是真卡

**不要随便杀 `curl`**：杀掉会让对应的 worker 收到非 0 返回、直接 `[FAIL]` 掉那个分片（虽然下一轮会补，且 part 可续传省流量，但会白白浪费一次）。只有在确认连接半开挂死时才杀，且要预期到会新增若干 `[FAIL]`。

### 4.3 ★ `[FAIL]` 不重试，必须用循环包装
主脚本遇到 `[FAIL]`（下载截断 `curl 18`、连接重置 `curl 56`）只跳过、不重试，`done` 只记成功分片。单跑一轮会永久缺几个百分点。
**修法**：用 `run_danbooru_loop.cmd` 做 6 轮 `for /l`，每轮 `todo` 只含不在 `done` 里的分片，失败的自然被下一轮补上（`0013.tar` 就是这样补成功的）。

### 4.4 ★ `anlia2_flat_2mp` 是 mirror 布局
一个画师一个文件夹，`Get-ChildItem -File`（非递归）在顶层返回 **0 个文件**，会误判成「2MP 没跑出来」。必须 `-Recurse` 或 `os.walk`。（这个坑当场误导过一次。）

### 4.5 执行机是 PowerShell 5.1，脚本必须纯 ASCII
无 BOM 的 UTF-8 中文注释会被按 ANSI 解析成乱码，直接语法错误。含中文的脚本要：内容与中文路径都 base64 化，`[IO.File]::WriteAllText` 用 `UTF8Encoding($true)`（带 BOM）写盘，否则记事本打开是乱码。

### 4.6 统计口径
- 日志里的 `dl=xx MB/s` 是单值覆盖的旧值，**不可信**，要用两次采样算
- `shard-*.tar` 的 `%MB` 取整会把刚创建的文件显示成 0
- 源的 `src=N/1000` 天然滞后于输出片数（一个源分片约产出 1.5 个输出片）

---

## 4.7 第三路任务：danbooru 2MP 训练包

**为什么有这一路**：768 版是分发用的，**2MP 才是自己训练的**；训练机带不动 4MP 源，所以要把源图压到 2MP。原始 4MP 只当原料，不直接进训练。

**实现**：`%TEMP%\process_2mp.py` + `%TEMP%\run_2mp_loop.cmd`，日志 `K:\anlia\build_2mp.log`

- 输入：**复用** `I:\anlia2\danbooru\images\*.tar`（不重新下载，省 1.6 TB 流量）
- 输出：`K:\anlia\danbooru2024_2mp\shard-XXXXXX.tar`（1750 MB 封口，成员 `<id>.webp`）+ `manifest.jsonl`
- **★ 核心优化**：`面积 <= 2MP` 的图**原样复制字节**（不解码不重编码，零损失且快），只有超 2 MP 的才 LANCZOS 缩到 2MP 预算并 32 对齐重编码 webp
- 实测比例：copy 61% / scaled 39%（源平均 1.93 MP，但分布很宽，4.2 MP 是上限）
- 产物校验：`out_MP` 平均 1.32、**最大 2.00，无一超标**；平均 168 KB/张
- 体积预估：约 780 万张 × 168 KB ≈ **1.3 TB**（放 K 盘；K 剩 2340 GB，768 后续还要约 430 GB，合计后余量约 600 GB —— **偏紧，要盯着**）
- 速率实测：40 进程约 167 img/s（与 768 任务并行时）
- 断点：`K:\anlia\danbooru2024_2mp\_state.json`（done / sealed / manifest_bytes）
- 与 768 并行：2MP 吃 CPU、768 吃带宽，理论上互补；但两者都读 I 盘源 tar，会有 I/O 竞争

**注意**：`run_2mp_loop.cmd` 是 10 轮、每轮间隔 5 分钟的循环。因为源分片是边下边处理的，第 1 轮只覆盖当时已下好的部分，后续轮次自动补新出现的分片。

---

## 5. 待办 / 未决

1. **执行机失联**：SSH（`121.225.25.33:22`）超时，本地网络正常，已确认为对方家宽 IP 变化（数据组反馈）。任务本身在远端独立运行，断网不影响它跑；但**若机器重启过，`run_danbooru_loop.cmd` 不会自启**，需要重新拉起（状态与已封分片都在，续跑安全）。
   **恢复步骤**：拿到新 IP → 改 `S:\tools\rc.host` 一行 → 跑 `status_danbooru.ps1` 看日志是否还在推进 → 若已停则用 `start_dbr.ps1` 拉起。
   **后续可选**：用户有 Cloudflare 托管的域名，可在执行机挂 DDNS（每 5 分钟更新 A 记录、TTL 60 秒），地址就固定成一个域名，不用再等报 IP。
2. **`asis` 的 32 对齐**：约 17% 的图（`fit=asis`，原图不缩放且面积够小）不是 32 的倍数，`freeratio`/`bucket` 全对齐。若下游 VAE/bucket 要求严格 32 倍数，需要跑完后统一后处理。
3. **344,440 vs 367,445**：第一批实际比用户记忆少 23,005 张，需查 skip 清单确认是否要补。
4. **`WDS_DL` 甜点**：6 还是 10 未定论（10 更快但失败率高，失败可靠循环补），等本轮跑完看实际总时长再定。
5. 跑完后要跑 `verify_768.py` 做终检，并确认日志出现 `[all rounds finished]`、`src` 到 1000。

---

## 6. 过程纪要（按发生顺序）

**第一批**
1. 启动 `build_wds.py`：931 个包，8 解压 worker / 60 编码进程，读 rar/zip → 同时产 768 与 2MP
2. 首片封口后持续滚动，每满 1750 MB 关一片换下一片
3. 与第二批并行时被抢 CPU，速率从 150 img/s 掉到 54 img/s
4. 正常收尾：30 片、344,440 张，两版数量一致

**第二批**
1. 先做端到端冒烟（下载 → 解码 → 缩放 → 编码 → 封片 → 写 manifest），校验 656 张产物与 tar 成员一一对应、id 无重复，通过
2. 清空冒烟产物、保留源缓存，正式启动
3. 第一次重启：`WDS_DL` 3 → 10 提速
4. 第二次重启：改用 6 轮循环包装，自动补失败分片
5. **出现静默故障**：下载全部变 0 字节、无 `[FAIL]`、CPU 2.3%、`imgs` 冻结
6. 缓存耗尽后暂停止损，保住 `done=23 / sealed=21 / 22 片 / 36.27 GB`
7. 对照实验定性：带 token 40 秒下 838 MB / 22 MB/s，匿名 403 → 是 token 没带上
8. 注入 `HF_TOKEN`、`WDS_DL=6` 重启，恢复正常，速率 272~330 img/s
9. 768 任务跑到 75% 时速率从 126 掉到 71.9 img/s，查明是**缓存耗尽、下载成瓶颈**（12.8 MB/s ≈ 100 Mbps 家宽跑满，CPU 仅 1%），属正常
10. 往 7 个数据目录写入 `README.md`
11. 执行机家宽换 IP（`.33` → `.11`），期间任务一直在跑，未中断
12. **追加 2MP 训练包任务**：与 768 任务并行，用已下载的源缓存转换，不重新下载

---

## 7. 2026-11-07 收官（两路都已跑完）

| 任务 | 结束时刻 | 产物 | manifest |
|---|---|---|---|
| 768（分发版） | `[all rounds finished] 11-07 06:43:05` | 843 个 tar / 1443.55 GB | 8,025,819 行 |
| 2MP（训练版） | `[2mp all rounds finished] 11-07 18:30:04` | 754 个 tar / 1294.37 GB | 8,005,010 行 |

- 768 的源分片 `1000 已完成 / 待处理 0`；两路都 `python=0 / tar=0`，没有残留进程
- 2MP 落地在 `K:\anlia\danbooru2024_2mp`，`F:` 那份已不存在（`move_2mp_to_k.ps1` 搬过）
- **抽样终检**（`S:\tools\final_verify.ps1`：首/中/尾各一片各解 3 张 + manifest 抽样）
  - 768：JPEG 可解码，平均 138.5 KB / 最大 199.2 KB，`fit` 三种都有（freeratio / bucket / asis）
  - 2MP：WEBP 可解码，平均 99.1 KB，**无一超标**（抽样最大 1.97 MP）
  - 未做全量 `verify_768.py`：它对 843 个 tar 逐个 `getnames()`，等于把 1443 GB 流式过一遍，几十分钟起步
- **★ 两批都不是全量 32 对齐**：768 的 `asis`（约 17%）、2MP 的 `copy` 分支（约 61%，面积≤2MP 原样复制字节）天然不对齐。下游若要严格 32 倍数，需统一后处理
- 收官时磁盘：K 剩 701.6 GB、I 剩 610.4 GB（`I:\anlia2\danbooru\images` 源缓存 1596 GB 仍在，可回收）
- 仍开着的待办：第一批 344,440 vs 367,445 的 23,005 张差（见 5.3）、`asis` 后处理决策
