"""嵌套包两阶段分包的端到端测试。

这条链路和普通分包的区别在于**先扫描造表、再并行写包**：id 分配发生在
扫描阶段，写包时只按 seq 取。所以测试重点不在参数校验，而在：

- 嵌套包里的图能不能真的变成分发包里的成员；
- image_id 会不会被容器名污染（第一版就是 `inner.zipalice-000001`）；
- manifest 里的 src/member 能不能还原"这张图来自哪个包"；
- 多线程与单线程的 id 顺序是否完全一致；
- 换 per_shard 重切时扫描表能不能复用、源文件变了旧表会不会被拦下；
- 中途取消时，已经写好的包要完整，不能留半截。
"""

import zipfile
from pathlib import Path

import pytest

from tagger.web.packaging import SplitParams, run_split


def _make_zip(path: Path, files: dict[str, bytes]) -> Path:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data)
    return path


def _split(tmp_path: Path, source: Path, **kw) -> dict:
    params = SplitParams(
        input_dir=str(source),
        out_dir=str(tmp_path / "dist"),
        table=str(tmp_path / "shards.json"),
        work_dir=str(tmp_path / "work"),
        nested=True,
        **kw,
    )
    return run_split(params, on_progress=lambda *a: None,
                     should_stop=lambda: False, on_log=lambda s: None)


def _members(shard: Path) -> list[str]:
    with zipfile.ZipFile(shard) as zf:
        return zf.namelist()


def _manifest(shard: Path) -> list[dict]:
    import json
    with zipfile.ZipFile(shard) as zf:
        raw = zf.read("manifest.jsonl").decode("utf-8")
    return [json.loads(x) for x in raw.splitlines() if x.strip()]


def test_nested_zip_becomes_members(tmp_path):
    """zip 套 zip：内层的图要原样出现在分发包里。"""
    inner = _make_zip(tmp_path / "inner.zip", {"alice/1.jpg": b"x" * 100})
    outer = _make_zip(tmp_path / "outer.zip",
                      {"inner.zip": inner.read_bytes(), "bob/2.png": b"y" * 200})

    res = _split(tmp_path, outer, per_shard=10)
    assert res["total"] == 2
    assert res["package_count"] == 1

    shard = tmp_path / "dist" / "dist-0000.zip"
    assert sorted(_members(shard)) == sorted(["alice-000001.jpg", "bob-000002.png",
                                              "manifest.jsonl"])


def test_image_id_not_polluted_by_container_name(tmp_path):
    """画师要从包内路径提，不能把 `inner.zip::` 算进去。"""
    inner = _make_zip(tmp_path / "inner.zip", {"alice/1.jpg": b"x" * 10})
    outer = _make_zip(tmp_path / "outer.zip", {"inner.zip": inner.read_bytes()})

    _split(tmp_path, outer, per_shard=10)
    rows = _manifest(tmp_path / "dist" / "dist-0000.zip")
    assert rows[0]["image_id"] == "alice-000001"
    # 来源要能追回原始包：src 记顶层文件，member/rel_path 记包内路径
    # （member 会被下游当成镜像路径用，不能塞进 `::` 内层链）
    assert rows[0]["src"] == str(outer)
    assert rows[0]["member"] == "alice/1.jpg"
    assert rows[0]["rel_path"] == "alice/1.jpg"


def test_shards_seal_by_count(tmp_path):
    """写满就封口：3 张、每包 2 张 → 2 个包，列表是 2 + 1。"""
    src = _make_zip(tmp_path / "a.zip", {f"p/{i}.jpg": b"z" * 10 for i in range(3)})
    res = _split(tmp_path, src, per_shard=2)

    assert res["package_count"] == 2
    counts = [p["count"] for p in res["packages"]]
    assert counts == [2, 1]
    # 每个包都必须有 manifest，且行数等于张数
    for plan in res["packages"]:
        rows = _manifest(tmp_path / "dist" / plan["name"])
        assert len(rows) == plan["count"]


def test_ids_are_sequential_and_stable(tmp_path):
    """同样的输入跑两次，id 必须完全相同——下游回传标注靠它对上。"""
    src = _make_zip(tmp_path / "a.zip", {f"k/{i}.jpg": b"q" * 5 for i in range(4)})

    first = _split(tmp_path, src, per_shard=10)
    ids1 = [r["image_id"] for r in _manifest(tmp_path / "dist" / "dist-0000.zip")]

    # 第二次必须换一个表名（validate 拦重复表），但 id 分配规则不变
    params = SplitParams(input_dir=str(src), out_dir=str(tmp_path / "dist2"),
                         table=str(tmp_path / "t2.json"),
                         work_dir=str(tmp_path / "work"), nested=True, per_shard=10)
    run_split(params, on_progress=lambda *a: None,
              should_stop=lambda: False, on_log=lambda s: None)
    ids2 = [r["image_id"] for r in _manifest(tmp_path / "dist2" / "dist-0000.zip")]

    assert ids1 == ids2
    assert first["total"] == 4


def test_resize_happens_while_packing(tmp_path):
    """入包时顺手缩放：包里的图要真的变小，且比例不变。"""
    import io

    from PIL import Image

    def png(w: int, h: int) -> bytes:
        buf = io.BytesIO()
        Image.new("RGB", (w, h), (90, 120, 150)).save(buf, "PNG")
        return buf.getvalue()

    src = _make_zip(tmp_path / "a.zip", {
        "big/1.png": png(1600, 900),
        "big/2.png": png(900, 1600),
    })
    res = _split(tmp_path, src, per_shard=10,
                 resize_mode="shortest", resize_value=768)
    assert res["total"] == 2

    shard = tmp_path / "dist" / "dist-0000.zip"
    with zipfile.ZipFile(shard) as zf:
        for name in ("big-000001.png", "big-000002.png"):
            with Image.open(io.BytesIO(zf.read(name))) as im:
                w, h = im.size
                assert min(w, h) == 768, f"{name} 最短边是 {min(w, h)}"
                assert abs(w / h - (1600 / 900)) < 0.01 or abs(w / h - (900 / 1600)) < 0.01


def test_parallel_path_matches_serial(tmp_path):
    """开多线程时 id 顺序必须和单线程完全一致——顺序一乱，id 就全错位。"""
    src = _make_zip(tmp_path / "a.zip", {f"p/{i}.jpg": b"y" * 300 for i in range(8)})

    _split(tmp_path, src, per_shard=4, workers=4, cpu_reserve=0)
    parallel = [r["image_id"] for s in sorted((tmp_path / "dist").glob("*.zip"))
                for r in _manifest(s)]

    params = SplitParams(input_dir=str(src), out_dir=str(tmp_path / "dist2"),
                         table=str(tmp_path / "t2.json"),
                         work_dir=str(tmp_path / "work"), nested=True,
                         per_shard=4, workers=1)
    run_split(params, on_progress=lambda *a: None,
              should_stop=lambda: False, on_log=lambda s: None)
    serial = [r["image_id"] for s in sorted((tmp_path / "dist2").glob("*.zip"))
              for r in _manifest(s)]

    assert parallel == serial
    assert len(parallel) == 8


def test_cancel_keeps_finished_shards(tmp_path):
    """取消时已经封口的包必须完整，不能写出半截 zip。"""
    src = _make_zip(tmp_path / "a.zip", {f"c/{i}.jpg": b"w" * 10 for i in range(6)})

    calls = {"n": 0}

    def stop() -> bool:
        calls["n"] += 1
        return calls["n"] > 4          # 写了几张之后喊停

    params = SplitParams(input_dir=str(src), out_dir=str(tmp_path / "dist"),
                         table=str(tmp_path / "shards.json"),
                         work_dir=str(tmp_path / "work"), nested=True, per_shard=2)
    with pytest.raises(Exception):
        run_split(params, on_progress=lambda *a: None,
                  should_stop=stop, on_log=lambda s: None)

    for shard in (tmp_path / "dist").glob("*.zip"):
        assert _members(shard)[-1] == "manifest.jsonl"   # 每个包都是完整的
    assert not list((tmp_path / "dist").glob("*.tmp"))


def test_scan_table_is_reused_on_resplit(tmp_path):
    """换 per_shard 重切同一批素材：不重新扫一遍，id 也不变。"""
    src = _make_zip(tmp_path / "a.zip", {f"p/{i}.jpg": b"z" * 10 for i in range(4)})
    _split(tmp_path, src, per_shard=4)

    scan = tmp_path / "dist" / "scan.jsonl"
    assert scan.is_file()
    mtime = scan.stat().st_mtime_ns
    ids1 = [r["image_id"] for r in _manifest(tmp_path / "dist" / "dist-0000.zip")]

    params = SplitParams(input_dir=str(src), out_dir=str(tmp_path / "dist2"),
                         table=str(tmp_path / "t2.json"),
                         work_dir=str(tmp_path / "work"), nested=True,
                         per_shard=2, scan_table=str(scan), verify_n=0)
    res = run_split(params, on_progress=lambda *a: None,
                    should_stop=lambda: False, on_log=lambda s: None)

    assert scan.stat().st_mtime_ns == mtime          # 没重写表 = 没重扫
    assert res["total"] == 4
    ids2 = [r["image_id"] for s in sorted((tmp_path / "dist2").glob("*.zip"))
            for r in _manifest(s)]
    assert ids2 == ids1


def test_verify_catches_stale_scan_table(tmp_path):
    """源文件变了，旧表必须被核对拦下——宁可不跑，也不产错位的 id。"""
    src = _make_zip(tmp_path / "a.zip", {f"p/{i}.jpg": b"z" * 10 for i in range(4)})
    _split(tmp_path, src, per_shard=4)
    scan = tmp_path / "dist" / "scan.jsonl"

    _make_zip(src, {f"p/{i}.jpg": b"z" * 20 for i in range(4)})   # 大小全变了

    params = SplitParams(input_dir=str(src), out_dir=str(tmp_path / "dist3"),
                         table=str(tmp_path / "t3.json"),
                         work_dir=str(tmp_path / "work"), nested=True,
                         per_shard=4, scan_table=str(scan), verify_n=4)
    with pytest.raises(ValueError, match="核对失败"):
        run_split(params, on_progress=lambda *a: None,
                  should_stop=lambda: False, on_log=lambda s: None)
