"""llama.cpp 引擎适配层：口令拼装、像素预算换算、缺件时的报错口径。

为什么这些要单独测
------------------
`nl_engine` 里每一个数字都对应一份产出分布：

- `-c` 是**总池**、vLLM 的 max_model_len 是**每序列**。拼错成直接传
  max_model_len，每个 slot 的上下文就只剩 1/n，长 caption 被截断——
  而截断不报错，只是数据整体变短。
- `--image-max-tokens` 与 `max_pixels` 是两种口径。算错会让换引擎之后
  的图被塞进不同的视觉 token 数，同一批数据出现按引擎分组的伪特征。

这些错都不会让服务起不来，只会让数据悄悄变样，所以必须用断言钉住。
"""

from __future__ import annotations

import types
from pathlib import Path

import pytest

from tagger import nl_engine
from tagger.config import ConfigError


def _profile(**over) -> types.SimpleNamespace:
    base = dict(
        model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                    gguf="models/nl/qwen3vl-8b/a.gguf",
                                    mmproj="models/nl/qwen3vl-8b/mmproj.gguf"),
        max_pixels=589824,
        max_model_len=8192,
        max_num_seqs=4,
        max_num_batched_tokens=0,
    )
    base.update(over)
    return types.SimpleNamespace(**base)


@pytest.fixture()
def fake_binary(monkeypatch) -> Path:
    """把 llama-server 指向一个真实存在的文件，绕开"没装"这一层。"""
    binary = Path(__file__).resolve().parent / "_fake_llama_server.exe"
    binary.write_bytes(b"")
    monkeypatch.setenv("TAGGER_LLAMA_SERVER", str(binary))
    try:
        yield binary
    finally:
        binary.unlink(missing_ok=True)


# ------------------------------------------------------------------ 引擎名

def test_engine_aliases_are_normalized():
    assert nl_engine.normalize_engine(None) == "vllm"      # 默认不用平台猜
    assert nl_engine.normalize_engine("") == "vllm"
    assert nl_engine.normalize_engine("llamacpp") == "llamacpp"
    assert nl_engine.normalize_engine("llama.cpp") == "llamacpp"
    assert nl_engine.normalize_engine("GGUF") == "llamacpp"
    assert nl_engine.normalize_engine("vllm") == "vllm"


def test_unknown_engine_is_rejected_with_options():
    with pytest.raises(ConfigError) as err:
        nl_engine.normalize_engine("tensorrt")
    assert "vllm" in str(err.value) and "llamacpp" in str(err.value)


# ------------------------------------------------------------------ 像素预算

def test_max_pixels_converts_to_vision_tokens():
    """589824 像素按 32×32 一个 token = 576，与 vLLM 侧的换算是同一套。"""
    assert nl_engine.image_tokens_for(_profile()) == 576


def test_other_family_refuses_to_guess():
    """换家族这个换算就不成立，宁可报错也不沿用 Qwen 的数字。"""
    p = _profile(model=types.SimpleNamespace(key="kimi", family="moonvit",
                                             gguf="a", mmproj="b"))
    with pytest.raises(ConfigError) as err:
        nl_engine.image_tokens_for(p)
    assert "32×32" in str(err.value) or "32" in str(err.value)


# ------------------------------------------------------------------ 权重解析

def test_missing_gguf_points_at_the_config_field(tmp_path, monkeypatch):
    monkeypatch.setattr(nl_engine, "ROOT", tmp_path)
    p = _profile(model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                             gguf="", mmproj=""))
    with pytest.raises(ConfigError) as err:
        nl_engine.resolve_weights(p)
    msg = str(err.value)
    assert "gguf:" in msg and "mmproj:" in msg
    # 权重 5.8GB，不能让人以为程序会自己下
    assert "modelscope" in msg or "huggingface" in msg


def test_mmproj_missing_is_not_an_optional_file(tmp_path, monkeypatch):
    """缺 mmproj 时服务照起，但每张图都会走纯文本路径——必须当硬错误拦住。"""
    monkeypatch.setattr(nl_engine, "ROOT", tmp_path)
    (tmp_path / "a.gguf").write_bytes(b"x")
    p = _profile(model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                             gguf="a.gguf", mmproj="missing.gguf"))
    with pytest.raises(ConfigError) as err:
        nl_engine.resolve_weights(p)
    assert "mmproj" in str(err.value)


def test_resolve_weights_accepts_absolute_paths(tmp_path, monkeypatch):
    monkeypatch.setattr(nl_engine, "ROOT", tmp_path / "elsewhere")
    gguf, mmproj = tmp_path / "a.gguf", tmp_path / "mm.gguf"
    gguf.write_bytes(b"x")
    mmproj.write_bytes(b"x")
    p = _profile(model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                             gguf=str(gguf), mmproj=str(mmproj)))
    assert nl_engine.resolve_weights(p) == (gguf, mmproj)


# ------------------------------------------------------------------ 命令行

def test_command_uses_measured_slot_plan(fake_binary, tmp_path):
    """`-c` 是总池 = slot 数 × 每 slot 上下文。

    不能照抄 vLLM 的 max_model_len（那是"最坏情况长上下文"），
    实测按 8192 × slot 数开会把 16GB 显存吃满、decode 崩到 1 tok/s。
    """
    gguf, mmproj = tmp_path / "a.gguf", tmp_path / "mm.gguf"
    gguf.write_bytes(b"x")
    mmproj.write_bytes(b"x")
    cmd = nl_engine.build_command(_profile(max_model_len=8192, max_num_seqs=4),
                                  port=8080, served_name="tagger",
                                  gguf=gguf, mmproj=mmproj, vram_gb=16.0)
    joined = " ".join(cmd)
    assert cmd[0].endswith("_fake_llama_server.exe")
    # 16GB → 12 slot × 3072
    assert "-np 12" in joined, joined
    assert "-c 36864" in joined, joined
    assert "-ctk q8_0" in joined and "-ctv q8_0" in joined
    # 路由名必须与任务表单里的「模型名」一致
    assert "-a tagger" in joined
    assert "--image-max-tokens 576" in joined
    assert "--mmproj" in joined and str(mmproj) in cmd
    assert "--metrics" in joined          # 没有它就只能靠肉眼判断过没过载


def test_slot_plan_follows_vram_tiers():
    """slot 数按显存分档：16G→12、10G→8、7G→4、未知→2。

    这些数字是实测出来的（12 是拐点，16 反而更慢），不是拍的。
    """
    p = _profile()
    assert nl_engine.slot_plan(p, 16.0)[0] == 12
    assert nl_engine.slot_plan(p, 24.0)[0] == 12      # 上限就停在 12
    assert nl_engine.slot_plan(p, 10.0)[0] == 8
    assert nl_engine.slot_plan(p, 7.0)[0] == 4
    assert nl_engine.slot_plan(p, None)[0] == 2       # 不知道就别赌
    assert nl_engine.slot_plan(p, 16.0)[1] == 3072    # 每 slot 上下文


def test_slot_plan_refuses_when_a_slot_cannot_hold_one_request():
    """视觉 token 就吃满上下文时，硬起只会得到被截断的产出。"""
    p = _profile(max_pixels=4 * 589824)        # 视觉 2304 token
    p.max_model_len = 2048
    with pytest.raises(ConfigError) as err:
        nl_engine.slot_plan(p, 16.0)
    assert "装不下" in str(err.value)


def test_missing_binary_is_a_config_error(monkeypatch):
    monkeypatch.delenv("TAGGER_LLAMA_SERVER", raising=False)
    monkeypatch.setattr(nl_engine.shutil, "which", lambda _n: None)
    with pytest.raises(ConfigError) as err:
        nl_engine.check_engine("llamacpp")
    assert "llama-server" in str(err.value)


def test_fingerprint_reads_slots_from_the_real_command_line():
    """并发数必须来自进程命令行，不是配置。

    profile 里写 8、进程实际开 12，客户端就会只送 8 条在途，
    每台机器白丢约 18% 吞吐——而且指纹会谎报运行参数。
    """
    from tagger.model_loader import _llamacpp_runtime_shape

    handle = types.SimpleNamespace(
        engine="llamacpp",
        cmd=["llama-server.exe", "-c", "36864", "-np", "12",
             "-ctk", "q8_0", "-ctv", "q8_0"])
    assert _llamacpp_runtime_shape(handle) == (12, "q8_0")

    vllm = types.SimpleNamespace(engine="vllm", cmd=["vllm", "serve"])
    assert _llamacpp_runtime_shape(vllm) == (None, "")

    broken = types.SimpleNamespace(engine="llamacpp", cmd=["llama-server", "-np"])
    assert _llamacpp_runtime_shape(broken)[0] is None


def test_client_concurrency_follows_the_fingerprint():
    """客户端在途数 = 指纹里的 max_num_seqs，否则服务端排队而 GPU 空转。"""
    from tagger.client import resolve_concurrency

    assert resolve_concurrency(None, {"max_num_seqs": 12}) == 12
    assert resolve_concurrency(None, {"max_num_seqs": 64}) == 32   # 上限
    assert resolve_concurrency(None, {}) == 4                      # 缺指纹的保守值
    assert resolve_concurrency(3, {"max_num_seqs": 12}) == 3       # 显式优先


def test_vllm_engine_still_goes_through_model_loader(monkeypatch):
    """vLLM 那一支的判定不能在本层被改口径，必须还走 check_environment。"""
    seen: list[str] = []
    import tagger.model_loader as loader

    monkeypatch.setattr(loader, "check_environment", lambda: seen.append("vllm"))
    nl_engine.check_engine("vllm")
    assert seen == ["vllm"]
