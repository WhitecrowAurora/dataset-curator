"""依赖检测：清单解析与状态判定的稳定断言。

刻意不假设"这台机器装了什么"：开发机、CI、全新装机三种环境下，能装的包
完全不同。这里只断言清单本身与判定逻辑，跑在哪儿都一样。
"""

from __future__ import annotations

from tagger.web.deps import (DepManager, Item, describe, installed_version,
                             load_extras, load_items)


def test_清单能读出来且不重名():
    items = load_items()
    assert items, "两份 requirements 至少要读出一批包"
    names = [i.name.lower().replace("_", "-") for i in items]
    assert len(names) == len(set(names)), "同一个包不该在页面上出现两行"


def test_清单包含运行环境必需的包():
    """fastapi / uvicorn 缺了服务根本起不来，它们必须在清单里。"""
    names = {i.name.lower() for i in load_items()}
    for must in ("fastapi", "uvicorn", "httpx", "websockets"):
        assert must in names


def test_分组只有三种():
    groups = {i.group for i in load_items()}
    assert groups <= {"core", "tag", "optional"}
    assert "core" in groups


def test_没装的包判为缺失():
    row = describe(Item(name="definitely-not-installed-xyz", spec="definitely-not-installed-xyz",
                        group="optional"))
    assert row["status"] == "missing"
    assert row["installed"] is None


def test_装了且版本符合的判为通过():
    # pytest 一定装着——这个测试文件正在被它跑。
    row = describe(Item(name="pytest", spec="pytest", group="core"))
    assert row["status"] == "ok"
    assert row["installed"] == installed_version("pytest")


def test_版本要求写死一个不可能的值时判为不符():
    row = describe(Item(name="pytest", spec="pytest==0.0.1", group="core"))
    assert row["status"] == "mismatch"


def test_导入名映射不会把_PIL_认错():
    """清单写的是 Pillow，import 用的是 PIL。少了映射表，装好的包会被报成缺失。"""
    item = Item(name="Pillow", spec="Pillow", group="core")
    assert item.module == "PIL"


def test_快照带着批量与检查字段():
    """页面靠这几个字段画批量进度和"导入失败"标记，缺了会静默画不出来。"""
    snap = DepManager().snapshot()
    assert "verify_at" in snap
    assert snap["summary"]["broken"] == 0       # 没检查过就该是 0，不是 None
    rows = [r for g in snap["groups"] for r in g["items"]]
    assert rows and all("verified" in r for r in rows)


def test_一次只允许一个动作在跑():
    mgr = DepManager()
    mgr.status = "running"                      # 假装有一个在跑
    try:
        mgr._start_many("verify", [Item(name="pytest", spec="pytest", group="core")])
    except RuntimeError:
        return
    raise AssertionError("并发动作应当被拒绝")


def test_非法包名被拒绝():
    mgr = DepManager()
    try:
        mgr._find("bad name; rm -rf /")
    except ValueError:
        return
    raise AssertionError("带空格的包名应当被拒绝")


# ---------------------------------------------------------------- 附加依赖
#
# 这几条守的是"页面上能一键装的东西，必须和 pyproject 里声明的同一串"。
# 抄一份清单到别处，迟早在某次升级后对不上，而且是对不上的那一刻才发现。


def test_附加依赖从_pyproject_读():
    extras = load_extras()
    assert "quantize" in extras, "量化用的 extra 必须在 pyproject 里能被读到"
    names = {it.name for it in extras["quantize"]}
    assert {"llmcompressor", "torch", "transformers"} <= names


def test_装附加依赖只挑缺的(monkeypatch):
    """已经装着的共用依赖不能动：为了补 llmcompressor 把打标用的 torch
    换一遍，等于把已产出 tag 的数值口径悄悄改掉。"""
    mgr = DepManager()
    seen: dict = {}
    monkeypatch.setattr(
        mgr, "_start_many",
        lambda action, items: seen.update(action=action, items=list(items)) or {})
    try:
        mgr.install_extra("quantize")
    except ValueError:
        # 这台机器上 extra 已经装齐了：拒绝白跑一次 pip 也是对的。
        assert seen == {}
        return
    assert seen["action"] == "install-quantize"
    assert seen["items"]
    assert all(describe(it)["status"] == "missing" for it in seen["items"])


def test_不认识的附加依赖被拒绝():
    try:
        DepManager().install_extra("definitely-not-an-extra")
    except ValueError:
        return
    raise AssertionError("不存在的 extra 应当被拒绝")


def test_install_extra_路由不会被通用路由吃掉(tmp_path):
    """`/api/deps/{name}/{action}` 也占两段，写成路径参数会被它先匹配走，
    然后报"不认识的操作"。这条路径必须保持单段 + query。"""
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    client = TestClient(create_app(ui_dist=tmp_path / "no-ui"))
    r = client.post("/api/deps/install-extra?extra=nope")
    assert r.status_code == 400, r.text
    assert "nope" in r.json()["detail"]
    assert client.post("/api/deps/install-extra").status_code == 400


def test_量化快照带上缺失依赖名单():
    """页面靠 missing_deps 决定给不给"一键安装"按钮；靠 reason 的中文
    去猜，改一个字按钮就消失。"""
    from tagger.quantize import QUANT

    snap = QUANT.snapshot(None)
    assert isinstance(snap.get("missing_deps"), list)
