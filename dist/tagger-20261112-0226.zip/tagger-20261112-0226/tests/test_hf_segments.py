"""多连接分段下载（IDM 式）。

三条最容易出错的边界：段计划必须无缝覆盖整个文件；中途取消后 `.part` 被
预分配成总长，**不能**再按"长度等于 total"判完成；服务端忽略 Range 时
必须干净地退回单连接，而不是写出一份花的数据。
"""

from __future__ import annotations

import hashlib
import http.server
import re
import threading

import pytest

from tagger import hf_source

SIZE = 17 * 1024 * 1024          # > 2×SEG_MIN_BYTES 才会分段
DATA = bytearray(range(256)) * (SIZE // 256) + bytes(SIZE % 256)
DIGEST = hashlib.sha256(bytes(DATA)).hexdigest()


class _RangeHandler(http.server.BaseHTTPRequestHandler):
    supports_range = True

    def do_GET(self) -> None:                          # noqa: N802
        rng = self.headers.get("Range")
        if rng and self.supports_range:
            m = re.match(r"bytes=(\d+)-(\d*)", rng)
            assert m, rng
            first = int(m.group(1))
            last = int(m.group(2)) if m.group(2) else SIZE - 1
            last = min(last, SIZE - 1)
            body = bytes(DATA[first:last + 1])
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {first}-{last}/{SIZE}")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(200)
        self.send_header("Content-Length", str(SIZE))
        self.end_headers()
        self.wfile.write(bytes(DATA))

    def log_message(self, *args) -> None:              # 静默
        pass


class _NoRangeHandler(_RangeHandler):
    supports_range = False


def _serve(handler) -> tuple[str, http.server.ThreadingHTTPServer]:
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{httpd.server_address[1]}/f.bin", httpd


@pytest.fixture
def ranged(monkeypatch):
    url, httpd = _serve(_RangeHandler)
    monkeypatch.setattr(hf_source, "resolve_url", lambda *a, **kw: url)
    yield url
    httpd.shutdown()


def test_plan_segments_covers_everything():
    plan = hf_source.plan_segments(SIZE, 4)
    assert len(plan) >= 2
    assert plan[0][0] == 0 and plan[-1][1] == SIZE - 1
    for (_, end), (start, _) in zip(plan, plan[1:]):
        assert start == end + 1, "段之间不能有缝或重叠"


def test_tiny_file_falls_back_to_one_segment():
    assert hf_source.plan_segments(1024, 8) == [(0, 1023)]


def test_segmented_download_is_byte_exact(ranged, tmp_path, monkeypatch):
    starts: list[int] = []
    real = hf_source._fetch_range

    def spy(url, headers, path, begin, end, *a, **kw):
        starts.append(begin)
        return real(url, headers, path, begin, end, *a, **kw)

    monkeypatch.setattr(hf_source, "_fetch_range", spy)

    shard = hf_source.download_shard("org/ds", "a.tar", tmp_path,
                                     verbose=False, conns=4)
    assert shard.path == tmp_path / "a.tar"
    assert hashlib.sha256(shard.path.read_bytes()).hexdigest() == DIGEST
    # 真的并发分段了，而不是静默退回单连接
    assert len(starts) >= 2
    # 成功后不该留下半成品或段状态
    assert not list(tmp_path.glob("*.part*"))


def test_cancel_keeps_progress_and_resumes(ranged, tmp_path):
    seen = {"n": 0}

    def on_progress(done: int, total: int) -> None:
        seen["n"] = max(seen["n"], done)

    def stop() -> bool:
        return seen["n"] > SIZE * 0.3

    with pytest.raises(hf_source.HFCancelled):
        hf_source.download_shard("org/ds", "a.tar", tmp_path, verbose=False,
                                 conns=4, on_progress=on_progress,
                                 should_stop=stop)
    part = tmp_path / "a.tar.part"
    state = tmp_path / "a.tar.part.json"
    assert part.is_file() and state.is_file()
    # 预分配：长度已经等于总长——所以"长度==total"不能当完成判据
    assert part.stat().st_size == SIZE

    # 第二次即使 conns=1，也必须按状态文件里的段计划续传
    shard = hf_source.download_shard("org/ds", "a.tar", tmp_path,
                                     verbose=False, conns=1)
    assert hashlib.sha256(shard.path.read_bytes()).hexdigest() == DIGEST
    assert not list(tmp_path.glob("*.part*"))


def test_server_without_range_falls_back(monkeypatch, tmp_path):
    url, httpd = _serve(_NoRangeHandler)
    monkeypatch.setattr(hf_source, "resolve_url", lambda *a, **kw: url)
    try:
        shard = hf_source.download_shard("org/ds", "a.tar", tmp_path,
                                         verbose=False, conns=4)
        assert hashlib.sha256(shard.path.read_bytes()).hexdigest() == DIGEST
        assert not list(tmp_path.glob("*.part*"))
    finally:
        httpd.shutdown()
