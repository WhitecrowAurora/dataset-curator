"""NL 提示词配置文件（prompt/*.json）与它的接口。

这一层要保证的几件事：
1. 文件名就是显示名，中文照原样落盘、能原样读回；
2. 手写 JSON 写错（`promt` / 顶层不是对象 / prompt 空）要报错，不能静默当成空提示词；
3. 坏文件仍然出现在清单里（带 error），不能"点开就少一条"；
4. 选中的提示词必须真的被发给模型：整段替换内置那份，system 与中文版各归各位；
5. 换提示词要换缓存指纹，否则换一套指令会命中旧缓存。
"""

from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from tagger import prompts as prompt_files


@pytest.fixture()
def prompt_dir(tmp_path, monkeypatch):
    d = tmp_path / "prompt"
    monkeypatch.setattr(prompt_files, "PROMPT_DIR", d)
    return d


# ---------------------------------------------------------------- 文件层

def test_create_and_list_chinese_name(prompt_dir):
    doc = prompt_files.create("更口语的描述", {"prompt": "You describe images plainly."})
    assert doc["id"] == "更口语的描述"
    assert (prompt_dir / "更口语的描述.json").is_file()

    items = prompt_files.list_prompts()
    assert [it["id"] for it in items] == ["更口语的描述"]
    assert items[0]["chars"] == len("You describe images plainly.")
    assert items[0]["has_zh"] is False
    assert "error" not in items[0]


def test_save_ignores_meta_keys(prompt_dir):
    """前端把读到的整个对象原样 PUT 回来，多带的 name/path 不该报错。"""
    prompt_files.create("x", {"prompt": "a"})
    got = prompt_files.save("x", {
        "name": "x", "path": "prompt/x.json", "id": "x",
        "prompt": "b", "prompt_zh": "乙", "note": "备注",
    })
    assert got["prompt"] == "b"
    raw = json.loads((prompt_dir / "x.json").read_text(encoding="utf-8"))
    assert raw == {"prompt": "b", "prompt_zh": "乙", "note": "备注"}


def test_empty_optional_fields_are_not_written(prompt_dir):
    prompt_files.create("x", {"prompt": "a", "system": "  ", "note": ""})
    raw = json.loads((prompt_dir / "x.json").read_text(encoding="utf-8"))
    assert raw == {"prompt": "a"}


def test_unknown_field_is_rejected(prompt_dir):
    with pytest.raises(prompt_files.PromptError, match="不认识的字段"):
        prompt_files.create("x", {"promt": "typo"})
    # 下划线开头当注释放行
    prompt_files.create("ok", {"prompt": "a", "_comment": "随手记"})
    assert prompt_files.load("ok").prompt == "a"


def test_prompt_is_required(prompt_dir):
    with pytest.raises(prompt_files.PromptError, match="prompt"):
        prompt_files.create("x", {"prompt": "   "})
    with pytest.raises(prompt_files.PromptError, match="顶层必须是对象"):
        prompt_dir.mkdir(parents=True)
        (prompt_dir / "list.json").write_text("[1, 2]", encoding="utf-8")
        prompt_files.load("list")


def test_duplicate_name_is_rejected_case_insensitively(prompt_dir):
    prompt_files.create("Style", {"prompt": "a"})
    with pytest.raises(prompt_files.PromptError, match="已经有"):
        prompt_files.create("style", {"prompt": "b"})


@pytest.mark.parametrize("bad", ["", "   ", "a/b", "x:y", "../逃逸", ".hidden", "con"])
def test_bad_names_are_rejected(prompt_dir, bad):
    with pytest.raises(prompt_files.PromptError):
        prompt_files.create(bad, {"prompt": "a"})


def test_broken_file_is_still_listed(prompt_dir):
    prompt_dir.mkdir(parents=True)
    (prompt_dir / "坏.json").write_text("{not json", encoding="utf-8")
    (prompt_dir / "空.json").write_text('{"prompt": ""}', encoding="utf-8")
    (prompt_dir / "好.json").write_text('{"prompt": "ok"}', encoding="utf-8")

    items = {it["id"]: it for it in prompt_files.list_prompts()}
    assert set(items) == {"坏", "空", "好"}
    assert "error" in items["坏"]
    assert "error" in items["空"]
    assert "error" not in items["好"]
    with pytest.raises(prompt_files.PromptError):
        prompt_files.load("坏")


def test_missing_id_lists_what_is_there(prompt_dir):
    prompt_files.create("有一份", {"prompt": "a"})
    with pytest.raises(prompt_files.PromptError, match="有一份"):
        prompt_files.load("没有这份")


def test_empty_dir_is_not_an_error(prompt_dir):
    """目录都还没建时，清单是空的——首次使用不该看到一个报错。"""
    assert prompt_files.list_prompts() == []
    assert not prompt_dir.exists()


# ---------------------------------------------------------------- 用到模型上

def _client(**kw):
    from tagger.artist import ArtistRule
    from tagger.client import StageTimer, TaggerClient
    from tagger.config import OutputSpec
    from tagger.quality import QualityGate, QualityPolicy

    return TaggerClient(
        base_url="http://127.0.0.1:1",      # 不会真的发请求
        model_name="tagger",
        output=OutputSpec(mode="both"),
        temperature=0.2,
        top_p=0.9,
        max_tokens=1024,
        timeout_s=1,
        max_attempts=1,
        gate=QualityGate(QualityPolicy(), verbose=False),
        prov_base={"model_id": "m"},
        artist_rule=ArtistRule(),
        stage=StageTimer(),
        **kw,
    )


def test_custom_prompt_replaces_builtin():
    from tagger.client import SYSTEM_PROMPT

    builtin = _client()
    custom = _client(prompt_text="自定义指令", system_text="你是另一个助手")

    assert builtin.system == SYSTEM_PROMPT
    assert custom.prompt == "自定义指令"
    assert custom.system == "你是另一个助手"
    assert custom.prompt != builtin.prompt
    # 换提示词/换 system 都必须换指纹，否则回命中上一套的缓存
    assert custom._cache_fingerprint() != builtin._cache_fingerprint()


def test_system_change_alone_changes_fingerprint():
    a = _client(prompt_text="同一份", system_text="甲")
    b = _client(prompt_text="同一份", system_text="乙")
    assert a.prompt == b.prompt
    assert a._cache_fingerprint() != b._cache_fingerprint()


def test_custom_prompt_without_zh_produces_no_chinese():
    """自定义提示词没写中文版时不许拿内置中文版来凑：两边要求不同，
    混在一批数据里事后分不出来。"""
    client = _client(prompt_text="自定义", caption_zh_ratio=0.5)
    assert client.prompt_zh == ""

    with_zh = _client(prompt_text="自定义", prompt_zh_text="中文版",
                      caption_zh_ratio=0.5)
    assert with_zh.prompt_zh == "中文版"

    # 比例为 0 = 这批全英文，给不给中文版都不用
    off = _client(prompt_text="自定义", prompt_zh_text="中文版",
                  caption_zh_ratio=0.0)
    assert off.prompt_zh == ""


# ---------------------------------------------------------------- 接口

@pytest.fixture()
def api(prompt_dir, tmp_path):
    from tagger.web.app import create_app

    with TestClient(create_app(ui_dist=tmp_path / "no-ui")) as test_client:
        yield test_client


def test_api_create_list_save(api):
    resp = api.post("/api/prompts", json={"name": "我的 一套", "prompt": "hello"})
    assert resp.status_code == 201, resp.text
    assert resp.json()["id"] == "我的 一套"

    listed = api.get("/api/prompts").json()
    assert [it["id"] for it in listed["items"]] == ["我的 一套"]

    got = api.get("/api/prompts/one", params={"id": "我的 一套"}).json()
    assert got["prompt"] == "hello"

    saved = api.put("/api/prompts/one", params={"id": "我的 一套"},
                    json={"prompt": "hello2", "prompt_zh": "你好"})
    assert saved.status_code == 200, saved.text
    assert saved.json()["prompt_zh"] == "你好"
    assert api.get("/api/prompts/one", params={"id": "我的 一套"}).json()["prompt"] == "hello2"


def test_api_rejects_bad_payload(api):
    assert api.post("/api/prompts", json={"prompt": "没名字"}).status_code == 400
    assert api.post("/api/prompts", json={"name": "x", "prompt": ""}).status_code == 400
    assert api.post("/api/prompts", json={"name": "y", "prompt": "a"}).status_code == 201
    assert api.get("/api/prompts/one", params={"id": "没有"}).status_code == 400


def test_api_template_is_the_builtin_prompt(api):
    tpl = api.get("/api/prompts/template").json()
    assert len(tpl["prompt"]) > 200          # 内置提示词是一大段，不是占位
    assert tpl["prompt_zh"]
    assert tpl["system"]
