"""llama.cpp 运行时：查找顺序、解压安全、安装状态。

**不联网**：真去 GitHub 下 200MB 不是单测该干的事。这里锁的都是"装完能
不能找到""解压会不会写到目录外""状态字段齐不齐"——这几件事错了，页面上
的表现分别是"装好了仍说没装""莫名其妙多出文件""进度条不动"。
"""

from __future__ import annotations

import threading
import zipfile

import pytest

from tagger import llama_runtime as lr


# ------------------------------------------------------------------ 查找顺序

def test_env_override_wins(tmp_path, monkeypatch):
    """TAGGER_LLAMA_SERVER 是显式指定，优先级必须最高。"""
    fake = tmp_path / "llama-server.exe"
    fake.write_text("x", encoding="utf-8")
    monkeypatch.setenv("TAGGER_LLAMA_SERVER", str(fake))
    assert lr.find_binary() == str(fake)


def test_env_override_pointing_nowhere_does_not_fall_back(tmp_path, monkeypatch):
    """指了个不存在的路径就该明确失败，而不是悄悄用另一份构建——
    那会让"我明明指定了版本"变成一句假话。"""
    monkeypatch.setenv("TAGGER_LLAMA_SERVER", str(tmp_path / "nope.exe"))
    monkeypatch.setattr(lr, "_local_binary", lambda: tmp_path / "other.exe")
    assert lr.find_binary() is None


def test_installed_copy_beats_path(tmp_path, monkeypatch):
    """本程序装的排在 PATH 前面：刚点完按钮的那一份才是用户想用的。"""
    monkeypatch.delenv("TAGGER_LLAMA_SERVER", raising=False)
    root = tmp_path / "runtime"
    binary = root / "build" / "bin" / lr.BINARY_NAME
    binary.parent.mkdir(parents=True)
    binary.write_text("x", encoding="utf-8")
    monkeypatch.setattr(lr, "INSTALL_ROOT", root)
    # zip 解出来可能是 build/bin/，也可能平铺，所以要能找到嵌套的那份
    assert lr.find_binary() == str(binary)


# ------------------------------------------------------------------ 解压

def test_extract_refuses_to_write_outside_the_target(tmp_path):
    """包是从网上下来的：即使是官方源，也不该给它写任意路径的权力。"""
    archive = tmp_path / "pkg.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("bin/llama-server.exe", "MZ")
        zf.writestr("../escaped.txt", "boom")

    dest = tmp_path / "dest"
    lr._extract(archive, dest, threading.Event())

    assert (dest / "bin" / "llama-server.exe").read_text(encoding="utf-8") == "MZ"
    assert not (tmp_path / "escaped.txt").exists()


def test_extract_honours_cancel(tmp_path):
    archive = tmp_path / "pkg.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("a.txt", "1")
        zf.writestr("b.txt", "2")
    cancel = threading.Event()
    cancel.set()
    with pytest.raises(lr._Cancelled):
        lr._extract(archive, tmp_path / "dest", cancel)


# ------------------------------------------------------------------ 状态/安装

def test_status_reports_missing_without_touching_the_network(monkeypatch):
    monkeypatch.setattr(lr, "find_binary", lambda: None)
    monkeypatch.setattr(lr, "_read_version", lambda: "")
    snap = lr.status()
    assert snap["installed"] is False
    assert snap["binary"] == ""
    for key in ("install_root", "busy", "stage", "done", "total",
                "error", "supported", "platform"):
        assert key in snap


def test_install_is_a_no_op_when_already_present(monkeypatch):
    """已经装了还去下 200MB，是用户点了按钮之后最莫名其妙的事。"""
    monkeypatch.setattr(lr, "find_binary", lambda: "C:/x/llama-server.exe")
    out = lr.install()
    assert out["started"] is False
    assert "已经装了" in out["reason"]


def test_asset_kind_splits_cudart_from_main():
    assert lr._asset_kind("cudart-llama-bin-win-cuda-12.4-x64.zip") == "cudart"
    assert lr._asset_kind("llama-b7123-bin-win-cuda-12.4-x64.zip") == "main"


def test_platform_tag_is_none_where_official_builds_dont_exist(monkeypatch):
    monkeypatch.setattr(lr.platform, "system", lambda: "Darwin")
    assert lr._platform_tag() is None
    monkeypatch.setattr(lr.platform, "system", lambda: "Windows")
    monkeypatch.setattr(lr.platform, "machine", lambda: "AMD64")
    assert lr._platform_tag() == "win-x64"


# ------------------------------------------------------------------ Web 接口

def test_web_llama_status_exposes_install_state(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    monkeypatch.setattr(lr, "find_binary", lambda: None)
    client = TestClient(create_app(ui_dist=tmp_path / "no-ui"))
    body = client.get("/api/llama").json()
    assert body["installed"] is False
    assert body["install_root"].endswith("llama.cpp")
    # supported 决定页面给不给按钮：给了却必然失败更糟
    assert "supported" in body


# ------------------------------------------------------------------ 资产匹配
#
# 2026 年 llama.cpp 的发布形态换了两次：
#   1. `latest` 指向版本号发布（v0.9.0），那里可能一个二进制都没有；
#   2. 资产名从 `-bin-win-cuda-x64` 变成 `-bin-win-cuda-13.5-x64`（架构插在后端后面）。
# 旧实现只查 latest + 要求连续子串 `-bin-cuda`，于是"点安装必失败"。这几条锁住
# 新口径，避免下次命名再变时又静默坏掉。


def test_资产名匹配按词而不是连续子串():
    assert lr._matches_asset("llama-b12188-bin-win-cuda-13.5-x64.zip", "win-cuda")
    assert lr._matches_asset("llama-b7123-bin-win-cuda-12.4-x64.zip", "win-cuda")
    assert lr._matches_asset("llama-b1-bin-win-vulkan-x64.zip", "win-vulkan")
    assert lr._matches_asset("llama-b1-bin-win-cpu-x64.zip", "win-cpu")


def test_资产名匹配不跨平台不跨架构():
    # arm64 包装到 x64 机器上，症状是"exe 一闪而过"，比不装更难查
    assert not lr._matches_asset("llama-b1-bin-win-cpu-arm64.zip", "win-cpu")
    assert not lr._matches_asset("llama-b1-bin-ubuntu-x64.zip", "win-cpu")
    assert not lr._matches_asset("llama-b1-bin-win-vulkan-x64.zip", "win-cpu")


def test_cudart_必须同平台同架构同版本():
    assert lr._matches_cudart("cudart-llama-bin-win-cuda-13.5-x64.zip", "win-cuda", 13.5)
    # 踩过的真实资产名：只判前缀 + 版本号时会被选中，解出来一堆 .so
    assert not lr._matches_cudart(
        "cudart-llama-b12189-bin-ubuntu-cuda-13.5-arm64.tar.gz", "win-cuda", 13.5)
    assert not lr._matches_cudart("cudart-llama-bin-win-cuda-12.4-x64.zip", "win-cuda", 13.5)


def test_cuda_版本不超过驱动能力():
    assets = [
        {"name": "llama-b1-bin-win-cuda-12.4-x64.zip", "browser_download_url": "u12", "size": 1},
        {"name": "llama-b1-bin-win-cuda-13.5-x64.zip", "browser_download_url": "u13", "size": 1},
    ]
    # 老驱动只吃 12.x；新驱动挑最高的 13.x
    assert lr._pick_main(assets, "win-cuda", 12)["url"] == "u12"
    assert lr._pick_main(assets, "win-cuda", 13)["url"] == "u13"
    assert lr._pick_main(assets[1:], "win-cuda", 12) is None


@pytest.mark.parametrize("fallback", ["vulkan", "cpu"])
def test_release_falls_back_when_cuda_requires_newer_driver(monkeypatch, fallback):
    assets = [{"name": f"llama-b1-bin-win-{kind}-x64.zip",
               "browser_download_url": "unused", "size": 1}
              for kind in ("cuda-13.5", fallback)]
    monkeypatch.setattr(lr, "_platform_tag", lambda: "win-x64")
    monkeypatch.setattr(lr, "_has_nvidia", lambda: True)
    monkeypatch.setattr(lr, "_max_cuda_major", lambda: 12)
    monkeypatch.setattr(lr, "_list_releases", lambda *args: [{"tag_name": "b1", "assets": assets}])
    _, chosen = lr._resolve_release(threading.Event())
    assert fallback in chosen[0]["name"]
