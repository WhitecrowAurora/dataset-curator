"""画师对照表接口（表 / 目录）、注入优先级，以及 prompt v4 的三处新增。

这一层要保证的几件事：
1. 表里有就用表，表里没有才退回目录名——反过来会出现"人工整理的名字被
   danbooru 的错标覆盖"；
2. 目录形态只读当前分片那一份，不去碰别的分片；
3. 谁都没有就留空，不拿上级目录凑；
4. 参考 tag 段只在真有 tag 时出现，空段落会让模型以为"这次没提示"从而编名字；
5. 画面里的文字用原语言引用时，不会让整条 caption 被判成中文。
"""

from __future__ import annotations

from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from tagger.artist import ArtistRule, ArtistTable
from tagger.client import (TaskRow, TaggerClient, _prompt_for, _ref_block,
                           _ref_tags_of)
from tagger.config import OutputSpec
from tagger.quality import QualityGate, QualityPolicy, is_cjk_text


def _parquet(path, rows: dict[int, list[str]], *, meta: dict[str, str] | None = None):
    tbl = pa.table({
        "id": pa.array(list(rows), pa.int64()),
        "artists": pa.array(list(rows.values()), pa.list_(pa.string())),
        "sources": pa.array([["danbooru2024"]] * len(rows), pa.list_(pa.string())),
    })
    if meta:
        # 与 work/shard_artists.py 同构：切表时把 tar 名与行数写进文件级
        # metadata，加载侧靠它判断"这片是不是我要的那片"。
        tbl = tbl.replace_schema_metadata(
            {str(k).encode(): str(v).encode() for k, v in meta.items()})
    pq.write_table(tbl, path)
    return path


def _client(**kw):
    from tagger.client import StageTimer

    kw.setdefault("artist_rule", ArtistRule(enabled=True))
    return TaggerClient(
        base_url="http://127.0.0.1:1",
        model_name="tagger",
        output=OutputSpec(mode="both"),
        temperature=0.2,
        top_p=0.9,
        max_tokens=1024,
        timeout_s=1,
        max_attempts=1,
        gate=QualityGate(QualityPolicy(), verbose=False),
        prov_base={"model_id": "m"},
        stage=StageTimer(),
        **kw,
    )


def _task(image_id="8349000", shard="shard-000123.tar", artist="from_dir"):
    return TaskRow(shard=shard, image_id=image_id, file=f"{image_id}.jpg",
                   artist=artist)


# ---------------------------------------------------------------- 表本身

def test_id_从文件名或路径里都能取():
    assert ArtistTable.id_of("8349000") == 8349000
    assert ArtistTable.id_of("8349000.jpg") == 8349000
    assert ArtistTable.id_of("output/8349000.webp") == 8349000
    assert ArtistTable.id_of("no-digits") is None


def test_id_取末段最长的那串数字():
    """取"最后一串"会在重名后缀上拿到 1，取"第一串"会在带数字的目录名上
    拿到目录里的数——两头都错，只有最长串对。"""
    assert ArtistTable.id_of("8349000_1.jpg") == 8349000
    assert ArtistTable.id_of("artist-8349000.webp") == 8349000
    assert ArtistTable.id_of("sub2/8349000.jpg") == 8349000


def test_单文件表能查到(tmp_path):
    p = _parquet(tmp_path / "all.parquet", {8349000: ["ban_syou"]})
    table = ArtistTable(str(p))
    assert table.lookup("8349000") == ["ban_syou"]
    assert table.lookup("8349001") == []


def test_目录形态只读对应分片(tmp_path):
    d = tmp_path / "shards"
    d.mkdir()
    _parquet(d / "shard-000123.artist.parquet", {1: ["a"]})
    _parquet(d / "shard-000124.artist.parquet", {2: ["b"]})
    table = ArtistTable(str(d))
    assert table.lookup("1", "shard-000123.tar") == ["a"]
    assert table.lookup("2", "shard-000123.tar") == []      # 不串片
    assert table.lookup("1", "shard-000999.tar") == []      # 缺文件不报错
    assert table.lookup("1") == []                          # 没分片名就不猜


def test_分片名的几种写法都归一到同一个名字():
    """分片名从三处来：本地路径、HF 直读 URI、manifest 的 rel_path。"""
    assert ArtistTable.shard_stem("D:\\d\\shard-000012.tar") == "shard-000012"
    assert ArtistTable.shard_stem(
        "hf://datasets/a/b/shard-000012.tar#0001.jpg") == "shard-000012"
    assert ArtistTable.shard_stem("shard-000012.tar.gz") == "shard-000012"
    assert ArtistTable.shard_stem("dist-0003.zip::artist/0001.jpg") == "dist-0003"
    assert ArtistTable.shard_stem("shard-000012.artist.parquet") == "shard-000012"
    assert ArtistTable.shard_stem("shard-000012") == "shard-000012"
    assert ArtistTable.shard_stem("") == ""


def test_分片记的是别的片就拒答(tmp_path):
    """一片按旧数据切出来的 parquet：列名、行数、类型全对，只有编号是旧的。
    照用它等于把别人的画师给这张图，且一句日志都没有——所以必须拒答。"""
    d = tmp_path / "shards"
    d.mkdir()
    _parquet(d / "shard-000123.artist.parquet", {1: ["a"]},
             meta={"shard": "shard-000122.tar", "rows": 1})
    table = ArtistTable(str(d))
    assert table.lookup("1", "shard-000123.tar") == []
    assert table.active is True
    assert table.problems and "shard-000122" in table.problems[0]


def test_行数对不上的分片也拒答(tmp_path):
    d = tmp_path / "shards"
    d.mkdir()
    _parquet(d / "shard-000123.artist.parquet", {1: ["a"], 2: ["b"]},
             meta={"shard": "shard-000123.tar", "rows": 5})
    table = ArtistTable(str(d))
    assert table.lookup("1", "shard-000123.tar") == []
    assert any("行" in p for p in table.problems)


def test_配对得上就照常回答(tmp_path):
    d = tmp_path / "shards"
    d.mkdir()
    _parquet(d / "shard-000123.artist.parquet", {1: ["a"]},
             meta={"shard": "shard-000123.tar", "rows": 1})
    assert ArtistTable(str(d)).lookup("1", "shard-000123.tar") == ["a"]


def test_分片表后到不会被空结果钉死(tmp_path):
    """分片 parquet 可能是边跑边拷的：第一次没读到不能记成"这片没画师"。"""
    d = tmp_path / "shards"
    d.mkdir()
    table = ArtistTable(str(d))
    assert table.lookup("1", "shard-000123.tar") == []
    _parquet(d / "shard-000123.artist.parquet", {1: ["a"]},
             meta={"shard": "shard-000123.tar", "rows": 1})
    assert table.lookup("1", "shard-000123.tar") == ["a"]


def test_一片读不动不影响别的片(tmp_path):
    """以前这类错误写进 self.error，active 一关，后面每片都跟着失效。"""
    d = tmp_path / "shards"
    d.mkdir()
    (d / "shard-000123.artist.parquet").write_bytes(b"not a parquet")
    _parquet(d / "shard-000124.artist.parquet", {2: ["b"]},
             meta={"shard": "shard-000124.tar", "rows": 1})
    table = ArtistTable(str(d))
    assert table.lookup("1", "shard-000123.tar") == []
    assert table.lookup("2", "shard-000124.tar") == ["b"]
    assert table.active is True
    assert table.problems


def test_在线画师表地址解析():
    """带 `.parquet` 是单表，其余一律当分片目录——写法必须有唯一解。"""
    single = ArtistTable("hf://datasets/me/arts/all.parquet")
    assert single.active and single.online
    assert single.remote_repo == "me/arts" and single.remote_file == "all.parquet"

    shards = ArtistTable("hf://datasets/me/arts/shards")
    assert shards.active and shards.remote_dir == "shards"

    bad = ArtistTable("hf://me/arts")
    assert not bad.active and "hf://datasets" in bad.error


def test_在线单表只拉一次(tmp_path):
    p = _parquet(tmp_path / "all.parquet", {8349000: ["a"]})
    calls: list[str] = []
    table = ArtistTable("hf://datasets/me/arts/all.parquet")
    table._fetch = lambda fn: (calls.append(fn) or p)
    assert table.lookup("8349000") == ["a"]
    assert table.lookup("8349000") == ["a"]
    assert calls == ["all.parquet"]


def test_在线分片用哪片拉哪片(tmp_path):
    p = _parquet(tmp_path / "a.parquet", {1: ["a"]},
                 meta={"shard": "shard-000123.tar", "rows": 1})
    remote = {"shards/shard-000123.artist.parquet": p}
    calls: list[str] = []
    table = ArtistTable("hf://datasets/me/arts/shards")
    table._fetch = lambda fn: (calls.append(fn) or remote.get(fn))

    assert table.lookup("1", "shard-000123.tar") == ["a"]
    assert table.lookup("1", "shard-000123.tar") == ["a"]       # 命中本地缓存
    assert table.lookup("1", "shard-000999.tar") == []
    assert calls == ["shards/shard-000123.artist.parquet",
                     "shards/shard-000999.artist.parquet"]


def test_在线分片拉不到不反复重试():
    """仓库里没有这片就是没有；每张图重试一次会把 844 片变成几十万次 404。"""
    calls: list[str] = []
    table = ArtistTable("hf://datasets/me/arts/shards")
    table._fetch = lambda fn: (calls.append(fn) or None)
    for _ in range(3):
        assert table.lookup("1", "shard-000123.tar") == []
    assert len(calls) == 1
    assert table.active is True            # 单片拉不到不等于整张表不能用


def test_在线分片也要配对(tmp_path):
    p = _parquet(tmp_path / "x.parquet", {1: ["a"]},
                 meta={"shard": "shard-000122.tar", "rows": 1})
    table = ArtistTable("hf://datasets/me/arts/shards")
    table._fetch = lambda fn: p
    assert table.lookup("1", "shard-000123.tar") == []
    assert table.problems


def test_路径不存在时给出原因而不是抛栈(tmp_path):
    table = ArtistTable(str(tmp_path / "nope.parquet"))
    assert not table.active
    assert "不存在" in table.error
    assert table.lookup("1", "shard-000001.tar") == []


# ---------------------------------------------------------------- 注入优先级

def test_表优先于目录名(tmp_path):
    p = _parquet(tmp_path / "all.parquet", {8349000: ["ban_syou"]})
    c = _client(artist_rule=ArtistRule(enabled=True, table=str(p)))
    task = _task(artist="from_dir")
    assert c._artist_names(task) == (["ban_syou"], "table")
    assert c._artist_tag_of(task) == "@ban_syou"


def test_表里没有就退回目录名(tmp_path):
    p = _parquet(tmp_path / "all.parquet", {1: ["x"]})
    c = _client(artist_rule=ArtistRule(enabled=True, table=str(p)))
    task = _task(image_id="8349000", artist="from_dir")
    assert c._artist_names(task) == (["from_dir"], "path")


def test_两边都没有就不注入(tmp_path):
    c = _client(artist_rule=ArtistRule(enabled=True))
    task = _task(artist="")
    assert c._artist_names(task) == ([], "")
    assert c._artist_tag_of(task) == ""


def test_关掉画师就一律不注入(tmp_path):
    p = _parquet(tmp_path / "all.parquet", {8349000: ["ban_syou"]})
    c = _client(artist_rule=ArtistRule(enabled=False, table=str(p)))
    assert c._artist_tag_of(_task()) == ""


def test_多画师只注入第一个但全部记下(tmp_path):
    p = _parquet(tmp_path / "all.parquet", {8349000: ["a", "b"]})
    c = _client(artist_rule=ArtistRule(enabled=True, table=str(p)))
    task = _task()
    assert c._artist_tag_of(task) == "@a"
    fields = c._artist_fields(task)
    assert fields["artists"] == ["a", "b"]
    assert fields["artist_source"] == "table"


def test_包内表口径压过查表(tmp_path):
    """封包时查好、跟着图一起封进来的值 = 逐图确认过的答案。
    再按分片查一次表，只会把确定值换成依赖分片命名的推测值。"""
    p = _parquet(tmp_path / "all.parquet", {8349000: ["stale_from_shard"]})
    c = _client(artist_rule=ArtistRule(enabled=True, table=str(p)))
    task = TaskRow(shard="s", image_id="8349000", file="x.jpg",
                   artist="packed", artist_source="table",
                   artists=("packed", "second"))
    assert c._artist_names(task) == (["packed", "second"], "table")


def test_包内目录名口径不压过查表(tmp_path):
    """目录名是从路径顺手拿的，表才是 danbooru 原始标注。"""
    p = _parquet(tmp_path / "all.parquet", {8349000: ["from_table"]})
    c = _client(artist_rule=ArtistRule(enabled=True, table=str(p)))
    task = TaskRow(shard="s", image_id="8349000", file="x.jpg",
                   artist="from_dir", artist_source="path")
    assert c._artist_names(task) == (["from_table"], "table")


def test_没有表时包内值照用(tmp_path):
    c = _client(artist_rule=ArtistRule(enabled=True))
    task = TaskRow(shard="s", image_id="1", file="x.jpg",
                   artist="packed", artist_source="table",
                   artists=("a", "b"))
    assert c._artist_names(task) == (["a", "b"], "table")


def test_封包阶段查表并标记来源(tmp_path):
    """封包烧表的目的：让画师跟着图走，下游不必再按分片名找索引表。"""
    from tagger.pipeline import plan_inputs

    src = tmp_path / "src"
    (src / "alice").mkdir(parents=True)
    (src / "alice" / "8349000.jpg").write_bytes(b"x")
    (src / "alice" / "8349001.jpg").write_bytes(b"x")
    p = _parquet(tmp_path / "all.parquet", {8349000: ["from_table", "other"]})

    plan = plan_inputs(src, assign_ids=False, layout="flat",
                       artist_rule=ArtistRule(enabled=True),
                       artist_table=ArtistTable(str(p)))
    rows = {Path(it.rel).name: it for it in plan.items}
    assert rows["8349000.jpg"].artist == "from_table"
    assert rows["8349000.jpg"].artist_source == "table"
    assert rows["8349000.jpg"].artists == ("from_table", "other")
    # 表里没有 → 退回目录名，并明确标记成 path（不冒充分片口径）
    assert rows["8349001.jpg"].artist == "alice"
    assert rows["8349001.jpg"].artist_source == "path"


def test_任务表单的画师表优先生效(tmp_path):
    """表单填了表就用它，不填才回落配置——否则换数据集还得改 yaml，
    而改 yaml 会把上一个任务的口径一起改掉。"""
    from tagger.web.jobs import JobSpec, _artist_context

    p = _parquet(tmp_path / "all.parquet", {8349000: ["a"]})
    rule, _ = _artist_context(JobSpec(input_dir="", artist_table=str(p)))
    assert rule.table == str(p)
    assert rule.enabled is True


def test_默认开着画师():
    """默认关掉的话，别人拿到产物才发现没有 @name，只能整批重打。"""
    assert ArtistRule().enabled is True
    assert ArtistRule.from_dict({}).enabled is True
    assert ArtistRule.from_dict({"enabled": False}).enabled is False


def test_tag串最前面也写画师(tmp_path):
    """训练侧读的是 .tag 文本：只写进 caption、不写进 tag 串，等于没绑上。"""
    p = _parquet(tmp_path / "all.parquet", {8349000: ["ban_syou"]})
    c = _client(artist_rule=ArtistRule(table=str(p)))
    payload = c._tag_payload(_task(), [("1girl", 1.0), ("solo", 0.9)], 0.2, 30, 1)
    assert payload["tag"].startswith("@ban_syou, 1girl, solo")
    assert payload["tags"][0] == ["@ban_syou", 1.0]
    assert payload["artist"] == "ban_syou"


def test_NL与TAG两个开关各自独立(tmp_path):
    """NL 与 TAG 是两条训练输入：有人只要 NL 带画师，有人只要 tag 带。"""
    p = _parquet(tmp_path / "all.parquet", {8349000: ["ban_syou"]})
    only_nl = _client(artist_rule=ArtistRule(table=str(p), inject_caption=True,
                                             inject_tags=False))
    payload = only_nl._tag_payload(_task(), [("1girl", 1.0)], 0.2, 30, 1)
    assert payload["tag"] == "1girl"
    assert payload["tags"] == [["1girl", 1.0]]
    assert payload["artist_tag"] == "@ban_syou"      # 字段还在，只是不进文本

    only_tag = _client(artist_rule=ArtistRule(table=str(p), inject_caption=False,
                                              inject_tags=True))
    assert only_tag._tag_payload(_task(), [("1girl", 1.0)], 0.2, 30, 1)["tag"] \
        == "@ban_syou, 1girl"
    assert only_tag.artist_rule.inject_caption is False


def test_两个开关默认都开():
    rule = ArtistRule.from_dict({})
    assert rule.inject_caption is True and rule.inject_tags is True
    assert ArtistRule.from_dict({"inject_tags": False}).inject_tags is False


# ---------------------------------------------------------------- prompt v4

def test_参考tag段只在有tag时出现():
    assert _ref_block(()) == ""
    assert _ref_block(["", "  "]) == ""
    en = _ref_block(["1girl", "blue_hair"])
    assert "<REFERENCE>" in en and "1girl, blue_hair" in en
    zh = _ref_block(["1girl"], zh=True)
    assert "<参考>" in zh


def test_有tag的图才会带参考段(tmp_path):
    c = _client()
    plain = c._prompt_for_task(_task())
    rich = c._prompt_for_task(TaskRow(shard="s", image_id="8349000",
                                      file="x.jpg", ref_tags=("1girl", "solo")))
    assert "<REFERENCE>" not in plain
    assert "<REFERENCE>" in rich and "1girl, solo" in rich
    # 同一张图重试必须拿到同一段（否则等于换题）
    assert rich == c._prompt_for_task(
        TaskRow(shard="s", image_id="8349000", file="x.jpg",
                ref_tags=("1girl", "solo")))


def test_从行里取tag的几种写法():
    assert _ref_tags_of({"tags": "1girl, solo"}) == ("1girl", "solo")
    assert _ref_tags_of({"tags_original": "1girl solo"}) == ("1girl", "solo")
    assert _ref_tags_of({"ref_tags": ["a", "b"]}) == ("a", "b")
    assert _ref_tags_of({}) == ()


def test_prompt_v4_要求风格与引文原样():
    # 文字条款现在从 prompts/图中文字规则.md 读，要显式开 text_rules。
    en = _prompt_for(OutputSpec(mode="nl", text_rules="图中文字规则"))
    assert "art style and medium" in en
    assert "never translate" in en and "never romanise" in en
    zh = _prompt_for(OutputSpec(mode="nl", text_rules="图中文字规则"), zh=True)
    assert "整体画风" in zh
    assert "不要翻译" in zh


def test_不开text_rules就没有文字条款():
    """tag/caption 规则是强制的，图中文字条款不是：它由配置开关决定。"""
    en = _prompt_for(OutputSpec(mode="nl"))
    assert "art style and medium" in en          # caption 规则仍在
    assert "never translate" not in en


# ---------------------------------------------------------------- 语言判定

def test_英文里引用中文招牌不算中文():
    """规范 v0.2 §6 要求引文保持原语言；若把它算进语言比例，
    这条正确的产出会被判成中文，进而跳过 tag 覆盖率、按 0.45 缩字符线。"""
    en = 'A red lantern hangs above the door; the sign reads "福" in gold paint.'
    assert not is_cjk_text(en)
    assert is_cjk_text("门口挂着一盏红灯笼，招牌上写着「福」字，字是金漆的。")


def test_双语引文也不影响判定():
    en = 'The poster reads 「禁止入内」 and the note says "keep out".'
    assert not is_cjk_text(en)


@pytest.mark.parametrize("ratio,expect", [(0.0, False), (1.0, True)])
def test_中文比例开关决定用哪份指令(ratio, expect):
    c = _client(prompt_zh_text="中文版", caption_zh_ratio=ratio)
    got = c._prompt_for_task(_task())
    assert (got == "中文版") is expect
