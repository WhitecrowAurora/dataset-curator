"""分段计时（--stats-json 的数据来源）。

这套数字的唯一用途是回答"该优化哪一段"。所以测试要保证的是：
每个阶段真的被记到、次数对得上、没有哪段被悄悄漏掉。
"""

from __future__ import annotations

import time

from tagger.artist import ArtistRule
from tagger.client import StageTimer, TaggerClient, TaskRow
from tagger.config import OutputSpec
from tagger.quality import QualityGate, QualityPolicy


def test_stage_timer_accumulates_and_averages():
    timer = StageTimer()
    timer.add("http", 0.10)
    timer.add("http", 0.30)
    snap = timer.snapshot()
    assert snap["http"]["count"] == 2
    assert snap["http"]["total_ms"] == 400.0
    assert snap["http"]["avg_ms"] == 200.0


def test_stage_timer_track_context():
    timer = StageTimer()
    with timer.track("gate"):
        time.sleep(0.01)
    snap = timer.snapshot()
    assert snap["gate"]["count"] == 1
    assert snap["gate"]["avg_ms"] >= 5


def _client() -> TaggerClient:
    return TaggerClient(
        base_url="http://127.0.0.1:9",          # 不会真的连：_infer 被替换掉了
        model_name="bench",
        output=OutputSpec(mode="both", tag_min_count=1, tag_max_count=10),
        temperature=0.2, top_p=0.9, max_tokens=64, timeout_s=5,
        max_attempts=1,
        gate=QualityGate(QualityPolicy(min_chars=5, max_chars=5000,
                                       min_tag_coverage=0.0,
                                       nl_min_tokens=0, nl_max_tokens=1000),
                         verbose=False),
        prov_base={"model_id": "bench"},
        artist_rule=ArtistRule(),
        stage=StageTimer(),
    )


def test_process_records_each_stage():
    client = _client()
    try:
        # _infer 的返回是 (文本, 输入 token, 输出 token)：输入 token 也要记账，
        # 否则 API 模式的成本只能算到输出那一半。
        # 第三个参数是这张图专用的指令（中文条目带中文那份），替身要照抄完整签名
        client._infer = lambda part, temp, prompt=None: (   # type: ignore[method-assign]
            "<TAGS>red, blue</TAGS>"
            "<CAPTION>a red square and a blue circle</CAPTION>", 0, 7)

        task = TaskRow(shard="x.zip", image_id="a-000001", file="a-000001.png")
        outcome = client.process(task, data=b"\x89PNG-not-really")

        assert outcome.ok
        snap = client.stage.snapshot()
        # 图片数据是调用方给的，所以不该有 read（读盘）这一段
        assert "read" not in snap
        assert snap["b64"]["count"] == 1
        assert snap["http"]["count"] == 1
        assert snap["parse"]["count"] == 1
        assert snap["gate"]["count"] == 1
        for row in snap.values():
            assert row["total_ms"] >= 0
    finally:
        client.close()


def test_process_counts_retries_in_http_stage():
    """重试时 http 的次数会大于图片数——这是对的，看 count 就知道重试了几次。"""
    client = _client()
    try:
        calls = {"n": 0}

        def fake_infer(part, temp, prompt=None):
            calls["n"] += 1
            # 第一次不给 tag，触发"tag 过少/没有产出"的重试
            if calls["n"] == 1:
                # 只有 caption 没有 tag：want_tag 时不合法，应触发重试
                return "<CAPTION>a red square and a blue circle</CAPTION>", 0, 3
            return ("<TAGS>red, blue</TAGS>"
                    "<CAPTION>a red square and a blue circle</CAPTION>", 0, 3)

        client._infer = fake_infer      # type: ignore[method-assign]
        client.max_attempts = 3

        task = TaskRow(shard="x.zip", image_id="a-000002", file="a-000002.png")
        outcome = client.process(task, data=b"\x89PNG-not-really")

        assert outcome.ok
        snap = client.stage.snapshot()
        assert snap["http"]["count"] == 2
        assert snap["gate"]["count"] == 1
    finally:
        client.close()
