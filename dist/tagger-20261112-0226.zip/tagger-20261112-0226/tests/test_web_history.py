"""任务历史落盘 + 新建任务页的参数记忆。

要钉住的三件事：
1. 跑完的任务会写进 `run/history/`，重启后列表还在（带 historical 标记）；
2. 重启前还在 running 的记录，读回来必须变 stopped —— 否则它会一直占着
   "已有任务在跑"的位子，新建任务永远 409；
3. 表单记忆不落凭据，也不收不认识的字段。
"""

from __future__ import annotations

import json
import threading
import time

import pytest
from fastapi.testclient import TestClient

from tagger.cpu_tagger import TagPrediction
from tagger.web import history as history_mod
from tagger.web import jobs as jobs_mod
from tagger.web.app import create_app


class _FakeBackend:
    name = "fake"
    precision = "bf16"
    batch_size = 1

    def __init__(self, delay=0.0):
        self.delay = delay
        self.last_timings = {"total": 5, "decode": 2, "forward": 2}
        self.calls = 0

    def load(self):
        return None

    def predict_batch(self, images):
        self.calls += 1
        if self.delay:
            time.sleep(self.delay)
        return [TagPrediction(tags=[("red", 0.9)], backend="fake",
                              rating={"general": 0.6}) for _ in images]


@pytest.fixture
def client(monkeypatch, tmp_path):
    jobs_mod.MANAGER._jobs.clear()
    monkeypatch.setattr(jobs_mod, "build_backend",
                        lambda *a, **kw: _FakeBackend(delay=0.02))
    monkeypatch.setattr(jobs_mod, "resolve_device", lambda s: "cpu")
    monkeypatch.setattr(jobs_mod.JobManager, "_make_guard",
                        lambda self, job: None)
    with TestClient(create_app(ui_dist=tmp_path / "no-ui")) as test_client:
        try:
            yield test_client
        finally:
            jobs = list(jobs_mod.MANAGER._jobs.values())
            for job in jobs:
                job.stop_flag.set()
                job.pause_flag.clear()
            names = {f"tag-job-{job.id}" for job in jobs}
            for thread in threading.enumerate():
                if thread.name in names:
                    thread.join(timeout=15)


def _images(tmp_path, n=3):
    src = tmp_path / "in"
    src.mkdir()
    for i in range(n):
        (src / f"{i}.png").write_bytes(b"\x89PNG\r\n\x1a\n")
    return src


def _wait(client, job_id, timeout=8.0):
    deadline = time.time() + timeout
    snap: dict = {}
    while time.time() < deadline:
        snap = client.get(f"/api/jobs/{job_id}").json()
        if snap["status"] in ("done", "failed", "stopped"):
            return snap
        time.sleep(0.05)
    raise AssertionError(f"任务没在 {timeout}s 内结束：{snap}")


def _run_one(client, tmp_path, n=3) -> str:
    src = _images(tmp_path, n)
    created = client.post("/api/jobs", json={"input_dir": str(src),
                                             "out_dir": str(tmp_path / "out")})
    assert created.status_code == 202, created.text
    job_id = created.json()["id"]
    assert _wait(client, job_id)["status"] == "done"
    return job_id


# --------------------------------------------------------------- 历史落盘

def test_finished_job_is_written_to_disk(client, tmp_path):
    job_id = _run_one(client, tmp_path)
    p = history_mod.HISTORY_DIR / f"{job_id}.json"
    assert p.is_file(), f"历史没落盘：{p}"
    saved = json.loads(p.read_text(encoding="utf-8"))
    assert saved["status"] == "done"
    assert saved["counts"]["done"] == 3


def test_history_survives_restart(client, tmp_path):
    job_id = _run_one(client, tmp_path)
    # 新实例 = 进程重启：内存表是空的，只能从盘上读回来
    fresh = jobs_mod.JobManager()
    snaps = {s["id"]: s for s in fresh.all_snapshots()}
    assert job_id in snaps, "重启后历史列表里没有这条任务"
    assert snaps[job_id]["historical"] is True
    # 活任务不带这个标记（页面据此决定「进度/结果」能不能点）
    assert all("historical" not in s or not s["historical"]
               for s in jobs_mod.MANAGER.all_snapshots())


def test_interrupted_record_revives_as_stopped(tmp_path):
    """重启前写的是 running，读回来必须是 stopped 并说明原因。"""
    history_mod.HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    (history_mod.HISTORY_DIR / "old1.json").write_text(json.dumps({
        "id": "old1", "status": "running", "created": 1.0, "spec": {}, "counts": {},
    }), encoding="utf-8")

    items = history_mod.load_all()
    assert items[0]["status"] == "stopped"
    assert "进程已退出" in items[0]["error"]
    # 改写要回盘，否则每次启动都得再改一遍
    again = json.loads((history_mod.HISTORY_DIR / "old1.json").read_text(encoding="utf-8"))
    assert again["status"] == "stopped"


def test_historical_job_can_be_restarted(client, tmp_path):
    """内存里没有 Job 对象时，「继续」要能按历史里的参数重开一个。"""
    job_id = _run_one(client, tmp_path)
    jobs_mod.MANAGER._jobs.clear()          # 模拟进程重启：只剩盘上的记录

    job = jobs_mod.MANAGER.restart(job_id)
    assert job.id != job_id
    assert job.spec.input_dir.endswith("in")
    jobs_mod.MANAGER.stop(job.id)


def test_bad_history_file_is_skipped(tmp_path):
    """一条坏记录不该让整个列表消失。"""
    history_mod.HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    (history_mod.HISTORY_DIR / "broken.json").write_text("{ not json", encoding="utf-8")
    (history_mod.HISTORY_DIR / "ok.json").write_text(json.dumps({
        "id": "ok", "status": "done", "created": 2.0, "spec": {}, "counts": {},
    }), encoding="utf-8")
    ids = [h["id"] for h in history_mod.load_all()]
    assert ids == ["ok"]


# --------------------------------------------------------------- 表单记忆

def test_job_form_roundtrip_drops_secrets_and_unknowns(client):
    r = client.post("/api/job-form", json={"spec": {
        "batch": 8,
        "temperature": 0.5,
        "api_key": "sk-should-not-land",
        "hf_token": "hf-should-not-land",
        "这不是字段": 1,
    }})
    assert r.status_code == 200

    saved = client.get("/api/job-form").json()["spec"]
    assert saved["batch"] == 8
    assert saved["temperature"] == 0.5
    assert "api_key" not in saved and "hf_token" not in saved
    assert "这不是字段" not in saved


def test_job_form_keeps_form_snapshot(client):
    """填一项存一项走的是 form：键名是页面 state，凭据同样不落盘。"""
    r = client.post("/api/job-form", json={"form": {
        "batch": 4,
        "temperature": 0.7,
        "seed": "123",
        "hfFiles": ["a.parquet", "b.parquet"],
        "catThresholds": {"general": "0.42"},
        "guardPolicy": {"max_vram_gb": 14},
        "hfProxy": "",
        "apiKey": "sk-should-not-land",
        "hfToken": "hf-should-not-land",
    }})
    assert r.status_code == 200

    form = client.get("/api/job-form").json()["form"]
    assert form["batch"] == 4
    assert form["temperature"] == 0.7
    assert form["seed"] == "123"
    assert form["hfFiles"] == ["a.parquet", "b.parquet"]
    # 字符串字典（类别阈值）和数字字典（硬件保护）都得留住
    assert form["catThresholds"] == {"general": "0.42"}
    assert form["guardPolicy"] == {"max_vram_gb": 14}
    assert "hfProxy" in form
    assert "apiKey" not in form and "hfToken" not in form


def test_job_form_halves_do_not_clobber_each_other(client):
    """填一项只写 form，提交只写 spec —— 两份互不覆盖。"""
    client.post("/api/job-form", json={"spec": {"batch": 8}})
    client.post("/api/job-form", json={"form": {"batch": 2}})
    got = client.get("/api/job-form").json()
    assert got["spec"]["batch"] == 8      # 提交那份还在
    assert got["form"]["batch"] == 2      # 逐项那份是新的


def test_job_form_rejects_non_object(client):
    r = client.post("/api/job-form", json={"spec": [1, 2, 3]})
    assert r.status_code == 400
    r = client.post("/api/job-form", json={"form": "nope"})
    assert r.status_code == 400
    r = client.post("/api/job-form", json={})
    assert r.status_code == 400


def test_job_form_missing_file_is_empty(client):
    """没记过 = 两份空对象，页面照默认值开，不是报错。"""
    got = client.get("/api/job-form").json()
    assert got["form"] == {} and got["spec"] == {}
