"""依赖检测：清单解析与状态判定的稳定断言。

刻意不假设"这台机器装了什么"：开发机、CI、全新装机三种环境下，能装的包
完全不同。这里只断言清单本身与判定逻辑，跑在哪儿都一样。
"""

from __future__ import annotations

from tagger.web.deps import DepManager, Item, describe, installed_version, load_items


def test_清单能读出来且不重名():
    items = load_items()
    assert items, "两份 requirements 至少要读出一批包"
    names = [i.name.lower().replace("_", "-") for i in items]
    assert len(names) == len(set(names)), "同一个包不该在页面上出现两行"


def test_清单包含运行环境必需的包():
    """fastapi / uvicorn 缺了服务根本起不来，它们必须在清单里。"""
    names = {i.name.lower() for i in load_items()}
    for must in ("fastapi", "uvicorn", "httpx", "websockets"):
        assert must in names


def test_分组只有三种():
    groups = {i.group for i in load_items()}
    assert groups <= {"core", "tag", "optional"}
    assert "core" in groups


def test_没装的包判为缺失():
    row = describe(Item(name="definitely-not-installed-xyz", spec="definitely-not-installed-xyz",
                        group="optional"))
    assert row["status"] == "missing"
    assert row["installed"] is None


def test_装了且版本符合的判为通过():
    # pytest 一定装着——这个测试文件正在被它跑。
    row = describe(Item(name="pytest", spec="pytest", group="core"))
    assert row["status"] == "ok"
    assert row["installed"] == installed_version("pytest")


def test_版本要求写死一个不可能的值时判为不符():
    row = describe(Item(name="pytest", spec="pytest==0.0.1", group="core"))
    assert row["status"] == "mismatch"


def test_导入名映射不会把_PIL_认错():
    """清单写的是 Pillow，import 用的是 PIL。少了映射表，装好的包会被报成缺失。"""
    item = Item(name="Pillow", spec="Pillow", group="core")
    assert item.module == "PIL"


def test_快照带着批量与检查字段():
    """页面靠这几个字段画批量进度和"导入失败"标记，缺了会静默画不出来。"""
    snap = DepManager().snapshot()
    assert "verify_at" in snap
    assert snap["summary"]["broken"] == 0       # 没检查过就该是 0，不是 None
    rows = [r for g in snap["groups"] for r in g["items"]]
    assert rows and all("verified" in r for r in rows)


def test_一次只允许一个动作在跑():
    mgr = DepManager()
    mgr.status = "running"                      # 假装有一个在跑
    try:
        mgr._start_many("verify", [Item(name="pytest", spec="pytest", group="core")])
    except RuntimeError:
        return
    raise AssertionError("并发动作应当被拒绝")


def test_重依赖不跟着批量装():
    """vllm 一次会拖进 80+ 个包并改写 numpy/starlette，绝不能混在
    「安装缺失」里——用户按那个按钮时以为只是补几个小包。"""
    mgr = DepManager()
    heavy = Item(name="vllm", spec="vllm", group="optional", heavy=True)
    snap = mgr._start_many("install-missing", [heavy])
    assert snap["job"]["batch"][0]["status"] == "skipped"
    assert "单独" in snap["job"]["batch"][0]["detail"]


def test_全是重依赖时批量直接拒绝():
    import tagger.web.deps as deps_mod

    original = deps_mod.load_items
    deps_mod.load_items = lambda: [
        Item(name="vllm", spec="vllm", group="optional", heavy=True)
    ]
    try:
        DepManager().install_missing()
    except ValueError as exc:
        assert "单独" in str(exc)
        return
    finally:
        deps_mod.load_items = original
    raise AssertionError("只有重依赖时不该开批")


def test_导入名和分发名不一样的包_不能报成缺失():
    """open_clip_torch 的真实模块叫 open_clip。少了这条映射，装好的包会
    一直红着，用户只会去反复重装——而它本来就是好的。"""
    assert Item("open_clip_torch", "open_clip_torch", "tag").module == "open_clip"
    assert Item("Pillow", "Pillow", "core").module == "PIL"
    assert Item("pyyaml", "pyyaml", "core").module == "yaml"


def test_模块内部炸了不要换个名字当没事(monkeypatch):
    """torch 的 _C 崩了、torchgen 却好好的——只因为后者能 import 就判"通过"，
    等于把真故障藏起来。换名字只对"这个名字压根不存在"才有意义。"""
    import tagger.web.deps as deps_mod

    monkeypatch.setattr(deps_mod.Item, "modules", property(lambda self: ["a", "b"]))
    mgr = deps_mod.DepManager()
    tried: list[str] = []

    def fake(module: str) -> tuple[bool, str]:
        tried.append(module)
        if module == "a":
            return False, "ImportError: DLL load failed while importing _C"
        return True, "0.1s"

    monkeypatch.setattr(mgr, "_try_import", fake)
    ok, _ = mgr._verify_one(deps_mod.Item("a", "a", "tag"))
    assert not ok
    assert tried == ["a"], "内部错误不该再去试别的模块名"


def test_能分辨是不是自带的_env():
    from tagger.web.deps import _python_kind

    assert _python_kind() in ("bundled", "external", "unknown")


def test_非法包名被拒绝():
    mgr = DepManager()
    try:
        mgr._find("bad name; rm -rf /")
    except ValueError:
        return
    raise AssertionError("带空格的包名应当被拒绝")
