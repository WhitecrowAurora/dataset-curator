"""本地量化成 GGUF：原始权重 → F16 → Q4_K_M / Q6_K。

这条路最容易出的错不是崩溃，而是**静默跑错档**：产物登记到错误的键上、
或者默认 gguf 没被顶掉，页面选 Q6 却还在用旧的 Q4。所以这几条钉的是
"登记结果"，而不是"命令拼得对不对"（命令由官方脚本决定）。
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from tagger import config as config_mod
from tagger import gguf_convert as gc


@pytest.fixture()
def overlay(tmp_path, monkeypatch):
    path = tmp_path / "models.json"
    monkeypatch.setattr(config_mod, "MODEL_OVERLAY", str(path))
    return path


def _task(tmp_path, key="qwen3vl-8b", target="q6_k"):
    src = tmp_path / "weights"
    src.mkdir(exist_ok=True)
    f16, mmproj, out = gc.default_outputs(src, key, target)
    return gc.ConvertTask(model_key=key, target=target, src=src,
                          f16=f16, mmproj=mmproj, out=out)


# ------------------------------------------------------------------ 识别
def test_vision_detection(tmp_path):
    """带不带视觉塔决定要不要跑第二趟 --mmproj；猜错的代价是白跑几分钟。"""
    cfg = tmp_path / "config.json"

    cfg.write_text(json.dumps({"vision_config": {"depth": 27}}), encoding="utf-8")
    assert gc.is_vision(tmp_path)

    cfg.write_text(json.dumps(
        {"architectures": ["Qwen3VLForConditionalGeneration"]}), encoding="utf-8")
    assert gc.is_vision(tmp_path)

    cfg.write_text(json.dumps({"architectures": ["Qwen2ForCausalLM"]}), encoding="utf-8")
    assert not gc.is_vision(tmp_path)
    # 没有 config.json（下了一半）不该当成视觉模型
    cfg.unlink()
    assert not gc.is_vision(tmp_path)


def test_output_names_match_the_script(tmp_path):
    """`--mmproj` 只加前缀，文件名对不上就会在目录里凭空多出一份。"""
    f16, mmproj, out = gc.default_outputs(tmp_path, "qwen3vl-8b", "q6_k")
    assert f16.name == "qwen3vl-8b-F16.gguf"
    assert mmproj.name == "mmproj-qwen3vl-8b-F16.gguf"
    assert out.name == "qwen3vl-8b-Q6_K.gguf"


# ------------------------------------------------------------------ 输入
def test_source_dir_ignores_hf_repo_id(tmp_path, monkeypatch, overlay):
    """path 是仓库名时不能拼成 H:\\tagger\\Qwen\\... 这种假路径。

    报错里列出假位置，用户会以为是自己配错了路径。
    """
    monkeypatch.setattr(gc, "MODELS_ROOT", tmp_path / "models")
    with pytest.raises(Exception) as err:
        gc.source_dir("qwen3vl-8b")
    assert "R:\\" not in str(err.value) and "tagger\\Qwen" not in str(err.value)


def test_source_dir_accepts_downloaded_repo(tmp_path, monkeypatch, overlay):
    """下完原始权重（config.json + safetensors）就该认得出来。"""
    from tagger.web import downloads as dl

    root = tmp_path / "models"
    monkeypatch.setattr(gc, "MODELS_ROOT", root)
    monkeypatch.setattr(dl, "MODELS_ROOT", root)
    dest = dl.resolve_dir("vlm", "qwen3vl-8b", None)
    dest.mkdir(parents=True)
    (dest / "config.json").write_text("{}", encoding="utf-8")
    (dest / "model-00001-of-00002.safetensors").write_bytes(b"x" * 16)

    assert gc.source_dir("qwen3vl-8b") == dest
    assert gc._safetensors_bytes(dest) == 16


# ------------------------------------------------------------------ 登记
def test_register_writes_tier_and_default(tmp_path, overlay, monkeypatch):
    """产物要登记到 q6 这一档；默认那档缺文件时也要顶上去。"""
    # ROOT 指到临时目录：登记时会把路径写成"相对仓库根"，这里的文件才在
    # 仓库根下面，得到的正是线上那种相对写法。
    monkeypatch.setattr(gc, "ROOT", tmp_path)
    task = _task(tmp_path)
    task.out.write_bytes(b"x" * 8)
    gc.CONVERTER._register(task)

    doc = json.loads(overlay.read_text(encoding="utf-8"))
    entry = doc["vlm"]["qwen3vl-8b"]
    assert entry["gguf_quants"]["q6"].endswith("qwen3vl-8b-Q6_K.gguf")
    # 原有的 q4 映射不能被这次登记抹掉（覆盖是整条替换）
    assert {"q4", "q6"} <= set(entry["gguf_quants"])
    # 相对路径：同一份 models.json 在 Windows 与 WSL 下都要能解析
    assert not Path(entry["gguf_quants"]["q6"]).is_absolute()


def test_register_keeps_existing_default_gguf(tmp_path, overlay, monkeypatch):
    """已经有一份能用的默认档，就不该被新压出来的 Q6 抢走默认位。"""
    monkeypatch.setattr(gc, "ROOT", tmp_path)
    task = _task(tmp_path)
    task.out.write_bytes(b"x" * 8)
    overlay.write_text(json.dumps({
        "vlm": {"qwen3vl-8b": {"gguf": ""}}
    }), encoding="utf-8")
    gc.CONVERTER._register(task)

    doc = json.loads(overlay.read_text(encoding="utf-8"))
    entry = doc["vlm"]["qwen3vl-8b"]
    # 配置里的 gguf 指向的文件不存在 → 允许新的顶上去
    assert entry["gguf"].endswith("qwen3vl-8b-Q6_K.gguf")

    # 再跑一次，此时默认档已经存在且可读 → 保持不变
    task2 = _task(tmp_path, target="q4_k_m")
    task2.out.write_bytes(b"x" * 8)
    gc.CONVERTER._register(task2)
    doc = json.loads(overlay.read_text(encoding="utf-8"))
    assert doc["vlm"]["qwen3vl-8b"]["gguf"].endswith("qwen3vl-8b-Q6_K.gguf")


# ------------------------------------------------------------------ 接口
@pytest.fixture()
def client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    monkeypatch.setattr(config_mod, "MODEL_OVERLAY", str(tmp_path / "models.json"))
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def test_api_reports_targets_and_source(client):
    """三档：F16 是"只转不压"的完整权重，Q4/Q6 是压缩档。

    少报 F16 的话，页面上就压不出一份未压缩的 GGUF —— 而它正是
    tiers.yaml 的默认档（8B 约 15.6 G）。
    """
    data = client.get("/api/gguf?model=qwen3vl-8b").json()
    assert [t["key"] for t in data["targets"]] == ["f16", "q4_k_m", "q6_k"]
    # 原始权重没下时给 hint，页面据此把"去下原始权重"摆出来
    assert data["source"]["ready"] is False
    assert "原始权重" in data["source"]["hint"]


def test_api_rejects_unknown_model_and_target(client):
    r = client.post("/api/gguf/convert", json={"model": "nope", "target": "q6_k"})
    assert r.status_code == 400
    assert "清单里没有" in r.json()["detail"]

    r = client.post("/api/gguf/convert",
                    json={"model": "qwen3vl-8b", "target": "q5_k"})
    assert r.status_code == 400
    assert "暂不支持" in r.json()["detail"]


def test_convert_shows_up_in_activities(client, monkeypatch):
    """转换要十几分钟，切走以后底栏必须还看得见它在跑。"""

    class Fake:
        def start(self, key, target):
            return {"status": "running"}

        def state(self):
            return {"status": "running"}

        def activity(self):
            return {"id": "convert:x:q6_k", "kind": "convert", "title": "本地量化",
                    "detail": "x → Q6_K", "status": "running", "percent": 42.0,
                    "stage": "量化", "message": "", "elapsed_s": 12.0,
                    "finished_at": 0.0, "log_tail": []}

        def cancel(self):
            return {}

    from tagger.web import app as app_mod

    monkeypatch.setattr(app_mod, "GGUF_CONVERT", Fake())
    items = client.get("/api/activities").json()["items"]
    conv = [i for i in items if i["kind"] == "convert"]
    assert conv and conv[0]["done"] == 42 and conv[0]["href"] == "/models"


def test_convert_extra_is_installable_from_the_page():
    """页面上的「一键安装」走 extra 名，必须真的在 pyproject 里声明过。"""
    from tagger.web import deps as deps_mod

    extras = deps_mod.load_extras()
    assert "convert" in extras, f"pyproject 里没有 convert extra：{sorted(extras)}"
    modules = {item.module for item in extras["convert"]}
    # sentencepiece 曾经漏在这里：点开始 → 等几分钟 → tokenizer 那步才炸
    assert {"torch", "transformers", "sentencepiece"} <= modules
    # 说明文案：没有它，安装列表里这一组会显示成空白
    assert deps_mod.EXTRA_NOTES.get("convert")


def test_raw_download_uses_the_transformers_repo(client, monkeypatch):
    """「原始权重」必须回 transformers 仓库取。

    破限版的 download_repo 指向 mradermacher 的 GGUF 仓库——那里一个
    safetensors 都没有。照它下 17G，本地量化仍然找不到输入。
    """
    from tagger.web import downloads as dl_mod

    captured: dict = {}

    def fake_start(kind, key, repo, dest, proxy="", allow=None):
        captured.update(repo=repo, allow=allow)
        return {"ok": True}

    monkeypatch.setattr(dl_mod.DOWNLOADS, "start", fake_start)
    r = client.post("/api/models/download",
                    json={"kind": "vlm", "key": "qwen3vl-4b-abliterated",
                          "precision": "raw"})
    assert r.status_code == 200, r.text
    assert captured["repo"] == "prithivMLmods/Qwen3-VL-4B-Instruct-Unredacted-MAX"
    # None = 整仓库，不再按文件白名单筛
    assert captured["allow"] is None


def test_source_download_falls_back_to_mirror(tmp_path, monkeypatch):
    """GitHub 直连慢就换反代，别让人对着"卡在 8/37 MB"干等。

    国内实测：github.com 直连 30 KB/s（37 MB 要二十分钟），gh-proxy 1.4 MB/s。
    所以"太慢就换路"是功能，不是优化。
    """
    tried: list[str] = []

    def fake(url, archive, say, proxy):
        host = url.split("/")[2]
        tried.append(host)
        if host == "github.com":
            raise TimeoutError("太慢：15s 只下了 1.0 MB")
        archive.write_bytes(b"ok")

    monkeypatch.setattr(gc, "_stream_source", fake)
    archive = tmp_path / "src.tar.gz"
    gc._download_source(archive, "v0.9.0", lambda _m: None, "")

    assert tried[0] == "github.com" and len(tried) == 2
    assert archive.read_bytes() == b"ok"


def test_source_download_reports_actionable_error(tmp_path, monkeypatch):
    """几条路全挂时要写"接下来做什么"（填代理 / 手动解压），别只抛状态码。"""
    def fake(url, archive, say, proxy):
        raise TimeoutError("太慢")

    monkeypatch.setattr(gc, "_stream_source", fake)
    with pytest.raises(config_mod.ConfigError) as exc:
        gc._download_source(tmp_path / "src.tar.gz", "v0.9.0", lambda _m: None, "")
    assert "代理" in str(exc.value)


# ------------------------------------------------------------------ 内置脚本
def test_missing_dependency_is_named():
    """缺哪个包要点名 + 给装法：官方脚本是跑到 tokenizer 那步才 import 的，
    那时候用户已经等了几分钟，一句"退出码 1"不够用。"""
    tail = ["Traceback (most recent call last):",
            "ModuleNotFoundError: No module named 'sentencepiece'"]
    assert gc._missing_module(tail) == "sentencepiece"
    assert gc._missing_module(["convert_hf_to_gguf.py: boom"]) == ""


def test_capability_blocks_before_a_long_run(monkeypatch):
    """缺包要在点按钮之前就说清（sentencepiece 就是漏过这一关的那个）。"""
    monkeypatch.setattr(gc, "_REQUIRED", ("definitely_not_installed_xyz",))
    ok, reason = gc.capability()
    assert not ok
    assert "definitely_not_installed_xyz" in reason and "convert" in reason


def test_vendored_convert_script_ships_with_the_repo():
    """`vendor\\llama-convert` 必须齐：它就是 pack-dist 打进包里的那一份。

    缺了不会崩，只会让接收方第一次转换去 GitHub 拉 37MB 源码包——而那一步
    在国内经常卡死在 8/37 MB。所以这里当硬线钉住。
    """
    assert gc._complete(gc.BUNDLED_DIR), f"内置转换脚本不完整：{gc.BUNDLED_DIR}"
    assert gc.tools_dir() == gc.BUNDLED_DIR
    # 版本号跟着内置那份走，别看运行时（两者可能不是同一次装的）
    assert (gc.BUNDLED_DIR / "VERSION").is_file()


def test_tools_dir_falls_back_when_bundle_missing(tmp_path, monkeypatch):
    """内置那份被删了才回落到下载目录，别让路径指向一个不存在的文件夹。"""
    monkeypatch.setattr(gc, "BUNDLED_DIR", tmp_path / "nope")
    monkeypatch.setattr(gc, "TOOLS_DIR", tmp_path / "downloaded")
    assert gc.tools_dir() == tmp_path / "downloaded"
    assert not gc.tools_ready()


def test_mmproj_pass_writes_its_own_file(tmp_path, monkeypatch):
    """★回归：第二趟（视觉塔）的 `--outfile` 必须是 mmproj 自己的路径。

    官方脚本的 `mmproj-` 前缀只在 "--outfile 是个目录" 时才加
    （conversion/base.py::MmprojModel.prepare_metadata）；传文件路径时它只做
    一次 `fill_templated_filename`，文件名原样返回 —— 于是第二趟**直接覆盖
    第一趟的 F16**。实测后果：15.6G 的 F16 被 1.1G 的 mmproj 顶掉，量化把
    mmproj 当文本模型压，产出 0.47G 的残废 Q6，而 mmproj-*.gguf 从不存在
    （起服务才报"视觉投影文件不存在"）。
    """
    src = tmp_path / "weights"
    src.mkdir()
    (src / "config.json").write_text('{"vision_config": {"depth": 27}}', encoding="utf-8")
    (src / "model.safetensors").write_bytes(b"x" * 64)

    task = gc.ConvertTask(model_key="k", target="q6_k", src=src,
                          f16=src / "k-F16.gguf", mmproj=src / "mmproj-k-F16.gguf",
                          out=src / "k-Q6_K.gguf")
    seen: list[tuple[tuple[str, ...], str]] = []

    def fake_run(_self, _task, extra, out, *_a, **_kw):
        seen.append((tuple(extra), Path(out).name))
        Path(out).write_bytes(b"x")                 # 假装官方脚本写了这个文件

    monkeypatch.setattr(gc.Converter, "_run_script", fake_run)
    gc.CONVERTER._convert(task)

    assert seen == [((), "k-F16.gguf"), (("--mmproj",), "mmproj-k-F16.gguf")]


def test_sentencepiece_is_in_the_deps_tab():
    """依赖管理 tab 直接读 `requirements-embedded.txt`（`deps.load_items`）。

    写在那份清单里才有两件事：tab 的「运行环境」多一行、而且「安装缺失」
    会把它一起装掉。只写 pyproject 的 extra 是不够的——extra 不在 tab 里显示。
    """
    from tagger.web import deps as deps_mod

    items = {it.name: it for it in deps_mod.load_items()}
    assert "sentencepiece" in items, sorted(items)
    assert items["sentencepiece"].group == "core"


def test_runner_puts_conversion_on_sys_path(tmp_path):
    """★回归：内嵌 Python 是 isolated 模式，PYTHONPATH 会被整个忽略。

    这里用 `sys.executable`（跑测试的就是那个 embeddable 解释器）加一个空的
    cwd 复现：不经 runner 直接跑脚本，`from conversion import ...` 必然报
    ModuleNotFoundError；经 runner 就该正常。官方脚本第 18 行就是这一句。
    """
    tools = tmp_path / "tools"
    (tools / "conversion").mkdir(parents=True)
    (tools / "conversion" / "__init__.py").write_text(
        "HELLO = 'conversion-ok'\n", encoding="utf-8")
    (tools / "convert_hf_to_gguf.py").write_text(
        "import sys\nfrom conversion import HELLO\nprint(HELLO, *sys.argv[1:])\n",
        encoding="utf-8")

    run = subprocess.run(
        [sys.executable, "-u", str(gc.RUNNER), str(tools), "--outtype", "f16"],
        cwd=tmp_path, capture_output=True, text=True, encoding="utf-8")
    assert run.returncode == 0, run.stderr
    assert "conversion-ok --outtype f16" in run.stdout
