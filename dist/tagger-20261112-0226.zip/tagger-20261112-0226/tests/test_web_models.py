"""模型管理：清单读写 + 覆盖合并。

三条最值得钉的：
1. **覆盖只动两段**（models / tagging.models），分档（tiers）不该被连带改；
2. **只存差异**——配置里原样的条目一条都不写进覆盖文件，否则第一次保存就把
   tiers.yaml 冻结成快照，以后改配置永远不生效；
3. **分档在用的模型不许删**，否则要等到起服务时才炸，报错还指向别处。
"""

from __future__ import annotations

import json
import time

import pytest
from fastapi.testclient import TestClient

from tagger import config as config_mod
from tagger.web.app import create_app


@pytest.fixture()
def client(tmp_path, monkeypatch):
    # 覆盖文件指到临时目录：跑测试绝不能碰仓库里真实的 configs/models.json
    monkeypatch.setattr(config_mod, "MODEL_OVERLAY", str(tmp_path / "models.json"))
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def test_catalog_comes_from_config(client):
    data = client.get("/api/models").json()
    keys = {m["key"] for m in data["vlm"]}
    assert {"qwen3vl-4b", "qwen3vl-8b"} <= keys
    assert {m["key"]: m["source"] for m in data["vlm"]} == {
        m["key"]: "config" for m in data["vlm"]}
    assert data["tag"] and all(t["repo"] for t in data["tag"])
    # 分档在用的模型要标出来：页面据此禁用删除
    # 三档现在都指向同一个 8B 破限版完整权重（默认不量化），档位只决定上下文与并发
    by_key = {m["key"]: m for m in data["vlm"]}
    assert by_key["qwen3vl-8b-abliterated"]["tiers"] == ["low-16g", "mid-24g", "high-32g"]
    assert by_key["qwen3vl-4b-abliterated"]["tiers"] == []
    assert by_key["qwen3vl-8b"]["tiers"] == []
    assert data["overlay_exists"] is False


def test_save_stores_only_diffs(client, tmp_path):
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm.append({
        "key": "my-4b", "path": "local/my-4b", "precision": "int4",
        "family": "qwen3vl", "revision": "", "quantized_path": "", "note": "自测用",
    })
    tag = [dict(t) for t in data["tag"]]
    got = client.put("/api/models", json={"vlm": vlm, "tag": tag}).json()
    assert "my-4b" in {m["key"] for m in got["vlm"]}

    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert list(doc["vlm"]) == ["my-4b"], "配置里原样的条目不该被复制进覆盖文件"
    assert doc["tag"] == {}
    assert doc["hidden"] == [] and doc["tag_hidden"] == []
    assert doc["notes"] == {"vlm:my-4b": "自测用"}

    # 合并后 CLI / 打标 / 起服务走的是同一个入口，都该看见这个模型
    table = config_mod.load_tier_table()
    assert "my-4b" in table["models"]
    # 新建任务页的下拉来自 /api/defaults，必须一起看见
    defaults = client.get("/api/defaults").json()
    assert "my-4b" in {m["key"] for m in defaults["vllm_models"]}
    assert {t["name"] for t in table["tiers"]} >= {"low-16g", "mid-24g", "high-32g"}
    assert config_mod.load_tier_table(overlay=False)["models"].get("my-4b") is None


def test_cannot_remove_model_referenced_by_tier(client):
    data = client.get("/api/models").json()
    vlm = [m for m in data["vlm"] if m["key"] != "qwen3vl-8b-abliterated"]
    r = client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    assert r.status_code == 400
    assert "不能删" in r.json()["detail"]


def test_tag_models_round_trip_and_hide(client, tmp_path):
    data = client.get("/api/models").json()
    tag = [dict(t) for t in data["tag"]]
    tag.append({"backend": "onnx", "repo": "local/onnx-tagger", "note": ""})
    tag = [t for t in tag if t["backend"] != "cl-tagger-v2"]      # 顺手藏掉一个
    client.put("/api/models", json={"vlm": data["vlm"], "tag": tag})

    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["tag"] == {"onnx": "local/onnx-tagger"}
    assert doc["tag_hidden"] == ["cl-tagger-v2"]

    got = client.get("/api/models").json()
    assert {t["backend"] for t in got["tag"]} == {"pixai", "wd-eva02", "onnx"}
    assert {t["backend"]: t["source"] for t in got["tag"]}["onnx"] == "managed"


def test_must_keep_at_least_one_nl_model(client):
    data = client.get("/api/models").json()
    r = client.put("/api/models", json={"vlm": [], "tag": data["tag"]})
    assert r.status_code == 400
    assert "至少保留一个" in r.json()["detail"]


def test_bad_vlm_entry_is_rejected(client):
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm.append({"key": "novalue", "path": ""})
    r = client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    assert r.status_code == 400
    assert "缺少权重路径" in r.json()["detail"]


# ---- 权重下载 / 删除 / 开目录


@pytest.fixture()
def dl_root(tmp_path, monkeypatch):
    """把"模型根目录"指到临时目录：真删真下都不会碰仓库里的 models/。"""
    from tagger.web import downloads as dl_mod

    root = tmp_path / "models"
    monkeypatch.setattr(dl_mod, "MODELS_ROOT", root)
    monkeypatch.setattr(dl_mod, "DOWNLOADS", dl_mod.DownloadManager(models_root=root))
    def unexpected_download(*args, **kwargs):
        raise AssertionError("测试必须模拟模型下载，不能访问真实仓库")
    monkeypatch.setattr(dl_mod, "_list_files", unexpected_download)
    return root


def test_uncensored_variants_are_shipped(client):
    """无审查版必须开箱可选，否则打 NSFW 图会整张漏标（模型拒答不报错）。"""
    keys = {m["key"] for m in client.get("/api/models").json()["vlm"]}
    assert {"qwen3vl-4b-abliterated", "qwen3vl-8b-abliterated"} <= keys


def test_local_state_and_download_repo(client, dl_root):
    data = client.get("/api/models").json()
    by_key = {m["key"]: m for m in data["vlm"]}
    entry = by_key["qwen3vl-4b"]
    # dl_root 把根目录指到了临时目录，所以这里只校验末两段
    from pathlib import Path

    assert Path(entry["local_dir"]).parts[-2:] == ("nl", "qwen3vl-4b")
    assert entry["exists"] is False and entry["local_bytes"] == 0
    # 下载源就是 path 指的原始权重仓库。网上现成的 GGUF 一份都不下：量化档
    # 只能由「本地量化」从这份原始权重压出来，否则"同一份权重两种来路"，
    # 产物漂了查不出是哪个环节。
    assert entry["download_repo"] == "Qwen/Qwen3-VL-4B-Instruct"
    # 没有"挑一档下"的清单：量化档不走下载，所以这个字段不该出现。
    assert "download_tiers" not in entry
    # tag 的默认目录对齐现有习惯：models/<backend>
    tag = {t["backend"]: t for t in data["tag"]}["wd-eva02"]
    assert Path(tag["local_dir"]).name == "wd-eva02"
    assert tag["download_repo"].startswith("ashen-sensored/")


def test_local_dir_is_persisted(client, tmp_path):
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm[0]["local_dir"] = "models/nl/custom-dir"
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["dirs"] == {f"vlm:{vlm[0]['key']}": "models/nl/custom-dir"}
    again = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}
    assert again[vlm[0]["key"]]["local_dir"] == "models/nl/custom-dir"


def test_download_reports_progress_then_shows_files(client, dl_root, monkeypatch):
    """下载完要能看出"已落地"：exists/local_bytes 是页面切到删除按钮的依据。"""
    from tagger.web import downloads as dl_mod

    # 现在 VLM 下载是整仓库原始权重（不再传白名单），这里给一个 safetensors
    # 文件名，跟真实下载的内容一致。
    name = "model.safetensors"
    monkeypatch.setattr(dl_mod, "_list_files", lambda repo, proxy="": [(name, 12)])
    seen: list[dict] = []

    def fake_fetch(task, name, size, done):
        (task.dest / name).parent.mkdir(parents=True, exist_ok=True)
        (task.dest / name).write_bytes(b"x" * size)
        task.tick(done + size)
        seen.append(task.state())
        return done + size

    monkeypatch.setattr(dl_mod, "_fetch", fake_fetch)
    key = "qwen3vl-4b"
    r = client.post("/api/models/download", json={"kind": "vlm", "key": key})
    assert r.status_code == 200
    for _ in range(200):
        state = dl_mod.DOWNLOADS.state_of("vlm", key)
        if state and state["status"] in ("done", "error"):
            break
        time.sleep(0.01)
    assert state and state["status"] == "done", state
    assert state["bytes_total"] == 12 and state["bytes_done"] == 12
    assert state["percent"] == 100.0
    assert (dl_root / "nl" / key / name).is_file()
    entry = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}[key]
    assert entry["exists"] is True and entry["local_bytes"] == 12


def test_download_needs_a_repo(client, dl_root, tmp_path):
    """path 是本地目录时没有可下的原始权重：要说清楚，而不是起个必然失败的任务。"""
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm[0]["path"] = str(tmp_path / "local-weights")
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    r = client.post("/api/models/download", json={"kind": "vlm", "key": vlm[0]["key"]})
    assert r.status_code == 400
    assert "原始权重" in r.json()["detail"]


def test_delete_refuses_paths_outside_models_root(client, dl_root, tmp_path):
    """local_dir 填到素材目录上时，"删除模型"不能变成删素材。"""
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "keep.jpg").write_bytes(b"x")
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    vlm[0]["local_dir"] = str(outside)
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})
    r = client.post("/api/models/localfiles/delete", json={"kind": "vlm", "key": vlm[0]["key"]})
    assert r.status_code == 400
    assert "不在模型目录" in r.json()["detail"]
    assert (outside / "keep.jpg").is_file(), "越界目录被删了"


# ---- 下载代理


def test_normalize_proxy_fills_scheme():
    from tagger.web.downloads import normalize_proxy, socks_ready

    assert normalize_proxy("") == ""
    assert normalize_proxy("  127.0.0.1:7890 ") == "http://127.0.0.1:7890"
    assert normalize_proxy("http://h:1") == "http://h:1"
    if socks_ready():
        assert normalize_proxy("socks5://h:1080") == "socks5://h:1080"
    with pytest.raises(ValueError):
        normalize_proxy("ftp://h:21")


def test_proxy_persists_and_survives_table_save(client, tmp_path):
    r = client.put("/api/models/proxy", json={"url": "127.0.0.1:7890"})
    assert r.status_code == 200
    assert r.json()["proxy"] == "http://127.0.0.1:7890"

    # 整表保存不能把代理抹掉：改一次模型清单就断网，用户会以为是网络坏了
    data = client.get("/api/models").json()
    client.put("/api/models", json={"vlm": data["vlm"], "tag": data["tag"]})
    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["proxy"] == "http://127.0.0.1:7890"
    assert client.get("/api/models").json()["proxy"] == "http://127.0.0.1:7890"

    # 清空 = 直连
    client.put("/api/models/proxy", json={"url": ""})
    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert "proxy" not in doc
    assert client.get("/api/models").json()["proxy"] == ""


def test_proxy_rejects_unknown_scheme(client):
    r = client.put("/api/models/proxy", json={"url": "ftp://1.2.3.4:21"})
    assert r.status_code == 400
    assert "不支持" in r.json()["detail"]


def test_proxy_test_returns_reason_instead_of_raising(client):
    r = client.post("/api/models/proxy/test", json={"url": "ftp://1.2.3.4:21"})
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is False and "不支持" in body["error"]


def test_delete_removes_downloaded_files(client, dl_root):
    key = "qwen3vl-4b"
    target = dl_root / "nl" / key
    target.mkdir(parents=True)
    (target / "model.safetensors").write_bytes(b"x" * 8)
    assert client.get("/api/models").json()  # 让 catalog 读到 exists
    r = client.post("/api/models/localfiles/delete", json={"kind": "vlm", "key": key})
    assert r.status_code == 200
    assert not target.exists()
    entry = {m["key"]: m for m in r.json()["vlm"]}[key]
    assert entry["exists"] is False and entry["local_bytes"] == 0


# ------------------------------------------------------------------ 下载内容
#
# 口径：VLM 下载**只有原始权重**。量化档一律由「本地量化」从这份权重压出来，
# 不从网上拿现成的——同一份权重两种来路，产出漂了根本查不出是哪一环。
# （历史问题"不管怎么选都是 Q4"是另一回事：那会儿下载清单写死 Q4/Q6、页面
# 没有选档入口；现在根本没有"选档下载"这个动作了。）


def test_download_always_fetches_raw_weights(client, dl_root, monkeypatch):
    """传什么 precision 都不影响内容：仓库是 path 指的那个，清单为空（整包）。"""
    from tagger.web import downloads as dl_mod

    captured: dict = {}

    def fake_start(kind, key, repo, dest, proxy="", allow=None):
        captured.update(repo=repo, allow=None if allow is None else list(allow))
        return {"ok": True}

    monkeypatch.setattr(dl_mod.DOWNLOADS, "start", fake_start)
    r = client.post("/api/models/download",
                    json={"kind": "vlm", "key": "qwen3vl-8b-abliterated",
                          "precision": "q6"})
    assert r.status_code == 200, r.text
    # 破限版的原始权重在 prithivMLmods，不是 mradermacher 那个 GGUF 仓库
    assert captured["repo"] == "prithivMLmods/Qwen3-VL-8B-Instruct-Unredacted-MAX"
    assert captured["allow"] is None, "整仓库都要，少一个文件就转不出 GGUF"


def test_local_state_flags_missing_gguf(client, dl_root):
    """原始权重到位 ≠ 能跑：GGUF 要等本地量化产出，缺它照样起不来。"""
    key = "qwen3vl-4b"
    dest = dl_root / "nl" / key
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "model-00001-of-00002.safetensors").write_bytes(b"x" * 8)
    entry = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}[key]
    assert entry["exists"] is True
    assert entry["ready"] is False
    assert "qwen3vl-4b-Q4_K_M.gguf" in entry["missing_files"]

    # 本地量化产出的两个文件放上，才算 ready
    (dest / "qwen3vl-4b-Q4_K_M.gguf").write_bytes(b"x" * 4)
    (dest / "mmproj-qwen3vl-4b-F16.gguf").write_bytes(b"x" * 4)
    entry = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}[key]
    assert entry["ready"] is True and entry["missing_files"] == []


def test_save_keeps_gguf_quants(client, tmp_path):
    """覆盖是整条替换：保存时漏抄 gguf_quants，q6 就静默消失。"""
    data = client.get("/api/models").json()
    vlm = [dict(m) for m in data["vlm"]]
    for item in vlm:
        if item["key"] == "qwen3vl-8b-abliterated":
            # 只改备注不会写进覆盖（notes 是单独一段），得动一个 spec 字段：
            # 改下载目录是最常见的手滑场景，也是当初把 gguf_quants 抹掉的那条路。
            item["mmproj"] = "models/nl/qwen3vl-8b/自定义-mmproj.gguf"
    client.put("/api/models", json={"vlm": vlm, "tag": data["tag"]})

    doc = json.loads((tmp_path / "models.json").read_text(encoding="utf-8"))
    assert doc["vlm"]["qwen3vl-8b-abliterated"]["gguf_quants"], \
        "覆盖文件里丢了 gguf_quants，之后选 q6 会静默回落 q4"
    table = config_mod.load_tier_table()
    quants = table["models"]["qwen3vl-8b-abliterated"]["gguf_quants"]
    assert {"q4", "q6"} <= set(quants)


def test_defaults_say_which_weights_are_missing(client, dl_root):
    """新建任务页要能"选完就知道缺什么"，而不是点启动才报错。

    vllm_models 原来只有配置字段，页面拿不到权重在不在盘上 —— 那句
    "权重未下载"的提示判断的是一个从来不存在的字段，永远不会显示。
    """
    # 用破限版：它在这台开发机上确实没下过，不受仓库里已有的那份影响
    models = {m["key"]: m for m in client.get("/api/defaults").json()["vllm_models"]}
    entry = models["qwen3vl-4b-abliterated"]
    assert entry["exists"] is False
    assert entry["ready"] is False
    assert entry["missing_files"], "至少要报出缺哪个文件"

    # 把 llama.cpp 真要的两个文件放进下载目录 → 变成可用
    dest = dl_root / "nl" / "qwen3vl-4b-abliterated"
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "qwen3vl-4b-abliterated-Q4_K_M.gguf").write_bytes(b"x")
    (dest / "mmproj-qwen3vl-4b-abliterated-F16.gguf").write_bytes(b"x")
    entry = {m["key"]: m for m in client.get("/api/defaults").json()["vllm_models"]}[
        "qwen3vl-4b-abliterated"]
    assert entry["ready"] is True and entry["missing_files"] == []
    # 页面的精度网格靠这个字段置灰：盘上只有 Q4，Q6 就不该让人选
    assert entry["gguf_ready"] == ["q4"]
    assert entry["raw_ready"] is False and entry["quantized"] is False


def test_truncated_gguf_does_not_count_as_ready(client, dl_root):
    """半截 .gguf 不能算"这一档压好了"。

    实测：量化中途断了，留下 0.47G 的 Q6（正常 6.3G）。文件名齐、大小不对，
    页面照样标"已压"，起服务也不报缺文件——直接加载一坨垃圾。有原始权重时
    就拿它的体积当基准（真量化档至少 20%：Q4≈30%、Q6≈40%、Q8≈53%）。
    """
    key = "qwen3vl-4b"
    dest = dl_root / "nl" / key
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "model.safetensors").write_bytes(b"x" * 1000)          # 基准
    (dest / "qwen3vl-4b-Q4_K_M.gguf").write_bytes(b"x" * 300)      # 30% → 正常
    (dest / "qwen3vl-4b-Q6_K.gguf").write_bytes(b"x" * 20)         # 2% → 半截

    entry = {m["key"]: m for m in client.get("/api/models").json()["vlm"]}[key]
    assert entry["gguf_ready"] == ["q4"]
    # 半截的那档要单列出来：页面据此说"Q6 文件不完整，重压一次"，
    # 而不是假装从来没压过（用户会以为是自己记错了）
    assert entry["gguf_broken"] == ["q6"]

def test_missing_files_follow_precision():
    """默认档是 f16 时，自己压了 q4 的人不该被告知"缺 F16.gguf"。

    反过来的坑也踩过：有人把 W4A16（vLLM 的 AWQ/GPTQ safetensors）压完了，
    页面还在提示缺 gguf —— 那是另一条引擎要的文件，文案与判定都得只谈
    llama.cpp 那一档。
    """
    from tagger.web.models import missing_weight_files

    spec = {
        "precision": "q4",
        "gguf": "models/nl/x/x-F16.gguf",
        "gguf_quants": {"f16": "models/nl/x/x-F16.gguf",
                        "q4": "models/nl/x/x-Q4_K_M.gguf"},
        "mmproj": "models/nl/x/mmproj-x-F16.gguf",
    }
    missing = missing_weight_files(spec)
    assert "x-Q4_K_M.gguf" in missing
    assert "x-F16.gguf" not in missing


def test_endpoint_setting_wins_over_env(client, monkeypatch):
    """下载源优先级：页面设置 > HF_ENDPOINT > 官方。

    这条必须钉住：镜像站是"下载不走梯子"的唯一解法，页面设了却被环境变量
    压住的话，用户会一直以为设置没生效（然后继续烧代理流量）。
    """
    monkeypatch.setenv("HF_ENDPOINT", "https://env.example")
    assert config_mod.download_endpoint() == "https://env.example"

    got = client.put("/api/models/endpoint",
                     json={"url": "https://hf-mirror.com/"}).json()
    assert got["endpoint"] == "https://hf-mirror.com", "末尾斜杠要吃掉"
    assert got["effective"] == "https://hf-mirror.com"
    assert got["catalog"]["effective_endpoint"] == "https://hf-mirror.com"

    # 清空 = 回到环境变量，而不是回到官方
    back = client.put("/api/models/endpoint", json={"url": ""}).json()
    assert back["effective"] == "https://env.example"


def test_endpoint_rejects_missing_scheme(client):
    """漏协议是最常见的填法（从地址栏抄 `hf-mirror.com`），要当场拒掉。"""
    assert client.put("/api/models/endpoint",
                      json={"url": "hf-mirror.com"}).status_code == 400


def test_conns_setting_roundtrip(client, monkeypatch):
    """连接数：页面设置 > 环境变量 > 默认 4。

    镜像站实测总速随连接数线性涨（4→1.2、16→5.8 MB/s），所以这个值必须
    能在页面上改，而不是只在代码里写死。
    """
    from tagger.web import downloads as dl

    monkeypatch.delenv("TAGGER_DL_CONNS", raising=False)
    assert dl._conns() == 4                      # 默认

    got = client.put("/api/models/conns", json={"conns": 16}).json()
    assert got["conns"] == 16
    assert dl._conns() == 16

    assert client.put("/api/models/conns", json={"conns": 0}).json()["conns"] == 4
    assert client.put("/api/models/conns", json={"conns": 99}).status_code == 400


def test_default_endpoint_is_mirror(client, monkeypatch):
    """什么都不设时走镜像站，不是官方。

    官方在国内基本要挂代理，而权重动辄十几 G——默认值选错，等于默认让用户
    按流量付费。要回官方得显式选。
    """
    monkeypatch.delenv("HF_ENDPOINT", raising=False)
    assert config_mod.download_endpoint() == "https://hf-mirror.com"
    assert client.get("/api/models").json()["effective_endpoint"] == "https://hf-mirror.com"
