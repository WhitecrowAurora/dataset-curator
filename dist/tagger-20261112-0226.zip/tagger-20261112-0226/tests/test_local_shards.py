"""本地分片输入：parquet 与 webdataset 的分流。

两种格式的解包方式完全不同（parquet 流式读、zip/tar 按成员解包），
但产物写法必须一致。混着放是没定义的——编号口径不同，拼一起对不上账。
"""

from __future__ import annotations

import pytest

from tagger.client import classify_local_inputs, collect_shards
from tagger.config import ConfigError


def test_classify_parquet_dir(tmp_path):
    (tmp_path / "pack-00000.parquet").write_bytes(b"")
    (tmp_path / "pack-00001.parquet").write_bytes(b"")
    parquet, shards = classify_local_inputs(tmp_path)
    assert [p.name for p in parquet] == ["pack-00000.parquet", "pack-00001.parquet"]
    assert shards == []


def test_classify_webdataset_dir(tmp_path):
    (tmp_path / "dist-00000.tar").write_bytes(b"")
    (tmp_path / "dist-00001.zip").write_bytes(b"")
    parquet, shards = classify_local_inputs(tmp_path)
    assert parquet == []
    assert [p.name for p in shards] == ["dist-00000.tar", "dist-00001.zip"]


def test_classify_accepts_a_single_string(tmp_path):
    """Web 侧 input_dir 是字符串；逐字符遍历会变成"分片不存在: D"。"""
    f = tmp_path / "one.parquet"
    f.write_bytes(b"")
    parquet, shards = classify_local_inputs(str(f))
    assert parquet == [f]
    assert shards == []


def test_classify_rejects_mixed_formats(tmp_path):
    (tmp_path / "a.parquet").write_bytes(b"")
    (tmp_path / "b.zip").write_bytes(b"")
    with pytest.raises(ConfigError, match="同时有 parquet"):
        classify_local_inputs(tmp_path)


def test_classify_rejects_empty_dir(tmp_path):
    with pytest.raises(ConfigError, match="没有 .parquet"):
        classify_local_inputs(tmp_path)


def test_classify_rejects_unknown_file(tmp_path):
    bad = tmp_path / "images.jpg"
    bad.write_bytes(b"")
    with pytest.raises(ConfigError, match="不认识的分片格式"):
        classify_local_inputs(bad)


def test_collect_shards_accepts_a_single_string(tmp_path):
    """同一个坑的第二处入口：CLI 传列表，Web 传字符串。"""
    f = tmp_path / "d.zip"
    f.write_bytes(b"")
    assert collect_shards(str(f)) == [f]
