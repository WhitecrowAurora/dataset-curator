"""WebUI 四项新功能的针对性回归：

    - HF 文件名过滤：指定的文件缺一片就警告，绝不静默"整包没交"
    - guard 在 tag_items 的挂点：stop 级别在块边界跳出、pause 等待可恢复、
      每个块结算一次 after_unit
    - guard 事件接线：_make_guard 的 on_state 把级别变化推进任务事件流
    - VLM 引擎：create 校验（hf_repo/input_dir 二选一）、run_client 桥接
      （Namespace 组装 / hook→事件 / ClientStats→快照）
    - 回传：假 FTP 上传的成功/失败/文件间停止；parquet 行数进快照
    - run_batch 的 should_stop：串行路径抛 Stopped，不再发新请求
"""

from __future__ import annotations

import threading
import time
from types import SimpleNamespace

import pytest

from tagger.client import (ClientStats, Outcome, TaskRow, _filter_shards,
                           run_batch)
from tagger.config import OutputSpec
from tagger.cpu_tagger import TagPrediction
from tagger.guard import GuardState
from tagger.local_tag import TagItem, tag_items
from tagger.web import jobs as jobs_mod
from tagger.web import uploads as uploads_mod
from tagger.web.jobs import JobManager, JobSpec
from tagger.web.uploads import UPLOADS, UploadManager

pyarrow = pytest.importorskip("pyarrow", reason="parquet 统计与产物需要 pyarrow")


# ------------------------------------------------------------------ 假件

class _FakeBackend:
    name = "fake"
    precision = "bf16"

    def __init__(self, batch_size=2):
        self.batch_size = batch_size
        self.last_timings = {"total": 0, "decode": 0, "forward": 0}
        self.calls: list[list[str]] = []

    def predict_batch(self, images):
        self.calls.append(list(images))
        self.last_timings = {"total": 10, "decode": 4, "forward": 3}
        return [TagPrediction(tags=[("red", 0.9)], backend="fake")
                for _ in images]


class _StubGuard:
    """before_unit 按剧本回放 GuardState；watchdog.state 给等待循环读。"""

    def __init__(self, script):
        self.script = list(script)
        self.state = GuardState()
        self.after_calls = 0
        self.watchdog = SimpleNamespace(state=self.state)

    def before_unit(self, *, wait=True):
        return self.script.pop(0) if self.script else self.state

    def after_unit(self):
        self.after_calls += 1
        return {}


def _items(tmp_path, n):
    items = []
    for i in range(n):
        p = tmp_path / f"{i}.png"
        p.write_bytes(b"\x89PNG\r\n\x1a\n")
        items.append(TagItem(image_id=f"i-{i}", rel=f"{i}.png", path=p))
    return items


# ------------------------------------------------------------------ HF 文件名过滤

def test_filter_shards_keeps_requested_and_warns_missing(capsys):
    names = ["shard-000.parquet", "shard-001.parquet", "shard-002.parquet"]
    kept = _filter_shards(names, ["shard-001.parquet", "shard-009.parquet"])
    assert kept == ["shard-001.parquet"]
    err = capsys.readouterr().err
    assert "shard-009.parquet" in err, "指定的文件不在仓库里必须警告，不能静默整包没交"
    # 空 = 全部；None 同
    assert _filter_shards(names, []) == names
    assert _filter_shards(names, None) == names


# ------------------------------------------------------------------ guard 挂点

def test_tag_items_guard_stop_breaks_before_chunk(tmp_path):
    backend = _FakeBackend()
    guard = _StubGuard([GuardState(level="stop")])
    stats = tag_items(backend, _items(tmp_path, 4), out_dir=tmp_path / "o",
                      guard=guard)
    assert stats.stopped is True
    assert stats.done == 0
    assert backend.calls == []
    assert guard.after_calls == 0


def test_tag_items_guard_pause_waits_then_runs(tmp_path):
    backend = _FakeBackend()
    guard = _StubGuard([GuardState(level="pause")])
    # 等待循环里读 watchdog.state：1s 后放行
    def release():
        time.sleep(1.0)
        guard.watchdog.state = GuardState(level="ok")
    t = threading.Thread(target=release, daemon=True)
    t.start()
    stats = tag_items(backend, _items(tmp_path, 4), out_dir=tmp_path / "o",
                      guard=guard)
    assert stats.stopped is False
    assert stats.done == 4
    assert guard.after_calls >= 1, "每个跑完的块都要结算一次占空比"


def test_make_guard_pushes_state_changes_into_events(tmp_path):
    _items(tmp_path, 1)                    # create() 要求目录里至少有图
    mgr = JobManager()
    spec = JobSpec(input_dir=str(tmp_path), out_dir=str(tmp_path / "out"))
    spec.guard = True
    job = mgr.create(spec)
    guard = mgr._make_guard(job)
    assert guard is not None
    # 模拟 watchdog 采样后的级别通知（run() 里同一入口）
    guard.watchdog._notify(GuardState(level="warn", temp_c=80.0))
    events = [e for e in job.events_since(0) if e["kind"] == "guard"]
    assert len(events) == 1
    assert events[0]["level"] == "warn"
    # 恢复到 ok 也要推一次：页面上的"已恢复正常"靠它
    guard.watchdog._notify(GuardState(level="ok"))
    events = [e for e in job.events_since(0) if e["kind"] == "guard"]
    assert [e["level"] for e in events] == ["warn", "ok"]
    guard.stop()


def test_guard_policy_overrides_reach_the_policy(tmp_path):
    """页面上改的阈值必须落到真正生效的 policy 上，而不是只停在快照里。"""
    _items(tmp_path, 1)                    # create() 要求目录里至少有图
    mgr = JobManager()
    job = mgr.create(JobSpec(
        input_dir=str(tmp_path), out_dir=str(tmp_path / "out"),
        guard_policy={"duty_cycle": 1.0, "temp_cutoff_c": 90, "temp_resume_c": 80}))
    guard = mgr._make_guard(job)
    assert guard is not None
    assert guard.policy.duty_cycle == 1.0
    assert (guard.policy.temp_cutoff_c, guard.policy.temp_resume_c) == (90, 80)
    # 磁盘阈值仍按 check_space 清零：否则剩 12G 跑 3 张图也会被拦
    assert guard.policy.disk_min_free_gb == 0.0
    guard.stop()


def test_guard_policy_rejects_resume_above_cutoff(tmp_path):
    """恢复温度不低于熔断温度 = 一熔断就再也恢复不了，必须在建任务时 400。"""
    _items(tmp_path, 1)
    with pytest.raises(ValueError, match="恢复温度"):
        JobManager().create(JobSpec(
            input_dir=str(tmp_path), out_dir=str(tmp_path / "out"),
            guard_policy={"temp_cutoff_c": 82, "temp_resume_c": 85}))


def test_normalize_guard_policy_drops_unknown_and_clamps():
    """白名单外静默丢掉（老前端多传一个键不该让整批跑不了），区间外的夹回来。"""
    assert jobs_mod.normalize_guard_policy(None) == {}
    # sample_interval_s 不在白名单：它改的是采样频率，与保护动作无关
    assert jobs_mod.normalize_guard_policy(
        {"sample_interval_s": 30, "duty_cycle": 9}) == {"duty_cycle": 1.0}
    # 闭环细调现在也在白名单里（团队内部工具，改坏了能改回来）
    assert jobs_mod.normalize_guard_policy({"kp": 0.5}) == {"kp": 0.5}
    assert jobs_mod.normalize_guard_policy({"temp_cutoff_c": 5}) == {
        "temp_cutoff_c": jobs_mod.GUARD_KNOBS["temp_cutoff_c"][0]}
    with pytest.raises(ValueError):
        jobs_mod.normalize_guard_policy({"duty_cycle": "abc"})


# ------------------------------------------------------------------ VLM 引擎

def _vlm_spec(tmp_path, **kw) -> JobSpec:
    kw.setdefault("out_dir", str(tmp_path / "out"))
    return JobSpec(engine="vlm", **kw)


def test_create_vlm_requires_repo_or_dir(tmp_path):
    mgr = JobManager()
    with pytest.raises(ValueError, match="hf_repo"):
        mgr.create(_vlm_spec(tmp_path))
    with pytest.raises(ValueError, match="二选一"):
        mgr.create(_vlm_spec(tmp_path, hf_repo="org/repo",
                             input_dir=str(tmp_path)))
    with pytest.raises(ValueError, match="input_dir"):
        mgr.create(JobSpec(engine="local", out_dir=str(tmp_path / "o")))


def test_create_vlm_plan_is_none(tmp_path):
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/repo"))
    assert job.plan is None
    assert job.items == []
    assert job.out_dir == tmp_path / "out"


def test_run_vlm_bridges_run_client(tmp_path, monkeypatch):
    seen: dict = {}

    # paused 是 run_client 的协作式暂停钩子（Web 的暂停按钮）。替身必须
    # 照抄完整签名：少一个关键字参数，岗位里的 TypeError 会被当成"任务失败"，
    # 测试报的是 `seen["args"]` KeyError，离真因隔了一层。
    def fake_run_client(args, ops, table, on_progress=None, should_stop=None,
                        on_log=None, guard=None, paused=None):
        seen["args"] = args
        seen["guard"] = guard
        on_log("横幅一条")
        stats = ClientStats()
        on_progress("done", TaskRow(shard="hf://r/s#m", image_id="a-1",
                                    file="a-1.jpg", image_path="hf://r/s#m"),
                    Outcome("a-1", True, tag={"tags": [["red", 0.9]]}), stats)
        on_progress("failed", TaskRow(shard="hf://r/s#m", image_id="a-2",
                                      file="a-2.jpg"),
                    Outcome("a-2", False, error="坏图"), stats)
        on_progress("skipped", TaskRow(shard="hf://r/s#m", image_id="a-3",
                                       file="a-3.jpg"), None, stats)
        stats.done, stats.failed, stats.skipped, stats.total = 1, 1, 1, 3
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/team-parquet",
                               guard=False, vlm_model="qwen-vl-8b"))
    mgr._run(job)

    args = seen["args"]
    assert args.hf_repo == "org/team-parquet"
    assert args.shard is None
    assert args.quiet is True and args.no_guard is True
    assert args.mode == "both"
    assert args.tag_backend == "wd-eva02"      # 默认后端 + both → 交给本地后端
    assert args.artifact_format == "jsonl"   # 本地默认一包一文件（parquet 是服务器侧的事）
    assert args.model_name == "qwen-vl-8b"
    assert seen["guard"] is None               # guard=False → 不构造

    assert job.status == "done"
    counts = job.snapshot()["counts"]
    assert counts == {"total": 3, "done": 1, "skipped": 1, "failed": 1, "busy": 0,
                      "blacklisted": 0, "settled": 3}
    kinds = [e["kind"] for e in job.events_since(0)]
    assert "log" in kinds and "item" in kinds
    items = [e for e in job.events_since(0) if e["kind"] == "item"]
    done_ev = next(e for e in items if e["image_id"] == "a-1")
    assert done_ev["ok"] is True and done_ev["tags"] == ["red"]
    failed_ev = next(e for e in items if e["image_id"] == "a-2")
    assert failed_ev["ok"] is False
    # 快照不泄露 token
    assert job.snapshot()["spec"]["hf_token"] in ("", "***")


def test_run_vlm_mode_mapping(tmp_path, monkeypatch):
    seen: dict = {}

    def fake_run_client(args, ops, table, **kw):
        seen["mode"] = args.mode
        seen["backend"] = args.tag_backend
        return 0

    monkeypatch.setattr("tagger.client.run_client", fake_run_client)
    mgr = JobManager()
    # 只要 NL：后端一起关掉
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False,
                               output_mode="nl", backend="pixai"))
    mgr._run(job)
    assert (seen["mode"], seen["backend"]) == ("nl", "none")
    # both + VLM 自己出 tag：后端 none，mode both
    job = mgr.create(_vlm_spec(tmp_path, hf_repo="org/r", guard=False,
                               output_mode="both", backend="vlm"))
    mgr._run(job)
    assert (seen["mode"], seen["backend"]) == ("both", "none")


# ------------------------------------------------------------------ 回传

def _parquet_file(tmp_path, name, rows):
    import pyarrow as pa
    import pyarrow.parquet as pq

    table = pa.table({"image_id": [f"i-{i}" for i in range(rows)],
                      "tag": ["red"] * rows})
    pq.write_table(table, tmp_path / name)
    return name


class _FakeUploader:
    """替身 FtpUploader：记录调用，回"成功"。阻塞版见 _BlockingUploader。"""

    last_instance: "_FakeUploader | None" = None

    def __init__(self, cfg, *, verbose=False):
        self.cfg = cfg
        self.uploads: list[str] = []
        self.connected = False
        self.closed = False
        _FakeUploader.last_instance = self

    def connect(self):
        self.connected = True

    def close(self):
        self.closed = True

    def upload(self, path, **kw):
        from tagger.upload import UploadResult

        self.uploads.append(path.name)
        return UploadResult(ok=True, bytes_sent=123, resumed=False)


class _BlockingUploader(_FakeUploader):
    """第一个文件传完前等外部放行：给"文件间停止"测试一个确定的窗口。"""

    def __init__(self, cfg, *, verbose=False):
        super().__init__(cfg, verbose=verbose)
        self.block_first = threading.Event()
        self.proceed = threading.Event()

    def upload(self, path, **kw):
        from tagger.upload import UploadResult

        self.uploads.append(path.name)
        if len(self.uploads) == 1:
            self.block_first.set()
            assert self.proceed.wait(timeout=10), "测试没有放行第一个文件"
        return UploadResult(ok=True, bytes_sent=123, resumed=False)


def test_upload_manager_success_and_rows(tmp_path, monkeypatch):
    names = [_parquet_file(tmp_path, f"pack-{i}.parquet", 5 + i) for i in range(2)]
    monkeypatch.setattr(uploads_mod, "FtpUploader", _FakeUploader)
    UPLOADS._jobs.clear()
    job = UploadManager().create(str(tmp_path), names, host="192.0.2.1",
                                 port=21, user="u", password="p",
                                 remote_dir="/team", passive=True)
    deadline = time.time() + 10
    while time.time() < deadline and job.status not in ("done", "failed", "stopped"):
        time.sleep(0.05)
    assert job.status == "done", job.error
    snap = job.snapshot()
    assert [f["status"] for f in snap["files"]] == ["done", "done"]
    assert [f["rows"] for f in snap["files"]] == [5, 6]
    assert snap["sent_bytes"] == 246
    # 密码不出门
    assert "password" not in snap["ftp"] and "user" not in snap["ftp"]
    assert _FakeUploader.last_instance.closed is True


def test_upload_manager_failure_marks_file(tmp_path, monkeypatch):
    class _FailUploader(_FakeUploader):
        def upload(self, path, **kw):
            from tagger.upload import UploadResult

            self.uploads.append(path.name)
            return UploadResult(ok=False, error="550 Permission denied")

    names = [_parquet_file(tmp_path, "pack-0.parquet", 3)]
    monkeypatch.setattr(uploads_mod, "FtpUploader", _FailUploader)
    UPLOADS._jobs.clear()
    job = UploadManager().create(str(tmp_path), names, host="h", port=21,
                                 user="u", password="p", remote_dir="/",
                                 passive=True)
    deadline = time.time() + 10
    while time.time() < deadline and job.status not in ("done", "failed", "stopped"):
        time.sleep(0.05)
    assert job.status == "failed"
    assert "Permission denied" in job.snapshot()["files"][0]["error"]


def test_upload_manager_stop_between_files(tmp_path, monkeypatch):
    names = [_parquet_file(tmp_path, f"pack-{i}.parquet", 2) for i in range(2)]
    monkeypatch.setattr(uploads_mod, "FtpUploader", _BlockingUploader)
    UPLOADS._jobs.clear()
    job = UPLOADS.create(str(tmp_path), names, host="h", port=21,
                                 user="u", password="p", remote_dir="/",
                                 passive=True)
    # 第一个文件开始传时置停止，然后放行：当前文件传完，第二个不再开始
    assert _BlockingUploader.last_instance.block_first.wait(timeout=10)
    assert UPLOADS.stop(job.id) is True
    _BlockingUploader.last_instance.proceed.set()
    deadline = time.time() + 10
    while time.time() < deadline and job.status not in ("done", "failed", "stopped"):
        time.sleep(0.05)
    assert job.status == "stopped"
    statuses = [f["status"] for f in job.snapshot()["files"]]
    assert statuses == ["done", "stopped"]
    assert _BlockingUploader.last_instance.uploads == ["pack-0.parquet"]


def test_upload_manager_rejects_traversal(tmp_path):
    (tmp_path / "a.parquet").write_bytes(b"x")
    UPLOADS._jobs.clear()
    with pytest.raises(ValueError, match="parquet"):
        UploadManager().create(str(tmp_path), ["../evil.parquet"], host="h",
                               port=21, user="u", password="p",
                               remote_dir="/", passive=True)
    with pytest.raises(ValueError, match="没有勾选"):
        UploadManager().create(str(tmp_path), [], host="h", port=21,
                               user="u", password="p", remote_dir="/",
                               passive=True)


# ------------------------------------------------------------------ run_batch 协作式停止

class _CountingClient:
    need_tags = True

    def __init__(self):
        self.output = OutputSpec(mode="both", tag_min_count=1, tag_max_count=10)
        self.calls: list[str] = []

    def process(self, task, data, reader):
        self.calls.append(task.image_id)
        return Outcome(task.image_id, True, tag={"tag": ["red"]}, tokens=3)


def test_run_batch_serial_stop_raises_and_stops_submitting(tmp_path):
    client = _CountingClient()
    tasks = [TaskRow(shard="s.zip", image_id=f"a-{i:06d}", file=f"a-{i:06d}.png")
             for i in range(1, 6)]
    from tagger.client import Stopped

    state = {"n": 0}

    def should_stop() -> bool:
        state["n"] += 1
        return state["n"] > 3        # 第 3 张之后就停

    with pytest.raises(Stopped):
        run_batch(client, tasks, None, out_dir=tmp_path, layout="flat",
                  force=False, concurrency=1, guard=None, stats=ClientStats(),
                  failures=None, verbose=False, should_stop=should_stop)
    assert len(client.calls) < len(tasks), "停止后不能再发新请求"
