"""自研 K-quant 内核的测试。

这些断言看起来"只是数值"，但它们各自锁住一类真实错误：

- 字节数不对 → GGUF 布局写错，llama.cpp 直接拒绝加载；
- 误差过大 → 位打包或 scale/min 偏移写反（第一版就把 `x + off` 写成了
  `x - off`，Q4 的 RMS 从 0.078 涨到 0.71）；
- round-trip 不等 → 读写端对 offset/alignment 的理解不一致。
"""

import numpy as np
import pytest
from pathlib import Path

from tagger.gguf_file import (
    GGML_TYPE_F16,
    GGML_TYPE_Q4_K,
    GGML_TYPE_Q6_K,
    Reader,
    TensorInfo,
    write_gguf,
)
from tagger.kquant import (
    Q4K_BLOCK_BYTES,
    Q6K_BLOCK_BYTES,
    QK_K,
    dequantize_q4k,
    dequantize_q6k,
    quantize_q4k,
    quantize_q6k,
    rms_error,
)
from tagger.gguf_quant import _plan, quantize_file


@pytest.fixture(scope="module")
def sample() -> np.ndarray:
    rng = np.random.default_rng(7)
    return rng.normal(size=QK_K * 64).astype(np.float32)


def test_block_sizes_match_ggml(sample):
    """块长必须和 ggml 的 struct 一致，否则文件长度就是错的。"""
    _, _, q4 = quantize_q4k(sample)
    _, q6 = quantize_q6k(sample)
    nblocks = sample.size // QK_K
    assert len(q4) == nblocks * Q4K_BLOCK_BYTES == nblocks * 144
    assert len(q6) == nblocks * Q6K_BLOCK_BYTES == nblocks * 210


def test_quantization_error_is_reasonable(sample):
    """4 bit 的理论下限约 0.087（step/sqrt(12)），留一倍余量。"""
    d, dmin, body = quantize_q4k(sample)
    assert rms_error(sample, dequantize_q4k(d, dmin, body, sample.size)) < 0.12

    d6, body6 = quantize_q6k(sample)
    assert rms_error(sample, dequantize_q6k(d6, body6, sample.size)) < 0.05


def test_zeros_round_trip_exactly():
    """全零张量（未使用的 bias）不能因为除零变成 NaN。"""
    z = np.zeros(QK_K * 4, dtype=np.float32)
    d, dmin, body = quantize_q4k(z)
    assert np.all(dequantize_q4k(d, dmin, body, z.size) == 0)


def test_q4_k_m_keeps_v_projection_at_q6():
    """Q4_K_M 的「M」就体现在这儿：v 投影用 Q6_K，其余用 Q4_K。"""
    assert _plan("blk.0.attn_v.weight", "Q4_K_M") == "q6k"
    assert _plan("blk.0.attn_q.weight", "Q4_K_M") == "q4k"
    # 不传层数时不做分层分配，保持纯 Q4_K
    assert _plan("blk.0.ffn_down.weight", "Q4_K_M") == "q4k"
    # 纯 Q4_K 档不混合
    assert _plan("blk.0.attn_v.weight", "Q4_K") == "q4k"


def test_q4_k_m_layer_rule_matches_official():
    """ffn_down 的升档层必须和官方 Q4_K_M 文件逐个对上。

    期望值不是推导出来的，是拿官方 Q4_K_M 文件数出来的：36 层里
    这 18 个是 Q6_K，其余是 Q4_K。规则 = i < n/8 | i >= 7n/8 | i % 3 == 0。
    """
    official = [0, 1, 2, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 31, 32, 33, 34, 35]
    ours = [i for i in range(36)
            if _plan(f"blk.{i}.ffn_down.weight", "Q4_K_M", 36) == "q6k"]
    assert ours == official
    # 反例：中间层不能无脑升
    assert _plan("blk.19.ffn_down.weight", "Q4_K_M", 36) == "q4k"


def test_q4_k_m_keeps_output_at_q6():
    """lm_head 不能被压成 Q4_K——它直接产出 logits。

    官方 Q4_K_M 文件里 output.weight 是 Q6_K，token_embd 却是 Q4_K。
    区别在于 embedding 之后还有几十层在洗，lm_head 之后什么都没有。
    """
    assert _plan("output.weight", "Q4_K_M", 36) == "q6k"
    assert _plan("token_embd.weight", "Q4_K_M", 36) == "q4k"


def _demo_gguf(path):
    """写一个最小 GGUF：两个 256*N 张量 + 一个压不动的 1D 张量。"""
    import struct

    def wstr(s):
        raw = s.encode()
        return struct.pack("<Q", len(raw)) + raw

    meta = wstr("general.alignment") + struct.pack("<I", 4) + struct.pack("<I", 32)
    rng = np.random.default_rng(3)
    tensors = [
        # 真实权重是 2D；1D 会被"norm 不量化"的规则整条跳过
        (TensorInfo("blk.0.attn_v.weight", (512, 1), 1, 0),
         rng.normal(size=512).astype(np.float16).tobytes()),
        (TensorInfo("blk.0.attn_q.weight", (512, 1), 1, 0),
         rng.normal(size=512).astype(np.float16).tobytes()),
        (TensorInfo("blk.0.attn_norm.weight", (16,), 1, 0),
         rng.normal(size=16).astype(np.float16).tobytes()),
    ]
    write_gguf(path, meta, 1, tensors)


def test_quantize_file_end_to_end(tmp_path):
    """F16 GGUF → Q4_K_M GGUF：类型要换对，元数据要原样留住。"""
    src = tmp_path / "src.gguf"
    out = tmp_path / "out.gguf"
    _demo_gguf(src)

    logs: list[str] = []
    stats = quantize_file(src, out, "Q4_K_M", logs.append,
                          lambda pct, stage: None, lambda: False)

    assert stats == {"tensors": 3, "skipped": 1}
    assert out.is_file()

    before = Reader(src)
    after = Reader(out)
    assert after.metadata_bytes() == before.metadata_bytes()
    assert after.kv_count == before.kv_count

    types = {t.name: t.type for t in after.tensors}
    assert types["blk.0.attn_v.weight"] == GGML_TYPE_Q6_K
    assert types["blk.0.attn_q.weight"] == GGML_TYPE_Q4_K
    # 16 个元素的 norm 压不了（不整除 256），原样保留
    assert types["blk.0.attn_norm.weight"] == GGML_TYPE_F16
    # 体积确实变小了：512 个权重 F16 占 1024 字节，Q4_K 只占 288
    assert out.stat().st_size < src.stat().st_size


_NL = Path(__file__).resolve().parents[1] / "models" / "nl" / "qwen3vl-8b"
_OFFICIAL_Q6 = _NL / "Qwen3VL-8B-Instruct-Q6_K.gguf"
_OFFICIAL_F16 = _NL / "Qwen3VL-8B-Instruct-F16.gguf"


@pytest.mark.skipif(not (_OFFICIAL_Q6.exists() and _OFFICIAL_F16.exists()),
                    reason="本机没有官方 GGUF 可对拍")
def test_dequantize_matches_official_gguf():
    """拿官方发布的 Q6_K 反过来解，必须能还原出 F16 的权重。

    这是唯一能证明"位布局与 ggml 一致"的测试。自己写的文件自己读，
    再自洽也没用——第一版里 `d` 差了 127 倍，round-trip 全过，但拿去解
    官方文件整体小 127 倍，RMS 0.99。这条会直接抓住那类错误。
    """
    from tagger.gguf_file import GGML_TYPE_Q6_K

    with Reader(_OFFICIAL_F16) as rf, Reader(_OFFICIAL_Q6) as rq:
        ref = {t.name: t for t in rf.tensors}
        target = next(t for t in rq.tensors
                      if t.type == GGML_TYPE_Q6_K and t.name == "blk.0.attn_k.weight")

        nblocks = target.n_elements // QK_K
        raw = rq.tensor_bytes(target, nblocks * Q6K_BLOCK_BYTES)
        buf = np.frombuffer(raw, dtype=np.uint8).reshape(nblocks, Q6K_BLOCK_BYTES)
        d = buf[:, 208:210].copy().view(np.float16).reshape(nblocks)

        got = dequantize_q6k(d, raw, target.n_elements)
        want = rf.read_float(ref[target.name])

    assert rms_error(want, got) < 0.05
    assert float(np.corrcoef(want, got)[0, 1]) > 0.99


def test_cancel_leaves_no_partial_file(tmp_path):
    """取消后目录里不能留下一个看起来能用的半截 .gguf。"""
    from tagger.gguf_quant import CancelledError

    src = tmp_path / "src.gguf"
    out = tmp_path / "out.gguf"
    _demo_gguf(src)

    with pytest.raises(CancelledError):
        quantize_file(src, out, "Q4_K_M", lambda _: None,
                      lambda pct, stage: None, lambda: True)

    assert not out.exists()
    assert not out.with_suffix(".gguf.part").exists()
