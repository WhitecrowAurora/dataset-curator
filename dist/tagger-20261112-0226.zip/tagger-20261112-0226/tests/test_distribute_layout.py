"""分发包布局：flat 平铺 / mirror 保留目录树。

`write_shard` 曾收着 `layout` 却从不使用，`--layout mirror` 打出来的包和
flat 一模一样、也没有任何提示。这组测试锁住两种布局的成员名，以及读侧
唯一依据（manifest 的 `file`）。
"""

from __future__ import annotations

import json
import zipfile

import pytest

from tagger.distribute import (DistItem, ShardPlan, read_shard_manifest,
                               write_shard)


def _plan(tmp_path, rows):
    """rows: (rel_path, image_id, ext)。散图源，避免为一个测试去造 zip。"""
    items = []
    for n, (rel, image_id, ext) in enumerate(rows):
        src = tmp_path / f"src{n}.jpg"
        src.write_bytes(b"x")
        items.append(DistItem(source=str(src), member="", rel_path=rel,
                              artist="alice", size=1, ext=ext,
                              image_id=image_id))
    return ShardPlan(index=0, name="dist-0000.zip",
                     first_id=items[0].image_id,
                     last_id=items[-1].image_id,
                     count=len(items), bytes=len(items),
                     items=items)


def _names(shard):
    with zipfile.ZipFile(shard) as zf:
        return [n for n in zf.namelist() if n != "manifest.jsonl"]


def test_flat_is_default_and_keeps_old_names(tmp_path):
    plan = _plan(tmp_path, [("alice/0001.jpg", "alice-000001", ".jpg")])
    shard = write_shard(plan, tmp_path / "out", verbose=False)
    # 默认必须是 flat：老批次的分发包形态不能因为这次改动而变
    assert _names(shard) == ["alice-000001.jpg"]
    rows = read_shard_manifest(shard)
    assert rows[0]["file"] == "alice-000001.jpg"


def test_mirror_keeps_original_tree(tmp_path):
    plan = _plan(tmp_path, [
        ("alice/0001.jpg", "alice-000001", ".jpg"),
        ("bob/sub/0002.png", "bob-000002", ".png"),
    ])
    shard = write_shard(plan, tmp_path / "out", layout="mirror", verbose=False)
    assert _names(shard) == ["alice/0001.jpg", "bob/sub/0002.png"]
    # manifest 的 file 必须跟着变：成员侧只按它取图，不看 image_id 拼名
    files = [r["file"] for r in read_shard_manifest(shard)]
    assert files == ["alice/0001.jpg", "bob/sub/0002.png"]


def test_mirror_strips_escapes_and_drive(tmp_path):
    plan = _plan(tmp_path, [
        ("../../etc/0001.jpg", "alice-000001", ".jpg"),
        ("D:\\素材\\0002.jpg", "alice-000002", ".jpg"),
        ("/abs/0003.jpg", "alice-000003", ".jpg"),
    ])
    shard = write_shard(plan, tmp_path / "out", layout="mirror", verbose=False)
    names = _names(shard)
    # `..` 进了 zip 就是 zip-slip；盘符段只是噪音。两者都要清掉，
    # 但不能把文件名本身也丢了。
    assert names == ["etc/0001.jpg", "素材/0002.jpg", "abs/0003.jpg"]
    for n in names:
        assert not n.startswith(("/", "..")) and ":" not in n


def test_mirror_collision_falls_back_to_image_id(tmp_path):
    # 两个来源里有同一个相对路径，覆盖掉一张图比目录不好看严重得多
    plan = _plan(tmp_path, [
        ("a/0001.jpg", "alice-000001", ".jpg"),
        ("a/0001.jpg", "bob-000002", ".jpg"),
    ])
    shard = write_shard(plan, tmp_path / "out", layout="mirror", verbose=False)
    names = _names(shard)
    assert names[0] == "a/0001.jpg"
    assert names[1] == "a/0001-bob-000002.jpg"
    assert len(set(names)) == 2


def test_mirror_never_clobbers_manifest(tmp_path):
    plan = _plan(tmp_path, [("manifest.jsonl", "alice-000001", ".jsonl")])
    shard = write_shard(plan, tmp_path / "out", layout="mirror", verbose=False)
    assert _names(shard) == ["manifest-alice-000001.jsonl"]
    assert len(read_shard_manifest(shard)) == 1


def test_unknown_layout_is_rejected(tmp_path):
    # 静默按 flat 走才是最难发现的：用户会以为镜像生效了
    plan = _plan(tmp_path, [("a/0001.jpg", "alice-000001", ".jpg")])
    with pytest.raises(ValueError, match="flat / mirror"):
        write_shard(plan, tmp_path / "out", layout="mirrow", verbose=False)


def test_manifest_is_valid_jsonl(tmp_path):
    plan = _plan(tmp_path, [("a/0001.jpg", "alice-000001", ".jpg")])
    shard = write_shard(plan, tmp_path / "out", layout="mirror", verbose=False)
    with zipfile.ZipFile(shard) as zf:
        for line in zf.read("manifest.jsonl").decode("utf-8").splitlines():
            if line.strip():
                json.loads(line)
