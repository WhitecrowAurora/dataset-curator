"""参考 tag 的分类分组（规范 v0.2 §7：分类型 tag 注入 prompt）。"""

from __future__ import annotations

from pathlib import Path

from tagger.client import _ref_block
from tagger.tag_categories import (category_of, find_vocab, group_tags,
                                   load_vocab, render_groups)

VOCAB = {
    "hatsune_miku": "character",
    "vocaloid": "copyright",
    "sakimichan": "artist",
    "long_hair": "general",
    "blue_sky": "general",
    "comic": "meta",
    # 真实 csv 里这四个词本身就是 rating 类（selected_tags.csv 前四行），
    # 它们在源 tag 里也很常见，必须能认出来。
    "general": "rating",
    "explicit": "rating",
}


def test_读csv拿到类别(tmp_path: Path):
    csv = tmp_path / "selected_tags.csv"
    csv.write_text(
        "tag_id,name,category,count\n"
        "0,general,9,1\n"
        "1,hatsune_miku,4,1\n"
        "2,vocaloid,3,1\n"
        "3,sakimichan,1,1\n",
        encoding="utf-8",
    )
    vocab = load_vocab(csv)
    assert vocab["general"] == "rating"
    assert vocab["hatsune_miku"] == "character"
    assert vocab["vocaloid"] == "copyright"
    assert vocab["sakimichan"] == "artist"
    assert category_of("hatsune_miku", vocab) == "character"
    # 这份小 csv 里没有 long_hair：词表外的必须退回 unclassified，不能猜。
    assert category_of("long_hair", vocab) == "unclassified"


def test_词表里没有的tag是unclassified():
    """规范 §7.1：来源没给类别就标 unclassified，不能冒充 general/artist。"""
    assert category_of("anything", {}) == "unclassified"
    assert category_of("midjourney_style", VOCAB) == "unclassified"
    assert load_vocab(Path("不存在的目录/nope.csv")) == {}


def test_分组顺序把身份排在画面之前():
    groups = group_tags(
        ["long_hair", "hatsune_miku", "vocaloid", "sakimichan", "blue_sky"],
        vocab=VOCAB)
    assert [cat for cat, _ in groups] == ["character", "copyright", "artist", "general"]
    assert dict(groups)["general"] == ["long_hair", "blue_sky"]
    assert render_groups(groups).splitlines()[0] == "character_tags: hatsune_miku"


def test_未知类别排在最后一组():
    groups = group_tags(["mystery_thing", "long_hair"], vocab=VOCAB)
    assert groups[-1] == ("unclassified", ["mystery_thing"])
    assert render_groups(groups).splitlines()[-1] == "unclassified_tags: mystery_thing"


def test_rating类不注入():
    """explicit/general 这几个词是审核等级，不是画面事实。"""
    groups = group_tags(["explicit", "general", "long_hair"], vocab=VOCAB)
    assert dict(groups) == {"general": ["long_hair"]}


def test_参考段按类别分组渲染():
    block = _ref_block(["hatsune_miku", "long_hair", "vocaloid"], vocab=VOCAB,
                       grouped=True)
    assert "<REFERENCE>" in block
    assert "character_tags: hatsune_miku" in block
    assert "copyright_tags: vocaloid" in block
    assert "general_tags: long_hair" in block
    # 身份组必须先出现：模型是从上往下读的
    assert block.index("character_tags:") < block.index("general_tags:")


def test_没有词表时全部标成unclassified():
    block = _ref_block(["long_hair", "blue_sky"], vocab={}, grouped=True)
    assert "unclassified_tags: long_hair blue_sky" in block


def test_中文参考段同样分组():
    block = _ref_block(["hatsune_miku", "long_hair"], zh=True, vocab=VOCAB,
                       grouped=True)
    assert "<参考>" in block
    assert "character_tags: hatsune_miku" in block


def test_默认平铺不分组():
    """分组是规范 §7.1 的做法，主创确认不需要；默认必须是平铺。"""
    block = _ref_block(["hatsune_miku", "long_hair", "vocaloid"], vocab=VOCAB)
    assert "<REFERENCE>" in block
    assert "hatsune_miku, long_hair, vocaloid" in block
    assert "character_tags" not in block


def test_空输入不产生空段落():
    assert _ref_block((), vocab=VOCAB) == ""
    assert _ref_block(["", "  "], vocab=VOCAB) == ""


def test_find_vocab认环境变量(tmp_path: Path, monkeypatch):
    csv = tmp_path / "tags.csv"
    csv.write_text("tag_id,name,category,count\n0,a,0,1\n", encoding="utf-8")
    monkeypatch.setenv("TAGGER_TAG_VOCAB", str(csv))
    assert find_vocab() == csv
    monkeypatch.setenv("TAGGER_TAG_VOCAB", str(tmp_path / "missing.csv"))
    assert find_vocab() is None
