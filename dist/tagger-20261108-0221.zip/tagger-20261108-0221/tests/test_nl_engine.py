"""llama.cpp 引擎适配层：口令拼装、像素预算换算、缺件时的报错口径。

为什么这些要单独测
------------------
`nl_engine` 里每一个数字都对应一份产出分布：

- `-c` 是**总池**、vLLM 的 max_model_len 是**每序列**。拼错成直接传
  max_model_len，每个 slot 的上下文就只剩 1/n，长 caption 被截断——
  而截断不报错，只是数据整体变短。
- `--image-max-tokens` 与 `max_pixels` 是两种口径。算错会让换引擎之后
  的图被塞进不同的视觉 token 数，同一批数据出现按引擎分组的伪特征。

这些错都不会让服务起不来，只会让数据悄悄变样，所以必须用断言钉住。
"""

from __future__ import annotations

import types
from pathlib import Path

import pytest

from tagger import nl_engine
from tagger.config import ConfigError


def _profile(**over) -> types.SimpleNamespace:
    base = dict(
        model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                    gguf="models/nl/qwen3vl-8b/a.gguf",
                                    mmproj="models/nl/qwen3vl-8b/mmproj.gguf"),
        max_pixels=589824,
        max_model_len=8192,
        max_num_seqs=4,
        max_num_batched_tokens=0,
        # resolve_weights 现在按精度档挑 gguf（同一份权重三个压缩比是三个文件），
        # 桩里不写这两项，测试会因为 AttributeError 挂掉，看起来像实现坏了。
        precision="q4",
        gguf_quants={},
    )
    base.update(over)
    return types.SimpleNamespace(**base)


@pytest.fixture()
def fake_binary(monkeypatch) -> Path:
    """把 llama-server 指向一个真实存在的文件，绕开"没装"这一层。"""
    binary = Path(__file__).resolve().parent / "_fake_llama_server.exe"
    binary.write_bytes(b"")
    monkeypatch.setenv("TAGGER_LLAMA_SERVER", str(binary))
    try:
        yield binary
    finally:
        binary.unlink(missing_ok=True)


# ------------------------------------------------------------------ 引擎名

def test_engine_aliases_are_normalized():
    # 默认 llama.cpp：Windows 原生唯一能上 GPU 的引擎，也是本项目的
    # 主要使用场景。想要 vLLM 必须显式写——引擎会进指纹，不能靠猜。
    assert nl_engine.normalize_engine(None) == "llamacpp"
    assert nl_engine.normalize_engine("") == "llamacpp"
    assert nl_engine.normalize_engine("llamacpp") == "llamacpp"
    assert nl_engine.normalize_engine("llama.cpp") == "llamacpp"
    assert nl_engine.normalize_engine("GGUF") == "llamacpp"
    assert nl_engine.normalize_engine("vllm") == "vllm"


def test_unknown_engine_is_rejected_with_options():
    with pytest.raises(ConfigError) as err:
        nl_engine.normalize_engine("tensorrt")
    assert "vllm" in str(err.value) and "llamacpp" in str(err.value)


# ------------------------------------------------------------------ 像素预算

def test_max_pixels_converts_to_vision_tokens():
    """589824 像素按 32×32 一个 token = 576，与 vLLM 侧的换算是同一套。"""
    assert nl_engine.image_tokens_for(_profile()) == 576


def test_other_family_refuses_to_guess():
    """换家族这个换算就不成立，宁可报错也不沿用 Qwen 的数字。"""
    p = _profile(model=types.SimpleNamespace(key="kimi", family="moonvit",
                                             gguf="a", mmproj="b"))
    with pytest.raises(ConfigError) as err:
        nl_engine.image_tokens_for(p)
    assert "32×32" in str(err.value) or "32" in str(err.value)


# ------------------------------------------------------------------ 权重解析

def test_missing_gguf_points_at_the_config_field(tmp_path, monkeypatch):
    monkeypatch.setattr(nl_engine, "ROOT", tmp_path)
    p = _profile(model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                             gguf="", mmproj=""))
    with pytest.raises(ConfigError) as err:
        nl_engine.resolve_weights(p)
    msg = str(err.value)
    assert "gguf:" in msg and "mmproj:" in msg
    # 权重 5.8GB，不能让人以为程序会自己下
    assert "modelscope" in msg or "huggingface" in msg


def test_mmproj_missing_is_not_an_optional_file(tmp_path, monkeypatch):
    """缺 mmproj 时服务照起，但每张图都会走纯文本路径——必须当硬错误拦住。"""
    monkeypatch.setattr(nl_engine, "ROOT", tmp_path)
    (tmp_path / "a.gguf").write_bytes(b"x")
    p = _profile(model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                             gguf="a.gguf", mmproj="missing.gguf"))
    with pytest.raises(ConfigError) as err:
        nl_engine.resolve_weights(p)
    assert "mmproj" in str(err.value)


def test_resolve_weights_accepts_absolute_paths(tmp_path, monkeypatch):
    monkeypatch.setattr(nl_engine, "ROOT", tmp_path / "elsewhere")
    gguf, mmproj = tmp_path / "a.gguf", tmp_path / "mm.gguf"
    gguf.write_bytes(b"x")
    mmproj.write_bytes(b"x")
    p = _profile(model=types.SimpleNamespace(key="qwen3vl-8b", family="qwen3vl",
                                             gguf=str(gguf), mmproj=str(mmproj)))
    assert nl_engine.resolve_weights(p) == (gguf, mmproj)


# ------------------------------------------------------------------ 命令行

def test_command_uses_measured_slot_plan(fake_binary, tmp_path):
    """`-c` 是总池 = slot 数 × 每 slot 上下文。

    不能照抄 vLLM 的 max_model_len（那是"最坏情况长上下文"），
    实测按 8192 × slot 数开会把 16GB 显存吃满、decode 崩到 1 tok/s。
    """
    gguf, mmproj = tmp_path / "a.gguf", tmp_path / "mm.gguf"
    gguf.write_bytes(b"x")
    mmproj.write_bytes(b"x")
    cmd = nl_engine.build_command(_profile(max_model_len=8192, max_num_seqs=4),
                                  port=8080, served_name="tagger",
                                  gguf=gguf, mmproj=mmproj, vram_gb=16.0)
    joined = " ".join(cmd)
    assert cmd[0].endswith("_fake_llama_server.exe")
    # 16GB → 12 slot × 3072
    assert "-np 12" in joined, joined
    assert "-c 36864" in joined, joined
    assert "-ctk q8_0" in joined and "-ctv q8_0" in joined
    # 路由名必须与任务表单里的「模型名」一致
    assert "-a tagger" in joined
    assert "--image-max-tokens 576" in joined
    assert "--mmproj" in joined and str(mmproj) in cmd
    assert "--metrics" in joined          # 没有它就只能靠肉眼判断过没过载


def test_slot_plan_follows_vram_tiers():
    """slot 数按显存分档：16G→12、10G→8、7G→4、未知→2。

    这些数字是实测出来的（12 是拐点，16 反而更慢），不是拍的。
    """
    p = _profile()
    assert nl_engine.slot_plan(p, 16.0)[0] == 12
    assert nl_engine.slot_plan(p, 24.0)[0] == 12      # 上限就停在 12
    assert nl_engine.slot_plan(p, 10.0)[0] == 8
    assert nl_engine.slot_plan(p, 7.0)[0] == 4
    assert nl_engine.slot_plan(p, None)[0] == 2       # 不知道就别赌
    assert nl_engine.slot_plan(p, 16.0)[1] == 3072    # 每 slot 上下文


def test_slot_plan_refuses_when_a_slot_cannot_hold_one_request():
    """视觉 token 就吃满上下文时，硬起只会得到被截断的产出。"""
    p = _profile(max_pixels=4 * 589824)        # 视觉 2304 token
    p.max_model_len = 2048
    with pytest.raises(ConfigError) as err:
        nl_engine.slot_plan(p, 16.0)
    assert "装不下" in str(err.value)


def test_missing_binary_is_a_config_error(monkeypatch):
    """找不到 llama-server 时的提示必须给出"下一步能做什么"。

    查找已经挪到 llama_runtime（环境变量 → runtime/llama.cpp → PATH），
    所以这里也 patch 那个模块：直接打 nl_engine.find_server_binary 会绕开
    真实查找顺序，测的就不是用户会碰到的那条路了。
    """
    monkeypatch.delenv("TAGGER_LLAMA_SERVER", raising=False)
    monkeypatch.setattr("tagger.llama_runtime.find_binary", lambda: None)
    with pytest.raises(ConfigError) as err:
        nl_engine.check_engine("llamacpp")
    assert "llama-server" in str(err.value)
    # 报错里要有一键安装这条路，否则用户只能自己去翻 GitHub
    assert "install" in str(err.value)


def test_slot_count_reaches_the_real_command_line(fake_binary):
    """并发数必须来自进程命令行，不是配置。

    profile 里写 8、进程实际开 12，客户端就会只送 8 条在途，
    每台机器白丢约 18% 吞吐——而且指纹会谎报运行参数。
    这条从命令行那一端反查：`-np` 的值必须等于 slot_plan 的决定。
    """
    cmd = nl_engine.build_command(
        _profile(), port=8080, served_name="tagger",
        gguf=Path("a.gguf"), mmproj=Path("m.gguf"),
        vram_gb=16.0, slots_override=12)
    np_value = int(cmd[cmd.index("-np") + 1])
    assert np_value == nl_engine.slot_plan(_profile(), 16.0, 12)[0] == 12
    # KV 量化也是指纹的一部分：它改显存预算，进而改能开几个 slot
    assert cmd[cmd.index("-ctk") + 1] == nl_engine.KV_TYPE


def test_client_concurrency_follows_the_fingerprint():
    """客户端在途数 = 指纹里的 max_num_seqs，否则服务端排队而 GPU 空转。"""
    from tagger.client import resolve_concurrency

    assert resolve_concurrency(None, {"max_num_seqs": 12}) == 12
    assert resolve_concurrency(None, {"max_num_seqs": 64}) == 32   # 上限
    assert resolve_concurrency(None, {}) == 4                      # 缺指纹的保守值
    assert resolve_concurrency(3, {"max_num_seqs": 12}) == 3       # 显式优先


def test_vllm_engine_still_goes_through_model_loader(monkeypatch):
    """vLLM 那一支的判定不能在本层被改口径，必须还走 check_environment。"""
    seen: list[str] = []
    import tagger.model_loader as loader

    monkeypatch.setattr(loader, "check_environment", lambda: seen.append("vllm"))
    nl_engine.check_engine("vllm")
    assert seen == ["vllm"]


# ------------------------------------------------------------------ 槽位（-np）
#
# 槽位是**唯一能让出显存的旋钮**：KV 在启动时按槽位数预留，把任务并发调小
# 只是让 slot 空着。用户在"边打标边玩游戏"时用的就是这个，所以它的三个
# 性质（自动分档、显存随槽位线性、clamp）必须钉住。

def test_slot_tiers_follow_vram():
    assert nl_engine.slot_plan(_profile(), 16.0)[0] == 12
    assert nl_engine.slot_plan(_profile(), 10.0)[0] == 8
    assert nl_engine.slot_plan(_profile(), 8.0)[0] == 4
    # 显存未知时给最保守的值：它只影响吞吐，不影响产出
    assert nl_engine.slot_plan(_profile(), None)[0] == 2


def test_slot_override_clamped():
    assert nl_engine.slot_plan(_profile(), 16.0, 4)[0] == 4
    # 0 与 None 同义：都是"按显存自动"，而不是"开 0 个槽位"
    assert nl_engine.slot_plan(_profile(), 16.0, None)[0] == 12
    assert nl_engine.slot_plan(_profile(), 16.0, 999)[0] == 64
    assert nl_engine.slot_plan(_profile(), 16.0, 1)[0] == 1


def test_kv_memory_scales_with_slots():
    """页面要显示"降槽位能省多少"，所以这个数必须随槽位线性。"""
    one = nl_engine.slot_plan_memory(_profile(), 1)
    four = nl_engine.slot_plan_memory(_profile(), 4)
    twelve = nl_engine.slot_plan_memory(_profile(), 12)
    assert four["kv_total_gib"] > one["kv_total_gib"]
    assert abs(twelve["kv_per_slot_gib"] * 12 - twelve["kv_total_gib"]) < 0.1
    # 12 → 4 要让出接近 2 GiB，否则"腾显存"这件事在页面上说服不了人
    assert twelve["kv_total_gib"] - four["kv_total_gib"] > 1.0
    assert twelve["ctx_total"] == 12 * nl_engine.CTX_PER_SLOT


def test_describe_reports_slots():
    info = nl_engine.describe(_profile(vram_gb=16.0))
    assert info["slots"] == 12
    assert info["slots_manual"] is False
    assert info["slots_default"] == 12
    manual = nl_engine.describe(_profile(vram_gb=16.0), slots_override=4)
    assert manual["slots"] == 4 and manual["slots_manual"] is True


def test_build_command_carries_slot_count(fake_binary):
    cmd = nl_engine.build_command(
        _profile(), port=8080, served_name="tagger",
        gguf=Path("a.gguf"), mmproj=Path("m.gguf"),
        vram_gb=16.0, slots_override=3)
    assert cmd[cmd.index("-np") + 1] == "3"
    # -c 是总池 = 槽位 × 每槽上下文；写成 max_model_len 会让每槽只剩 1/n
    assert cmd[cmd.index("-c") + 1] == str(3 * nl_engine.CTX_PER_SLOT)
