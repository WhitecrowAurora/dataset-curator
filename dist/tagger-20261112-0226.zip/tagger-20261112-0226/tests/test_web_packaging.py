"""数据打包（分包 / 拼接 / 封包）的 web 层守卫。

与 test_web 相同的立场：验的是"编排与契约"，不是数值——分包/拼接/封包的
领域逻辑分别由 test_pipeline / test_merge / test_pack 钉死。这里最值得钉的：

1. 分包表是 image_id 的分配凭证：表已存在必须拒绝，停止时表没写；
2. 拼接停止 = 一张表都不写（半份对账不能落盘）；
3. 一次只跑一个数据任务；参数校验的 400 / 冲突的 409 走对端点。
"""

from __future__ import annotations

import threading
import time

import pytest
from fastapi.testclient import TestClient

from tagger.cpu_tagger import TagPrediction
from tagger.distribute import read_shard_manifest
from tagger.merge import load_shard_plans
from tagger.pack import discover_inputs
from tagger.web import jobs as jobs_mod
from tagger.web import packaging as pkg
from tagger.web.app import create_app
from tagger.web.packaging import (DataJobManager, DataJobStopped, MergeParams,
                                  PackParams, SplitParams, run_merge, run_pack,
                                  run_split)

PNG = b"\x89PNG\r\n\x1a\n"          # 分包不读字节，假 PNG 就够


def _corpus(root, artists=("alpha", "beta"), per=3):
    """两层画师目录的散图语料。返回根目录。"""
    src = root / "in"
    n = 0
    for a in artists:
        d = src / a
        d.mkdir(parents=True, exist_ok=True)
        for _ in range(per):
            (d / f"{n:03d}.png").write_bytes(PNG)
            n += 1
    return src


def _noop_progress(done, total, label):
    pass


def _wait_job(job, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline and job.status in ("pending", "running"):
        time.sleep(0.02)
    return job


# ------------------------------------------------------------------ run_split


def test_run_split_writes_packages_and_table(tmp_path):
    src = _corpus(tmp_path)
    params = SplitParams(input_dir=str(src), per_shard=2,
                         out_dir=str(tmp_path / "out"),
                         table=str(tmp_path / "t.json"))
    progress = []
    summary = run_split(params, on_progress=lambda d, t, l: progress.append(d),
                        should_stop=lambda: False, on_log=lambda m: None)

    assert summary["package_count"] == 3          # 6 张 / 每包 2
    assert summary["total"] == 6
    assert summary["no_artist"] == 0              # 第一层目录就是画师名
    assert summary["verify"] == {"checked": 3, "bad": 0}
    assert [d for d, _ in zip(progress, range(4))] == [0, 1, 2, 3]

    out = tmp_path / "out"
    zips = sorted(out.glob("dist-*.zip"))
    assert len(zips) == 3
    table_path = tmp_path / "t.json"
    assert table_path.is_file()

    # 表与包对账：首尾 id、条数逐包一致
    for row in load_shard_plans(table_path):
        rows = read_shard_manifest(out / row["name"])
        assert len(rows) == row["count"]
        assert rows[0]["image_id"] == row["first_id"]
        assert rows[-1]["image_id"] == row["last_id"]


def test_run_split_excludes_listed_keys(tmp_path):
    src = _corpus(tmp_path, artists=("alpha",), per=3)
    key = discover_inputs(str(src))[0].key        # 散图的 key 就是自身路径
    excl = tmp_path / "dedup-exclude.txt"
    excl.write_text(f"# 注释行\n{key}\n", encoding="utf-8")

    params = SplitParams(input_dir=str(src), exclude=str(excl), per_shard=10,
                         out_dir=str(tmp_path / "out"),
                         table=str(tmp_path / "t.json"))
    summary = run_split(params, on_progress=_noop_progress,
                        should_stop=lambda: False, on_log=lambda m: None)
    assert summary["excluded"] == 1
    assert summary["total"] == 2
    assert summary["discovered"] == 3


def test_run_split_refuses_existing_table(tmp_path):
    src = _corpus(tmp_path, artists=("alpha",), per=2)
    params = SplitParams(input_dir=str(src), per_shard=10,
                         out_dir=str(tmp_path / "out"),
                         table=str(tmp_path / "t.json"))
    run_split(params, on_progress=_noop_progress,
              should_stop=lambda: False, on_log=lambda m: None)
    with pytest.raises(ValueError, match="分包表已存在"):
        run_split(params, on_progress=_noop_progress,
                  should_stop=lambda: False, on_log=lambda m: None)


def test_run_split_stop_leaves_table_unwritten(tmp_path):
    src = _corpus(tmp_path, artists=("alpha",), per=4)   # 每包 2 → 2 个包
    params = SplitParams(input_dir=str(src), per_shard=2,
                         out_dir=str(tmp_path / "out"),
                         table=str(tmp_path / "t.json"))
    state = {"done": 0}

    def progress(done, total, label):
        if done:
            state["done"] = done

    with pytest.raises(DataJobStopped):
        run_split(params, on_progress=progress,
                  should_stop=lambda: state["done"] >= 1, on_log=lambda m: None)

    # 第一个包已落盘（停止语义：已写的保留），但分配凭证没写——
    # 重跑从头分配，不会留下"表说这批是 A、包里装的是 B"的错位。
    assert len(list((tmp_path / "out").glob("dist-*.zip"))) == 1
    assert not (tmp_path / "t.json").exists()


# ------------------------------------------------------------------ run_merge


def _split_three(tmp_path):
    """3 张图切成 2 个包（2+1），返回 (ids, out_dir, table)。"""
    src = _corpus(tmp_path, artists=("alpha",), per=3)
    out = tmp_path / "out"
    table = tmp_path / "t.json"
    run_split(SplitParams(input_dir=str(src), per_shard=2,
                          out_dir=str(out), table=str(table)),
              on_progress=_noop_progress, should_stop=lambda: False,
              on_log=lambda m: None)
    ids: list[str] = []
    for z in sorted(out.glob("dist-*.zip")):
        ids.extend(r["image_id"] for r in read_shard_manifest(z))
    return ids, out, table


def test_run_merge_reconciles_missing_and_empty_roots(tmp_path, write_artifact):
    ids, out, table = _split_three(tmp_path)
    # m1 只交了第一条；m2 一个目录建了但空着；m3 根本不存在
    m1 = tmp_path / "m1"
    write_artifact(m1, ids[0], tag="red, square", caption="a red square")
    (tmp_path / "m2").mkdir()

    params = MergeParams(roots=[str(m1), str(tmp_path / "m2"), str(tmp_path / "m3")],
                         shard_dir=str(out), table=str(table),
                         out=str(tmp_path / "merged.jsonl"),
                         sample_out=str(tmp_path / "sample.md"), sample_n=2)
    progress = []
    summary = run_merge(params, on_progress=lambda d, t, l: progress.append(d),
                        should_stop=lambda: False, on_log=lambda m: None)

    assert summary["expected"] == 3
    assert summary["found"] == 1
    assert summary["complete"] == 1
    assert summary["missing_n"] == 2
    assert len(summary["empty_roots"]) == 2        # 空目录 + 不存在的目录
    assert summary["failed"] is True
    # 整包没交：第二个包（1 条）整包缺失；第一个包短 1 条
    assert len(summary["whole_missing"]) == 1
    assert summary["whole_missing"][0]["expected"] == 1
    assert len(summary["short"]) == 1
    assert summary["short"][0]["got"] == 1
    # 总表只写完整的 1 条；抽检清单落盘
    assert summary["written"] == 1
    assert (tmp_path / "merged.jsonl").is_file()
    assert summary["sample_count"] == 1            # 完整的只有 1 条，抽样取整
    assert (tmp_path / "sample.md").is_file()
    assert progress and progress[-1] >= 2          # collect 的逐文件计数


def test_run_merge_flags_content_conflicts(tmp_path, write_artifact):
    ids, out, table = _split_three(tmp_path)
    m1, m2 = tmp_path / "m1", tmp_path / "m2"
    for i in ids:
        write_artifact(m1, i, tag="red", caption="a red square")
    write_artifact(m2, ids[0], tag="blue", caption="a blue square")

    params = MergeParams(roots=[str(m1), str(m2)],
                         out=str(tmp_path / "merged.jsonl"), sample_n=0)
    summary = run_merge(params, on_progress=_noop_progress,
                        should_stop=lambda: False, on_log=lambda m: None)
    assert summary["duplicates_n"] == 1
    assert summary["failed"] is True
    assert summary["written"] == 3                 # 先到的留在 records，人工裁决


def test_run_merge_stop_writes_nothing(tmp_path, write_artifact):
    ids, out, table = _split_three(tmp_path)
    m1 = tmp_path / "m1"
    for i in ids:
        write_artifact(m1, i, tag="red", caption="a red square")

    calls = {"n": 0}

    def should_stop():
        calls["n"] += 1
        return calls["n"] > 1

    params = MergeParams(roots=[str(m1)], out=str(tmp_path / "merged.jsonl"),
                         sample_n=2, sample_out=str(tmp_path / "sample.md"))
    with pytest.raises(DataJobStopped):
        run_merge(params, on_progress=_noop_progress,
                  should_stop=should_stop, on_log=lambda m: None)
    assert not (tmp_path / "merged.jsonl").exists()
    assert not (tmp_path / "sample.md").exists()


# ------------------------------------------------------------------ run_pack


def _plan_ids(tmp_path):
    """与 run_pack 同参跑一遍 plan_inputs，拿到确定的 image_id。"""
    from tagger.artist import AliasTable
    from tagger.config import DEFAULT_TIERS, load_ops, load_tier_table
    from tagger.pipeline import plan_inputs

    ops = load_ops(load_tier_table(DEFAULT_TIERS))
    rule = ops.artist_rule()
    rule.enabled = True
    aliases = AliasTable(rule.aliases_path).as_dict() if rule.aliases_path else {}
    plan = plan_inputs(str(tmp_path / "in"), assign_ids=True,
                       artist_rule=rule, aliases=aliases)
    return [it.image_id for it in plan.items]


def test_run_pack_seals_and_counts_missing(tmp_path, make_png, write_artifact):
    src = tmp_path / "in" / "alpha"
    src.mkdir(parents=True)
    for i in range(3):
        (src / f"{i}.png").write_bytes(make_png())     # 封包要真重编码

    out = tmp_path / "out"
    ids = _plan_ids(tmp_path)
    for i in ids[:2]:
        write_artifact(out / "tags", i, tag="red, square", caption="a red square")
    # 第三个缺 tag 产物 → skipped_missing

    logs = []
    params = PackParams(input_dir=str(tmp_path / "in"), out_dir=str(out),
                        formats=["zip"], max_records=2, check_space=False,
                        assign_ids=True)
    progress = []
    summary = run_pack(params, on_progress=lambda d, t, l: progress.append(d),
                       should_stop=lambda: False, on_log=logs.append)

    assert summary["packed"] == 2
    assert summary["skipped_missing"] == 1
    assert summary["skipped_done"] == 0
    assert summary["failed"] == 0
    assert summary["sealed_count"] == 1            # 2 条 / 每包 2
    assert len(list(out.glob("pack-*.zip"))) == 1
    assert progress == [0, 1, 2]


def test_run_pack_relative_ids_match_tag_only_artifacts(tmp_path, make_png, write_artifact):
    """本机「新建任务」只打标的产物：id 是相对路径，pack 要用同一套口径。"""
    src = tmp_path / "in" / "alpha"
    src.mkdir(parents=True)
    (src / "000.png").write_bytes(make_png())
    (src / "001.png").write_bytes(make_png())

    out = tmp_path / "out"
    tags = out / "tags"
    (tags / "alpha").mkdir(parents=True)           # 相对路径 id 按层级铺开
    # 只打标任务的 id 是去扩展名的相对路径（_legacy_id）
    write_artifact(tags, "alpha/000", tag="red", caption="a red square")
    # 第二张不打 → skipped_missing

    params = PackParams(input_dir=str(tmp_path / "in"), out_dir=str(out),
                        formats=["zip"], check_space=False, assign_ids=False)
    summary = run_pack(params, on_progress=_noop_progress,
                       should_stop=lambda: False, on_log=lambda m: None)
    assert summary["packed"] == 1
    assert summary["skipped_missing"] == 1


def test_run_pack_space_error_is_clean(tmp_path, make_png, monkeypatch):
    src = tmp_path / "in" / "alpha"
    src.mkdir(parents=True)
    (src / "0.png").write_bytes(make_png())

    import tagger.pipeline as pipeline_mod

    def boom(*args, **kwargs):
        raise pipeline_mod.PackSpaceError("只剩 1 GB，预计要 5 GB")

    monkeypatch.setattr(pipeline_mod, "pack_items", boom)
    params = PackParams(input_dir=str(tmp_path / "in"),
                        out_dir=str(tmp_path / "out"), check_space=True)
    with pytest.raises(ValueError, match="磁盘不够"):
        run_pack(params, on_progress=_noop_progress,
                 should_stop=lambda: False, on_log=lambda m: None)


# ------------------------------------------------------------------ 管理器


def test_manager_rejects_bad_kind_and_unknown_params(tmp_path):
    mgr = DataJobManager()
    with pytest.raises(ValueError, match="未知"):
        mgr.create("nope", {})
    with pytest.raises(ValueError, match="未知参数"):
        mgr.create("split", {"input_dir": str(tmp_path), "wat": 1})


def test_manager_success_failure_and_one_at_a_time(monkeypatch, tmp_path):
    mgr = DataJobManager()
    monkeypatch.setitem(pkg.RUNNERS, "split",
                        lambda p, **kw: {"total": 6})
    job = _wait_job(mgr.create("split", {"input_dir": str(tmp_path)}))
    assert job.status == "done"
    assert job.summary == {"total": 6}

    def failing(params, *, on_progress, should_stop, on_log):
        raise RuntimeError("炸了")

    monkeypatch.setitem(pkg.RUNNERS, "pack", failing)
    job = _wait_job(mgr.create("pack", {"input_dir": str(tmp_path)}))
    assert job.status == "failed"
    assert "炸了" in job.error

    gate = threading.Event()
    release = threading.Event()

    def slow(params, *, on_progress, should_stop, on_log):
        release.set()
        gate.wait(3)
        if should_stop():
            raise DataJobStopped()
        return {}

    monkeypatch.setitem(pkg.RUNNERS, "merge", slow)
    job = mgr.create("merge", {"roots": [str(tmp_path)]})
    assert release.wait(3)
    with pytest.raises(RuntimeError, match="已有数据任务"):
        mgr.create("split", {"input_dir": str(tmp_path)})
    assert mgr.stop(job.id) is True
    _wait_job(job)
    assert job.status == "stopped"
    assert mgr.stop(job.id) is False               # 已结束，不能再停


# ------------------------------------------------------------------ 端点


class _FakeBackend:
    name = "fake"
    precision = "bf16"
    batch_size = 1

    def __init__(self):
        self.last_timings = {"total": 5, "decode": 2, "forward": 2}

    def load(self):
        return None

    def predict_batch(self, images):
        return [TagPrediction(tags=[("red", 0.9)], backend="fake",
                              rating={"general": 0.6}) for _ in images]


@pytest.fixture
def client(monkeypatch, tmp_path):
    jobs_mod.MANAGER._jobs.clear()
    pkg.DATAJOBS._jobs.clear()
    monkeypatch.setattr(jobs_mod, "build_backend",
                        lambda *a, **kw: _FakeBackend())
    monkeypatch.setattr(jobs_mod, "resolve_device", lambda s: "cpu")
    monkeypatch.setattr(jobs_mod.JobManager, "_make_guard",
                        lambda self, job: None)
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def _wait_endpoint(client, job_id, timeout=8.0):
    deadline = time.time() + timeout
    snap = {}
    while time.time() < deadline:
        snap = client.get(f"/api/datajob/{job_id}").json()
        if snap["status"] in ("done", "failed", "stopped"):
            return snap
        time.sleep(0.05)
    raise AssertionError(f"数据任务没在 {timeout}s 内结束：{snap}")


def test_datajob_endpoints_split_lifecycle(client, tmp_path):
    src = _corpus(tmp_path, artists=("alpha",), per=2)
    body = {"kind": "split", "params": {
        "input_dir": str(src), "per_shard": 10,
        "out_dir": str(tmp_path / "out"), "table": str(tmp_path / "t.json")}}
    resp = client.post("/api/datajob/start", json=body)
    assert resp.status_code == 202
    job_id = resp.json()["id"]

    snap = _wait_endpoint(client, job_id)
    assert snap["status"] == "done"
    assert snap["summary"]["total"] == 2
    assert (tmp_path / "t.json").is_file()

    # 同一张表再跑 → 400（image_id 分配凭证）
    resp = client.post("/api/datajob/start", json=body)
    assert resp.status_code == 400
    assert "分包表已存在" in resp.json()["detail"]

    # 列表里能看到这次任务
    jobs = client.get("/api/datajob").json()["jobs"]
    assert any(j["id"] == job_id for j in jobs)


def test_datajob_endpoints_validation_and_missing(client, tmp_path):
    assert client.post("/api/datajob/start",
                       json={"kind": "nope", "params": {}}).status_code == 400
    assert client.post("/api/datajob/start",
                       json={"kind": "split",
                             "params": {"input_dir": str(tmp_path / "gone")}
                             }).status_code == 400
    assert client.post("/api/datajob/start",
                       json={"kind": "split",
                             "params": {"input_dir": str(tmp_path), "wat": 1}
                             }).status_code == 400
    assert client.get("/api/datajob/unknown").status_code == 404
    assert client.post("/api/datajob/unknown/stop").status_code == 409


def test_datajob_preview_endpoint(client, tmp_path):
    src = _corpus(tmp_path, artists=("alpha", "beta"), per=2)
    body = {"input_dir": str(src)}
    data = client.post("/api/datajob/preview", json=body).json()
    assert data["total"] == 4
    assert data["artists"] == {"count": 2, "covered": 4, "missing": 0}
    assert {s["name"] for s in data["sources"]} == {str(src / "alpha"),
                                                    str(src / "beta")}

    # 预览与排除清单同口径
    key = discover_inputs(str(src))[0].key
    excl = tmp_path / "dedup-exclude.txt"
    excl.write_text(key + "\n", encoding="utf-8")
    data = client.post("/api/datajob/preview",
                       json={"input_dir": str(src), "exclude": str(excl)}).json()
    assert data["excluded"] == 1
    assert data["total"] == 4                      # 预览列出全集，排除单列

    assert client.post("/api/datajob/preview",
                       json={"input_dir": str(tmp_path / "gone")}
                       ).status_code == 400
    assert client.post("/api/datajob/preview",
                       json={"input_dir": str(src), "kind": "pack"}
                       ).status_code == 400
