"""精度/批处理这一层的测试。

这些用例**不需要 torch**：所有涉及前向的地方都换成假后端，
测的是"参数怎么落、批怎么攒、结果怎么对位"，不是数值。
数值口径由 devtools/verify_dtype.py 在真权重上验（见 perf-baseline.md）。
"""

from __future__ import annotations

import time

import pytest


# ------------------------------------------------------------------ 精度归一


def test_normalize_precision_aliases():
    from tagger.cpu_tagger import normalize_precision

    assert normalize_precision(None) == "fp32"
    assert normalize_precision("") == "fp32"
    assert normalize_precision("FP32") == "fp32"
    assert normalize_precision("bfloat16") == "bf16"
    assert normalize_precision(" tf32 ") == "tf32"
    assert normalize_precision("float32") == "fp32"


def test_normalize_precision_rejects_unknown():
    from tagger.cpu_tagger import normalize_precision

    with pytest.raises(ValueError, match="未知精度"):
        normalize_precision("int8")


def test_backend_defaults_keep_old_behaviour():
    """不给新参数时，precision/batch 必须是"等价于没开"的值。"""
    from tagger.cpu_tagger import TagBackend

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):  # noqa: D103
            self._ready = True

        def _predict_one(self, image):
            return {"a": 0.5}

    b = _Fake()
    assert b.precision == "fp32"
    assert b.batch_size == 1


def test_backend_batch_size_is_at_least_one():
    from tagger.cpu_tagger import TagBackend

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            return {}

    assert _Fake(batch_size=0).batch_size == 1
    assert _Fake(batch_size=-3).batch_size == 1


# ------------------------------------------------------------------ 批处理接口


class _CountingBackend:
    """假后端：记录每次 _predict_many 收到几张，输出可预测且按张不同。"""

    name = "counting"

    def __init__(self, calls: list[int], precision: str = "fp32", batch_size: int = 1):
        self.calls = calls
        self.precision = precision
        self.batch_size = batch_size

    def predict_batch(self, images):
        from tagger.cpu_tagger import TagPrediction

        self.calls.append(len(images))
        out = []
        for i, _ in enumerate(images):
            out.append(TagPrediction(tags=[(f"t{i}", 0.9)], backend=self.name))
        return out


def test_predict_batch_default_falls_back_to_one_by_one():
    """基类默认实现必须逐张跑：pixai / onnx 没覆写 _predict_many，
    加了这个接口之后它们的行为不能有任何变化。"""
    from tagger.cpu_tagger import TagBackend

    seen: list[int] = []

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            seen.append(image)
            return {"tag%d" % image: 0.5}

    b = _Fake()
    preds = b.predict_batch([1, 2, 3])
    assert seen == [1, 2, 3]
    assert [p.tags for p in preds] == [[("tag1", 0.5)], [("tag2", 0.5)], [("tag3", 0.5)]]


def test_predict_batch_postprocess_matches_predict():
    """批路径与单张路径的后处理必须一字不差：降序、四舍五入到 4 位、max_tags 截断。"""
    from tagger.cpu_tagger import TagBackend

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            return {"b": 0.12345678, "a": 0.9, "c": 0.55}

    b_single = _Fake(max_tags=2)
    b_batch = _Fake(max_tags=2)
    single = b_single.predict("x")
    batched = b_batch.predict_batch(["x"])[0]
    # 降序后取前 2 个：a(0.9) 与 c(0.55)；概率四舍五入到 4 位
    assert single.tags == batched.tags == [("a", 0.9), ("c", 0.55)]


def test_predict_batch_empty_input_is_noop():
    from tagger.cpu_tagger import TagBackend

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            return {"a": 0.5}

    assert _Fake().predict_batch([]) == []


# ------------------------------------------------------------------ 工厂透传


def test_build_backend_passes_precision_and_batch():
    from tagger.cpu_tagger import build_backend

    obj = build_backend("wd-eva02", precision="bf16", batch_size=8, verbose=False)
    assert obj is not None
    assert obj.precision == "bf16"
    assert obj.batch_size == 8


def test_build_backend_rejects_unknown_precision():
    from tagger.cpu_tagger import build_backend

    with pytest.raises(ValueError, match="未知精度"):
        build_backend("wd-eva02", precision="int8", verbose=False)


def test_build_backend_none_returns_none():
    from tagger.cpu_tagger import build_backend

    assert build_backend("none") is None


# ------------------------------------------------------------------ 攒批执行器


def test_batch_executor_returns_results_in_submit_order():
    from tagger.client import _BatchTagExecutor

    ex = _BatchTagExecutor(lambda batch: [[(f"t{n}", 0.5)] for n in batch],
                           max_batch=4)
    try:
        futs = [ex.submit(i) for i in range(6)]
        results = [f.result(timeout=5) for f in futs]
    finally:
        ex.shutdown(wait=True)
    # 顺序必须与提交顺序一致（results 是逐张的 tag 列表，错位会污染产物）
    assert results == [[("t0", 0.5)], [("t1", 0.5)], [("t2", 0.5)],
                       [("t3", 0.5)], [("t4", 0.5)], [("t5", 0.5)]]


def test_batch_executor_actually_gathers_and_honours_max_batch():
    """worker 忙的时候，后面的提交必须被攒进同一次调用——这是 batch 唯一的意义。"""
    from tagger.client import _BatchTagExecutor

    sizes: list[int] = []

    def fn(batch):
        sizes.append(len(batch))
        time.sleep(0.02)
        return [[] for _ in batch]

    ex = _BatchTagExecutor(fn, max_batch=4)
    try:
        futs = []
        for i in range(8):
            futs.append(ex.submit(f"img{i}"))
            time.sleep(0.005)
        for f in futs:
            f.result(timeout=5)
    finally:
        ex.shutdown(wait=True)

    assert max(sizes) > 1, f"没有攒批，实际每批 {sizes}"
    assert max(sizes) <= 4
    assert sum(sizes) == 8


def test_batch_executor_with_max_batch_one_never_batches():
    from tagger.client import _BatchTagExecutor

    sizes: list[int] = []
    ex = _BatchTagExecutor(lambda batch: (sizes.append(len(batch)), [[] for _ in batch])[1],
                           max_batch=1)
    try:
        for i in range(4):
            ex.submit(i).result(timeout=5)
    finally:
        ex.shutdown(wait=True)
    assert sizes == [1, 1, 1, 1]


def test_batch_executor_propagates_error_to_every_future():
    from tagger.client import _BatchTagExecutor

    def boom(batch):
        raise RuntimeError("模型炸了")

    ex = _BatchTagExecutor(boom, max_batch=4)
    try:
        futs = [ex.submit(f"img{i}") for i in range(3)]
        for f in futs:
            with pytest.raises(RuntimeError, match="模型炸了"):
                f.result(timeout=5)
    finally:
        ex.shutdown(wait=True)


def test_batch_executor_rejects_short_result():
    """后端少返回一张必须报错，不能把结果错位地发给别人——
    tag 错位会静默污染产物，比崩掉更糟。"""
    from tagger.client import _BatchTagExecutor

    ex = _BatchTagExecutor(lambda batch: [], max_batch=1)
    try:
        with pytest.raises(RuntimeError, match="返回 0 条"):
            ex.submit("img").result(timeout=5)
    finally:
        ex.shutdown(wait=True)


def test_batch_executor_submit_after_shutdown_fails_cleanly():
    from tagger.client import _BatchTagExecutor

    ex = _BatchTagExecutor(lambda batch: [[] for _ in batch], max_batch=1)
    ex.shutdown(wait=True)
    with pytest.raises(RuntimeError, match="已关闭"):
        ex.submit("img").result(timeout=5)


# ------------------------------------------------------------------ 解码入口

def test_open_rgb_accepts_bytes_and_skips_rgb_copy():
    """后端要能吃原始字节，且已经是 RGB 的图不再复制。

    客户端原来先 decode+convert 一遍、后端 `_open_rgb` 再 convert 一遍，
    1024² 上是每张白付几毫秒；PIL 的 convert 即使在 RGB 上也会整幅复制。
    """
    from io import BytesIO

    from PIL import Image

    from tagger.cpu_tagger import TagBackend

    im = Image.new("RGB", (32, 24), (10, 20, 30))
    assert TagBackend._open_rgb(im) is im

    buf = BytesIO()
    im.save(buf, "PNG")
    got = TagBackend._open_rgb(buf.getvalue())
    assert isinstance(got, Image.Image)
    assert got.mode == "RGB" and got.size == (32, 24)


def test_open_rgb_converts_non_rgb():
    from PIL import Image

    from tagger.cpu_tagger import TagBackend

    got = TagBackend._open_rgb(Image.new("L", (8, 8), 128))
    assert got.mode == "RGB"


def test_predict_batch_accepts_raw_bytes():
    from io import BytesIO

    from PIL import Image

    from tagger.cpu_tagger import TagBackend

    seen: list[tuple[int, int]] = []

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            img = self._open_rgb(image)
            seen.append(img.size)
            return {"ok": 0.9}

    buf = BytesIO()
    Image.new("RGB", (16, 12), (0, 0, 0)).save(buf, "PNG")
    preds = _Fake().predict_batch([buf.getvalue()])
    assert seen == [(16, 12)]
    assert preds[0].tags == [("ok", 0.9)]


# ------------------------------------------------------------------ CUDA Graph

def test_graph_is_off_for_cpu_and_batch_one():
    """图只在 CUDA + batch>1 下有意义；其余情况必须干净地不建。"""
    from tagger.cpu_tagger import build_backend

    cpu = build_backend("wd-eva02", device="cpu", batch_size=4, verbose=False)
    cpu._maybe_capture_graph(448)
    assert cpu._graph is None

    one = build_backend("wd-eva02", device="cpu", batch_size=1, verbose=False)
    one._maybe_capture_graph(448)
    assert one._graph is None


def test_use_graph_can_be_disabled():
    from tagger.cpu_tagger import build_backend

    b = build_backend("wd-eva02", use_graph=False, verbose=False)
    assert b.use_graph is False
    b._maybe_capture_graph(448)
    assert b._graph is None


# ---------------------------------------------------------------- 解码预取

def test_prefetch_defaults_on_and_can_be_disabled():
    """开关必须从工厂透传到后端；漏传时 TypeError 会直接把启动打断。"""
    from tagger.cpu_tagger import build_backend

    assert build_backend("wd-eva02", verbose=False).prefetch is True
    assert build_backend("wd-eva02", prefetch=False, verbose=False).prefetch is False


def test_prefetch_is_skipped_on_cpu():
    """CPU 上解码与前向抢同一批核，重叠只会互相拖，所以必须退回串行。"""
    import threading

    from tagger.cpu_tagger import build_backend

    b = build_backend("wd-eva02", device="cpu", batch_size=2,
                      prefetch=True, verbose=False)
    threads: list[str] = []

    def fake_decode(part):
        threads.append(threading.current_thread().name)
        return list(part), 0

    def fake_forward(tensors):
        return [{"ok": float(t)} for t in tensors], [], 0

    b._decode_batch = fake_decode
    b._forward_chunk = fake_forward

    out = b._predict_many([1, 2, 3, 4])
    assert out == [{"ok": 1.0}, {"ok": 2.0}, {"ok": 3.0}, {"ok": 4.0}]
    assert len(threads) == 2
    assert not any(t.startswith("tag-prefetch") for t in threads)


# ------------------------------------------------------------------ 词表校验

def _write_csv(path, rows: list[tuple]):
    lines = ["tag_id,name,category,count"]
    for tag_id, name, cat in rows:
        lines.append(f"{tag_id},{name},{cat},100")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def test_read_wd_tags_accepts_well_formed_csv(tmp_path):
    from tagger.cpu_tagger import _read_wd_tags

    p = _write_csv(tmp_path / "t.csv", [(0, "1girl", 0), (1, "hatsune_miku", 4),
                                        (2, "general", 9)])
    names, cats = _read_wd_tags(p, model_id="m")
    assert names == ["1girl", "hatsune_miku", "general"]
    assert cats == ["general", "character", "rating"]


def test_read_wd_tags_rejects_gap_in_tag_id(tmp_path):
    """tag_id 不连续 = 词表与分类头错位，必须报错而不是补空名字。

    以前这里是"按 id 落位、中间补空字符串"，补出来的空名会一路传到产物里。
    """
    from tagger.cpu_tagger import TaggerUnavailable, _read_wd_tags

    p = _write_csv(tmp_path / "t.csv", [(0, "1girl", 0), (2, "hatsune_miku", 4)])
    with pytest.raises(TaggerUnavailable, match="tag_id 不连续"):
        _read_wd_tags(p, model_id="m")


def test_read_wd_tags_rejects_empty_name(tmp_path):
    from tagger.cpu_tagger import TaggerUnavailable, _read_wd_tags

    p = _write_csv(tmp_path / "t.csv", [(0, "1girl", 0), (1, "", 0)])
    with pytest.raises(TaggerUnavailable, match="没有 name"):
        _read_wd_tags(p, model_id="m")


def test_vocab_must_match_head_width(tmp_path):
    """csv 行数 != num_classes 时，zip 会静默截断/错位，必须提前挡住。"""
    from tagger.cpu_tagger import TaggerUnavailable, _check_vocab_against_head

    csv = tmp_path / "t.csv"
    _check_vocab_against_head(16473, 16473, csv_path=csv, model_id="m")

    with pytest.raises(TaggerUnavailable, match="对不上"):
        _check_vocab_against_head(16472, 16473, csv_path=csv, model_id="m")
    with pytest.raises(TaggerUnavailable, match="对不上"):
        _check_vocab_against_head(16474, 16473, csv_path=csv, model_id="m")
    with pytest.raises(TaggerUnavailable, match="num_classes"):
        _check_vocab_against_head(16473, 0, csv_path=csv, model_id="m")


# ------------------------------------------------------------------ rating

def test_rating_plan_only_picks_rating_rows():
    """rating 要按"不过阈值"单独取：它是四个独立分数的相对大小。"""
    from tagger.cpu_tagger import WDEva02Tagger

    b = WDEva02Tagger()
    b._names = ["1girl", "general", "sensitive", "explicit"]
    b._categories = ["general", "rating", "rating", "rating"]
    assert [i for i, _ in b._rating_plan()] == [1, 2, 3]

    # 默认 keep 不含 rating，所以这些行不会进 tag 串
    assert "rating" not in b.keep


def test_rating_plan_is_cached():
    from tagger.cpu_tagger import WDEva02Tagger

    b = WDEva02Tagger()
    b._names = ["general"]
    b._categories = ["rating"]
    first = b._rating_plan()
    assert b._rating_plan() is first


# ------------------------------------------------------------------ 耗时拆分

def test_last_timings_reports_total_when_backend_has_no_split():
    """没拆分的后端（pixai/onnx）不能凭空编解码占比，全部计入 forward。"""
    from tagger.cpu_tagger import TagBackend

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            return {"a": 0.5}

    b = _Fake()
    b.predict_batch(["x"])
    assert b.last_timings["decode"] == 0
    assert b.last_timings["forward"] == b.last_timings["total"] >= 0


def test_last_timings_uses_split_reported_by_subclass():
    from tagger.cpu_tagger import TagBackend

    class _Split(TagBackend):
        name = "split"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            return {"a": 0.5}

        def _predict_many(self, images):
            self._split_ms = (30, 12)
            return [{"a": 0.5} for _ in images]

    b = _Split()
    b.predict_batch(["x", "y"])
    assert b.last_timings["decode"] == 30
    assert b.last_timings["forward"] == 12
    assert b.last_timings["total"] >= 0


# ------------------------------------------------------------------ 预处理位置
# pil = 现状（PIL 缩放/归一化，CPU）；tensor = 缩放/归一化上卡。
# 这里只测"参数怎么落、transform 认不认得出、两条路的像素差有多大"，
# 真权重上的 tag 差异见 devtools/perf-baseline.md §12。


def test_normalize_preprocess_aliases():
    from tagger.cpu_tagger import normalize_preprocess

    assert normalize_preprocess(None) == "pil"
    assert normalize_preprocess("") == "pil"
    assert normalize_preprocess(" PIL ") == "pil"
    assert normalize_preprocess("CPU") == "pil"
    assert normalize_preprocess("gpu") == "tensor"
    assert normalize_preprocess("cuda") == "tensor"
    assert normalize_preprocess("tensor_gpu") == "tensor"


def test_normalize_preprocess_rejects_unknown():
    from tagger.cpu_tagger import normalize_preprocess

    with pytest.raises(ValueError, match="未知预处理"):
        normalize_preprocess("npu")


def test_default_preprocess_is_pil():
    """不显式开就是现状，老档老结果不受影响。"""
    from tagger.cpu_tagger import TagBackend

    class _Fake(TagBackend):
        name = "fake"

        def _load(self):
            self._ready = True

        def _predict_one(self, image):
            return {}

    assert _Fake().preprocess == "pil"
    assert _Fake(preprocess="tensor").preprocess == "tensor"


def _compose(torch, T, resize, crop=448, with_norm=True, interp=None):
    interp = interp or T.InterpolationMode.BICUBIC
    ops = [T.Resize(resize, interpolation=interp)]
    if crop:
        ops.append(T.CenterCrop(crop))
    ops.append(T.ToTensor())
    if with_norm:
        ops.append(T.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]))
    return T.Compose(ops)


def test_tensor_prep_plan_reads_squash_and_center():
    pytest.importorskip("torch")
    T = pytest.importorskip("torchvision.transforms")
    from tagger.cpu_tagger import _tensor_prep_plan

    squash = _tensor_prep_plan(_compose(None, T, (448, 448)))
    assert squash.resize == (448, 448)
    assert squash.crop == (448, 448)
    assert squash.mode == "bicubic"

    center = _tensor_prep_plan(_compose(None, T, 512))
    assert center.resize is None
    assert center.short_edge == 512
    assert center.crop == (448, 448)


def test_tensor_prep_plan_gives_up_on_unsupported():
    """认不出来必须返回 None（回落 PIL），不允许猜一套近似口径。"""
    pytest.importorskip("torch")
    T = pytest.importorskip("torchvision.transforms")
    from tagger.cpu_tagger import _tensor_prep_plan

    rand = T.Compose([T.RandomResizedCrop(448), T.ToTensor(),
                      T.Normalize([0.5] * 3, [0.5] * 3)])
    assert _tensor_prep_plan(rand) is None

    lanczos = _compose(None, T, (448, 448), interp=T.InterpolationMode.LANCZOS)
    assert _tensor_prep_plan(lanczos) is None

    no_norm = _compose(None, T, (448, 448), with_norm=False)
    assert _tensor_prep_plan(no_norm) is None


def test_prep_on_device_matches_pil_transform():
    """两条路的重采样实现不同，但同一张平滑图要几乎一致（CPU 上就能验）。"""
    torch = pytest.importorskip("torch")
    T = pytest.importorskip("torchvision.transforms")
    image_mod = pytest.importorskip("PIL.Image")
    np = pytest.importorskip("numpy")
    from tagger.cpu_tagger import WDEva02Tagger, _tensor_prep_plan

    transform = _compose(torch, T, (448, 448))
    backend = WDEva02Tagger(device="cpu", verbose=False)
    backend._tensor_prep = _tensor_prep_plan(transform)
    assert backend._tensor_prep is not None

    yy, xx = np.mgrid[0:120, 0:160]
    pixels = np.stack([(xx * 255 // 160), (yy * 255 // 120),
                       ((xx + yy) * 255 // 280)], axis=2).astype(np.uint8)
    image = image_mod.fromarray(pixels)

    out = backend._prep_on_device(backend._pixels_uint8(image))
    ref = transform(image)
    assert out.shape == ref.shape == (3, 448, 448)
    assert out.dtype == torch.float32
    # 平滑图上的核差异只在边缘几个像素，阈值按实测留 3× 余量
    assert float((out - ref).abs().max()) < 0.05
    assert float((out - ref).abs().mean()) < 0.01
