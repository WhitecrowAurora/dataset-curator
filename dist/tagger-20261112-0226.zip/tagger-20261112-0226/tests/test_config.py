"""配置口径的守卫。

这些断言看着琐碎，但每条都对应一个真实会犯的错：下限被改回 8、区间写反、
质检的字符线跟 token 预算脱钩、报告批次退化成常量。
"""

from __future__ import annotations

import pytest

from tagger.config import (ConfigError, OpsConfig, OutputSpec, load_ops,
                           load_tier_table, resolve_buckets)
from tagger.pack import PackOptions


# ------------------------------------------------------------------ 产出规格


def test_tag_floor_is_twelve():
    """下限 12 是主创定的口径：实测 0.35 阈值下真实插画稳定出 12~20 个。"""
    assert OutputSpec().tag_min_count == 12
    assert OutputSpec.from_dict({}).tag_min_count == 12
    assert OutputSpec.from_dict({"mode": "both"}).tag_max_count == 160


def test_output_spec_rejects_unknown_mode():
    with pytest.raises(ConfigError):
        OutputSpec.from_dict({"mode": "nl+tag"})


def test_output_spec_rejects_empty_interval():
    with pytest.raises(ConfigError):
        OutputSpec.from_dict({"tag_min_count": 20, "tag_max_count": 10})
    with pytest.raises(ConfigError):
        OutputSpec.from_dict({"nl_min_tokens": 300, "nl_max_tokens": 100})


def test_output_spec_accepts_override():
    spec = OutputSpec.from_dict({"tag_min_count": 16, "tag_max_count": 80,
                                 "mode": "tag"})
    assert (spec.tag_min_count, spec.tag_max_count, spec.mode) == (16, 80, "tag")
    assert spec.wants_tag and not spec.wants_nl


# ------------------------------------------------------------------ 质检同步


def test_quality_follows_output_token_budget():
    """NL 预算只有一个真值源。两处各写一份，迟早出现"生成了 256 却按 128 判废"。"""
    ops = OpsConfig(output={"nl_min_tokens": 40, "nl_max_tokens": 200},
                    quality={"min_chars": 1, "max_chars": 2})
    policy = ops.quality_policy()
    assert policy.nl_min_tokens == 40
    assert policy.nl_max_tokens == 200


# ------------------------------------------------------------------ 打包选项


def test_pack_options_defaults_are_quality_first():
    opts = PackOptions.from_dict({})
    assert opts.jpeg_quality == 95
    # 4:4:4（0）是项目口径：4:2:0 把色度分辨率砍半，饱和色/细线边缘有可见色晕
    assert opts.jpeg_subsampling == 0
    assert opts.reencode_mode == "always"


def test_pack_options_rejects_low_quality():
    with pytest.raises(ConfigError):
        PackOptions.from_dict({"jpeg_quality": 85})


def test_pack_options_accepts_old_boolean_reencode():
    assert PackOptions.from_dict({"reencode": True}).reencode_mode == "always"
    assert PackOptions.from_dict({"reencode": False}).reencode_mode == "never"


def test_pack_options_rejects_unknown_reencode():
    with pytest.raises(ConfigError):
        PackOptions.from_dict({"reencode": "sometimes"})


# ------------------------------------------------------------------ 报告批次


def test_report_batch_size_default_and_override():
    assert OpsConfig().report_batch_size() == 1000
    assert OpsConfig(report={"batch_size": 200}).report_batch_size() == 200


def test_report_batch_size_falls_back_on_garbage():
    """配错了不该让整条命令挂掉：报告是观察手段，不是校验关口。"""
    assert OpsConfig(report={"batch_size": "abc"}).report_batch_size() == 1000
    assert OpsConfig(report={"batch_size": 0}).report_batch_size() == 1000


# ------------------------------------------------------------------ 分档表


def test_repo_tier_table_parses_and_carries_new_sections():
    table = load_tier_table("configs/tiers.yaml")
    ops = load_ops(table)
    assert ops.output_spec().tag_min_count == 12
    assert ops.report_batch_size() >= 1
    assert isinstance(ops.variants, dict)
    assert "base" in ops.variants


def test_repo_tier_table_alpha_policy_is_documented():
    """注释里不能再写"带 alpha 不转"——那是被推翻的旧口径。"""
    text = open("configs/tiers.yaml", encoding="utf-8").read()
    assert "带 alpha 的图无论哪个模式都不转" not in text
    assert "铺白底" in text


def test_resolve_buckets_off():
    assert resolve_buckets(False, 589824) == []
    assert resolve_buckets("off", 589824) == []
    assert resolve_buckets({"enabled": False}, 589824) == []


def test_resolve_buckets_defaults_cover_five_ratios():
    buckets = resolve_buckets(True, 589824)
    assert len(buckets) == 5
    # 32 对齐是硬要求，否则 processor 会自己向上取整、账算不准
    for b in buckets:
        assert b.width % 32 == 0 and b.height % 32 == 0
