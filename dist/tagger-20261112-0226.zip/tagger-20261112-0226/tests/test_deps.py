"""依赖检测：清单解析与状态判定的稳定断言。

刻意不假设"这台机器装了什么"：开发机、CI、全新装机三种环境下，能装的包
完全不同。这里只断言清单本身与判定逻辑，跑在哪儿都一样。
"""

from __future__ import annotations

import sys

from tagger.web.deps import (DepManager, Item, describe, installed_version,
                             load_extras, load_items)


def test_清单能读出来且不重名():
    items = load_items()
    assert items, "两份 requirements 至少要读出一批包"
    names = [i.name.lower().replace("_", "-") for i in items]
    assert len(names) == len(set(names)), "同一个包不该在页面上出现两行"


def test_清单包含运行环境必需的包():
    """fastapi / uvicorn 缺了服务根本起不来，它们必须在清单里。"""
    names = {i.name.lower() for i in load_items()}
    for must in ("fastapi", "uvicorn", "httpx", "websockets"):
        assert must in names


def test_分组只有三种():
    groups = {i.group for i in load_items()}
    assert groups <= {"core", "tag", "optional"}
    assert "core" in groups


def test_没装的包判为缺失():
    row = describe(Item(name="definitely-not-installed-xyz", spec="definitely-not-installed-xyz",
                        group="optional"))
    assert row["status"] == "missing"
    assert row["installed"] is None


def test_装了且版本符合的判为通过():
    # pytest 一定装着——这个测试文件正在被它跑。
    row = describe(Item(name="pytest", spec="pytest", group="core"))
    assert row["status"] == "ok"
    assert row["installed"] == installed_version("pytest")


def test_版本要求写死一个不可能的值时判为不符():
    row = describe(Item(name="pytest", spec="pytest==0.0.1", group="core"))
    assert row["status"] == "mismatch"


def test_导入名映射不会把_PIL_认错():
    """清单写的是 Pillow，import 用的是 PIL。少了映射表，装好的包会被报成缺失。"""
    item = Item(name="Pillow", spec="Pillow", group="core")
    assert item.module == "PIL"


def test_快照带着批量与检查字段():
    """页面靠这几个字段画批量进度和"导入失败"标记，缺了会静默画不出来。"""
    snap = DepManager().snapshot()
    assert "verify_at" in snap
    assert snap["summary"]["broken"] == 0       # 没检查过就该是 0，不是 None
    rows = [r for g in snap["groups"] for r in g["items"]]
    assert rows and all("verified" in r for r in rows)


def test_一次只允许一个动作在跑():
    mgr = DepManager()
    mgr.status = "running"                      # 假装有一个在跑
    try:
        mgr._start_many("verify", [Item(name="pytest", spec="pytest", group="core")])
    except RuntimeError:
        return
    raise AssertionError("并发动作应当被拒绝")


def test_非法包名被拒绝():
    mgr = DepManager()
    try:
        mgr._find("bad name; rm -rf /")
    except ValueError:
        return
    raise AssertionError("带空格的包名应当被拒绝")


# ---------------------------------------------------------------- 附加依赖
#
# 这几条守的是"页面上能一键装的东西，必须和 pyproject 里声明的同一串"。
# 抄一份清单到别处，迟早在某次升级后对不上，而且是对不上的那一刻才发现。


def test_附加依赖从_pyproject_读():
    extras = load_extras()
    assert "quantize" in extras, "量化用的 extra 必须在 pyproject 里能被读到"
    names = {it.name for it in extras["quantize"]}
    assert {"llmcompressor", "torch", "transformers"} <= names


def test_装附加依赖只挑缺的(monkeypatch):
    """已经装着的共用依赖不能动：为了补 llmcompressor 把打标用的 torch
    换一遍，等于把已产出 tag 的数值口径悄悄改掉。"""
    mgr = DepManager()
    seen: dict = {}
    monkeypatch.setattr(
        mgr, "_start_many",
        lambda action, items: seen.update(action=action, items=list(items)) or {})
    try:
        mgr.install_extra("quantize")
    except ValueError:
        # 这台机器上 extra 已经装齐了：拒绝白跑一次 pip 也是对的。
        assert seen == {}
        return
    assert seen["action"] == "install-quantize"
    assert seen["items"]
    assert all(describe(it)["status"] == "missing" for it in seen["items"])


def test_不认识的附加依赖被拒绝():
    try:
        DepManager().install_extra("definitely-not-an-extra")
    except ValueError:
        return
    raise AssertionError("不存在的 extra 应当被拒绝")


def test_install_extra_路由不会被通用路由吃掉(tmp_path):
    """`/api/deps/{name}/{action}` 也占两段，写成路径参数会被它先匹配走，
    然后报"不认识的操作"。这条路径必须保持单段 + query。"""
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    client = TestClient(create_app(ui_dist=tmp_path / "no-ui"))
    r = client.post("/api/deps/install-extra?extra=nope")
    assert r.status_code == 400, r.text
    assert "nope" in r.json()["detail"]
    assert client.post("/api/deps/install-extra").status_code == 400


def test_量化快照带上缺失依赖名单():
    """页面靠 missing_deps 决定给不给"一键安装"按钮；靠 reason 的中文
    去猜，改一个字按钮就消失。"""
    from tagger.quantize import QUANT

    snap = QUANT.snapshot(None)
    assert isinstance(snap.get("missing_deps"), list)


# ---------------------------------------------------------------- 附加依赖进 tab
#
# 这几组原来只长在各自的弹窗里（「本地量化」一个按钮、「量化」一个按钮），
# 想"先把环境配齐再干活"的人在依赖检测页根本看不到它们缺什么。


def test_附加依赖组也进依赖检测页():
    snap = DepManager().snapshot()
    extras = {g["extra"]: g for g in snap["groups"] if g.get("kind") == "extra"}
    assert {"convert", "quantize"} <= set(extras)

    conv = extras["convert"]
    assert "sentencepiece" in {i["name"] for i in conv["items"]}
    # 组头的"缺几个"决定「安装本组」按钮上的角标，算错就会显示"缺 0 个"却还亮着
    assert conv["missing"] == sum(1 for i in conv["items"] if i["status"] == "missing")

    # 与主清单重名的包要标出来：在两组点"卸载"改的是同一个 site-packages
    torch_row = next(i for i in conv["items"] if i["name"] == "torch")
    assert torch_row["shared"] is True


def test_附加依赖组不进批量安装():
    """serve 在 Windows 上装了也起不来、llmcompressor 几百 MB：
    把它们混进「安装缺失」就是一次误伤。"""
    snap = DepManager().snapshot()
    core = {i["name"] for g in snap["groups"] if g.get("kind") != "extra" for i in g["items"]}
    extras = {g["extra"]: g for g in snap["groups"] if g.get("kind") == "extra"}

    assert "llmcompressor" not in core
    assert "llmcompressor" in {i["name"] for i in extras["quantize"]["items"]}


# ---------------------------------------------------------------- 平台专属包
#
# requirements 文件表达不了"这个包只有 Linux"：vLLM 的轮子只有 Linux，Windows
# 上装出来是个 import 就炸的壳，还会把钉死的 torch 换掉。所以清单读完后按一张表
# 打标，页面对这类包置灰；这里守的就是那张表和它的两个消费点（计数、动作）。


def test_平台专属包带上平台标记():
    vllm = next(i for i in load_items() if i.name == "vllm")
    assert vllm.platforms == ("linux",)
    row = describe(vllm)
    assert row["platforms"] == ["linux"]
    # 断言"和当前系统一致"，这样 Linux CI 上也成立
    assert row["supported"] is bool(sys.platform.startswith("linux"))


def test_装不了的包不占按钮上的计数(monkeypatch):
    """「缺失 N」那个角标要是把 Linux-only 的包算进去，点下去必然报错。"""
    import tagger.web.deps as deps

    monkeypatch.setattr(deps.sys, "platform", "win32")
    snap = deps.DepManager().snapshot()

    main = [r for g in snap["groups"] if g.get("kind") != "extra" for r in g["items"]]
    assert snap["summary"]["blocked"] == sum(
        1 for r in main if r["status"] == "missing" and not r["supported"])
    for g in snap["groups"]:
        assert g["blocked"] == sum(
            1 for r in g["items"] if r["status"] == "missing" and not r["supported"])


def test_windows_上不许装_vllm(monkeypatch):
    import tagger.web.deps as deps

    monkeypatch.setattr(deps.sys, "platform", "win32")
    mgr = deps.DepManager()
    for act in (mgr.install, mgr.reinstall):
        try:
            act("vllm")
        except ValueError as exc:
            assert "linux" in str(exc)
        else:
            raise AssertionError("Windows 上不该放行 vllm")


def test_torch_索引贴着清单里实测的_cuda_版本():
    """索引里的 cuXXX 写错 = 页面上点「安装 torch」必然 `No matching distribution`。

    PyTorch 的索引按 CUDA 版本分目录、各自只放自己那份：cu124 目录最高只到
    2.6.0，拿它去装钉死的 2.14.1 直接解析不出来。这条守的是两处别再各写各的
    （写这个测试之前，安装脚本已经换成 cu126，网页这边还留着 cu124）。
    """
    import re
    from pathlib import Path

    from tagger.web.deps import TORCH_INDEX_GPU

    root = Path(__file__).resolve().parent.parent
    text = (root / "requirements-tag.txt").read_text(encoding="utf-8")
    # 注释里写的是"torch 2.14.1+cu126"，钉死的那行是 torch==2.14.1：两种都认
    m = re.search(r"\btorch\s*=*\s*[\d.]+(\+cu\d+)", text)
    assert m, "requirements-tag.txt 里要记着实测的 torch 版本（形如 torch 2.14.1+cu126）"
    assert m.group(1)[1:] in TORCH_INDEX_GPU, (
        f"清单实测的是 {m.group(1)}，网页却从 {TORCH_INDEX_GPU} 装")


def test_没有显卡时_torch_走_cpu(monkeypatch):
    import tagger.web.deps as deps

    monkeypatch.setattr(deps.shutil, "which", lambda name: None)
    assert deps.torch_plan() == (deps.TORCH_INDEX_CPU, "")


def test_驱动太老时_torch_退到_cpu_版并说明原因(monkeypatch):
    """驱动只支持 CUDA 12.4 时装 cu126 的轮子：pip 成功、`import torch` 才报
    驱动版本不足。这种失败在页面上看不出任何征兆，所以宁可退 CPU 版。"""
    import tagger.web.deps as deps

    monkeypatch.setattr(deps.shutil, "which",
                        lambda name: "nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(deps, "_driver_cuda", lambda: (12, 4))
    index, note = deps.torch_plan()
    assert index == deps.TORCH_INDEX_CPU
    assert "12.4" in note and "CPU" in note


def test_驱动够新时_torch_走_cu126(monkeypatch):
    import tagger.web.deps as deps

    monkeypatch.setattr(deps.shutil, "which",
                        lambda name: "nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(deps, "_driver_cuda", lambda: (12, 6))
    assert deps.torch_plan() == (deps.TORCH_INDEX_GPU, "")


def test_快照把_torch_的说明一起带出去(monkeypatch):
    """页面底部那行要靠它解释"为什么装了显卡还慢"。"""
    import tagger.web.deps as deps

    monkeypatch.setattr(deps, "torch_plan", lambda: (deps.TORCH_INDEX_CPU, "驱动太老"))
    snap = deps.DepManager().snapshot()
    assert snap["torch_index"] == deps.TORCH_INDEX_CPU
    assert snap["torch_note"] == "驱动太老"


def test_装不了的附加依赖组不发起_pip(monkeypatch):
    """serve = [vllm]：Windows 上整组都装不了，应当直接说清原因。"""
    import tagger.web.deps as deps

    monkeypatch.setattr(deps.sys, "platform", "win32")
    mgr = deps.DepManager()
    touched: list = []
    monkeypatch.setattr(mgr, "_start_many",
                        lambda action, items: touched.extend(items) or {})
    try:
        mgr.install_extra("serve")
    except ValueError as exc:
        assert "linux" in str(exc)
    assert not any(it.name == "vllm" for it in touched)
