"""复核对账的守卫。

这一层的存在理由只有一句：宁可现在报错，也不要让缺口流到下游。
所以测试重点是"能不能发现"，而不是"合格时返回 0"。
"""

from __future__ import annotations

import io
import json
import tarfile

import pytest

from tagger.pack import PackOptions, Packer
from tagger.verify import verify_dir, verify_sample


def _write_tar(path, samples: dict[str, dict[str, bytes]]) -> None:
    with tarfile.open(path, "w") as tf:
        for stem, members in samples.items():
            for suffix, data in members.items():
                info = tarfile.TarInfo(f"{stem}{suffix}")
                info.size = len(data)
                tf.addfile(info, io.BytesIO(data))


def _meta(name: str) -> bytes:
    return json.dumps({"name": name, "key": name.rsplit(".", 1)[0]}).encode()


# ------------------------------------------------------------------ 单条检查


def test_verify_sample_flags_empty_object():
    issues = verify_sample("a", {".json": b"{}"})
    assert [i.kind for i in issues] == ["bad_json"]


def test_verify_sample_flags_missing_tag_by_mode():
    members = {".json": _meta("a.jpg"), ".nl": b"a caption"}
    issues = verify_sample("a", members, mode="both")
    assert [i.kind for i in issues] == ["no_tag"]
    # tag 模式下 nl 缺失不算错
    assert verify_sample("a", members, mode="nl") == []


# ------------------------------------------------------------------ 归档检查


def test_verify_parquet_from_packer_passes(tmp_path, make_png):
    """parquet 是 Packer 的默认格式，复核必须能读它——否则主格式没人验。"""
    pytest.importorskip("pyarrow")
    opts = PackOptions(max_records=10, formats=("parquet",))
    packer = Packer(tmp_path, opts, verbose=False)
    for i in (1, 2):
        packer.add(flat_name=f"c-{i:06d}.png", image_bytes=make_png(),
                   meta={"width": 8, "height": 8}, nl="caption",
                   tag_text="red, square")
    packer.close()

    report = verify_dir(tmp_path, mode="both",
                        expected={"c-000001.jpg", "c-000002.jpg"})
    assert report.shards == 1
    assert report.scanned == 2 and report.ok == 2
    assert not report.failed


def test_verify_zip_from_packer_passes(tmp_path, make_png):
    """Packer 写的 zip 里带 index.json，不能被当成一条样本。"""
    opts = PackOptions(max_records=10, formats=("zip",))
    packer = Packer(tmp_path, opts, verbose=False)
    for i in (1, 2):
        packer.add(flat_name=f"a-{i:06d}.png", image_bytes=make_png(),
                   meta={"width": 8, "height": 8}, nl="caption",
                   tag_text="red, square")
    packer.close()

    report = verify_dir(tmp_path, mode="both",
                        expected={"a-000001.jpg", "a-000002.jpg"})
    assert report.scanned == 2
    assert report.ok == 2
    assert not report.failed
    assert not report.missing and not report.extra


def test_verify_tar_from_packer_passes(tmp_path, make_png):
    opts = PackOptions(max_records=10, formats=("webdataset",))
    packer = Packer(tmp_path, opts, verbose=False)
    packer.add(flat_name="b-000001.png", image_bytes=make_png(),
               meta={"width": 8, "height": 8}, nl="caption", tag_text="red")
    packer.close()

    report = verify_dir(tmp_path, mode="both", expected={"b-000001.jpg"})
    assert report.scanned == 1 and report.ok == 1
    assert not report.failed


def test_verify_reads_vlm_artifact_parquet(tmp_path):
    """VLM 客户端的 parquet 把整个 payload 塞进 tag / nl 列。

    直接拿那段 JSON 当正文的话，`mode=nl` 的批次每条都会被判成"缺 NL"，
    而数据其实好着——这是复核口径读错了，不是产物有问题。
    """
    pytest.importorskip("pyarrow")
    from tagger.artifacts import ParquetSink

    sink = ParquetSink(tmp_path, rows_per_file=10)
    sink.add("a-000001",
             {"image_id": "a-000001", "tag": "red, square", "ok": True},
             {"image_id": "a-000001", "caption": "a red square", "ok": True})
    sink.add("a-000002", None,
             {"image_id": "a-000002", "caption": "only caption", "ok": True})
    sink.flush()

    # 只出 NL 的批次：tag 列是空的（None），不该被判成缺 tag
    report = verify_dir(tmp_path, mode="nl")
    assert report.scanned == 2
    assert report.ok == 2, [i.detail for i in report.issues]
    assert not report.failed

    # 只出 tag 的批次：第二条没有 tag，要能报出来
    report = verify_dir(tmp_path, mode="tag")
    assert report.ok == 1
    assert [i.kind for i in report.issues] == ["no_tag"]


def test_verify_detects_missing_expected(tmp_path):
    _write_tar(tmp_path / "pack-00000.tar", {
        "a-000001": {".json": _meta("a-000001.jpg"), ".nl": b"x", ".tag": b"red"},
    })
    report = verify_dir(tmp_path, mode="both",
                        expected={"a-000001.jpg", "a-000002.jpg"})
    assert report.missing == ["a-000002.jpg"]
    assert report.failed


def test_verify_detects_image_without_json(tmp_path):
    """"只有图没有 json"是最隐蔽的丢标形态：它是合法 tar，但整条没有内容。"""
    _write_tar(tmp_path / "pack-00000.tar", {
        "a-000001": {".json": _meta("a-000001.jpg"), ".nl": b"x", ".tag": b"red"},
        # 只有图片成员，没有任何文本成员
        "a-000002": {".jpg": b"\xff\xd8\xff\xd9"},
    })
    report = verify_dir(tmp_path, mode="both")
    assert report.scanned == 2
    assert any(i.kind == "bad_json" and "a-000002" in i.detail
               for i in report.issues)


def test_verify_detects_empty_tag(tmp_path):
    _write_tar(tmp_path / "pack-00000.tar", {
        "a-000001": {".json": _meta("a-000001.jpg"), ".nl": b"x", ".tag": b"   "},
    })
    report = verify_dir(tmp_path, mode="both")
    assert any(i.kind == "no_tag" for i in report.issues)
    assert report.failed


def test_verify_detects_duplicate_across_shards(tmp_path):
    for i in (0, 1):
        _write_tar(tmp_path / f"pack-0000{i}.tar", {
            "same": {".json": _meta("same.jpg"), ".nl": b"x", ".tag": b"red"},
        })
    report = verify_dir(tmp_path, mode="both")
    assert any(i.kind == "duplicate" for i in report.issues)
    assert report.failed


def test_verify_reports_extra_when_output_has_more(tmp_path):
    _write_tar(tmp_path / "pack-00000.tar", {
        "a-000001": {".json": _meta("a-000001.jpg"), ".nl": b"x", ".tag": b"red"},
        "a-000009": {".json": _meta("a-000009.jpg"), ".nl": b"x", ".tag": b"red"},
    })
    report = verify_dir(tmp_path, mode="both", expected={"a-000001.jpg"})
    assert report.extra == ["a-000009.jpg"]


def test_verify_no_shards(tmp_path):
    report = verify_dir(tmp_path)
    assert report.shards == 0
    assert report.scanned == 0
