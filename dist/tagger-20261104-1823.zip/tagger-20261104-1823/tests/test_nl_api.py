"""外部推理 API 适配层（tagger/nl_api.py）。

这一层的存在理由就是"两种方言长得不一样"，所以测试钉的都是差异点：
端点归一化、system 放哪、图片形态、seed 能不能带、响应怎么取文本与 token。
client.py 只负责把 blob 递进来，方言逻辑不该再散回主循环里。
"""

from __future__ import annotations

import io

import pytest
from PIL import Image

from tagger import nl_api
from tagger.artist import ArtistRule
from tagger.client import StageTimer, TaggerClient, TaskRow
from tagger.config import OutputSpec

GOOD_TEXT = "<CAPTION>A red square.</CAPTION>"


# ------------------------------------------------------------------ 来源归一化


def test_normalize_provider_accepts_common_spellings():
    assert nl_api.normalize_provider("") == ""
    assert nl_api.normalize_provider("local") == ""
    assert nl_api.normalize_provider("llamacpp") == ""
    assert nl_api.normalize_provider("openai-compatible") == "openai"
    assert nl_api.normalize_provider("CLAUDE") == "anthropic"


def test_normalize_provider_rejects_unknown():
    """静默退回本机会让人以为在用 API、实际却带着本机指纹产数据。"""
    with pytest.raises(ValueError):
        nl_api.normalize_provider("gemini")


# ------------------------------------------------------------------ 端点拼装


def test_endpoint_does_not_double_v1():
    """用户复制粘贴过来的地址多半已经带 /v1，再拼一次就是 /v1/v1/...。"""
    assert nl_api.endpoint("http://127.0.0.1:8000", "") == \
        "http://127.0.0.1:8000/v1/chat/completions"
    assert nl_api.endpoint("https://api.openai.com/v1", "openai") == \
        "https://api.openai.com/v1/chat/completions"
    assert nl_api.endpoint("https://api.openai.com/v1/", "openai") == \
        "https://api.openai.com/v1/chat/completions"
    assert nl_api.endpoint("https://gw.example.com/openai/v1", "openai") == \
        "https://gw.example.com/openai/v1/chat/completions"


def test_endpoint_accepts_full_endpoint_and_anthropic_path():
    assert nl_api.endpoint("https://x.dev/v1/chat/completions", "openai") == \
        "https://x.dev/v1/chat/completions"
    assert nl_api.endpoint("https://api.anthropic.com", "anthropic") == \
        "https://api.anthropic.com/v1/messages"
    assert nl_api.endpoint("https://api.anthropic.com/v1", "anthropic") == \
        "https://api.anthropic.com/v1/messages"


def test_endpoint_empty_base_raises():
    with pytest.raises(ValueError):
        nl_api.endpoint("   ", "openai")


# ------------------------------------------------------------------ 鉴权头


def test_auth_headers_follow_dialect():
    assert nl_api.auth_headers("", "k") == {}
    assert nl_api.auth_headers("openai", "") == {}
    assert nl_api.auth_headers("openai", " k ") == {"Authorization": "Bearer k"}
    anth = nl_api.auth_headers("anthropic", "k")
    # anthropic-version 是必需的：不传会被 400，而提示不指向版本头。
    assert anth == {"anthropic-version": nl_api.ANTHROPIC_VERSION, "x-api-key": "k"}
    assert nl_api.auth_headers("anthropic", "") == {
        "anthropic-version": nl_api.ANTHROPIC_VERSION}


# ------------------------------------------------------------------ 请求体


def test_anthropic_payload_uses_top_level_system_and_image_block():
    blob = nl_api.ImageBlob(mime="image/png", data_url="data:x", b64="QUJD")
    payload = nl_api.build_payload(
        "anthropic", model="claude-x", system="SYS", prompt="P", image=blob,
        temperature=0.2, top_p=0.9, max_tokens=256, seed=7)

    assert payload["system"] == "SYS"
    content = payload["messages"][0]["content"]
    assert content[0] == {"type": "image",
                          "source": {"type": "base64", "media_type": "image/png",
                                     "data": "QUJD"}}
    assert content[1] == {"type": "text", "text": "P"}
    # Anthropic 不认 seed：带上它是 400，而不是被忽略。
    assert "seed" not in payload


def test_openai_payload_keeps_image_url_and_seed():
    blob = nl_api.ImageBlob(mime="image/png", data_url="data:image/png;base64,QUJD",
                            b64="QUJD")
    payload = nl_api.build_payload(
        "openai", model="gpt-x", system="SYS", prompt="P", image=blob,
        temperature=0.2, top_p=0.9, max_tokens=256, seed=7)

    assert payload["messages"][0] == {"role": "system", "content": "SYS"}
    user = payload["messages"][1]["content"]
    assert user[0] == {"type": "image_url",
                       "image_url": {"url": "data:image/png;base64,QUJD"}}
    assert payload["seed"] == 7


def test_local_payload_is_unchanged_vllm_shape():
    """provider="" 必须与本机 vLLM 原来的形状逐字一致，否则老服务会 400。"""
    blob = nl_api.ImageBlob(mime="image/jpeg", data_url="file:///tmp/a.jpg")
    payload = nl_api.build_payload(
        "", model="tagger", system="SYS", prompt="P", image=blob,
        temperature=0.2, top_p=0.9, max_tokens=64, seed=None)
    assert set(payload) == {"model", "messages", "temperature", "top_p", "max_tokens"}
    assert payload["messages"][1]["content"][0]["image_url"]["url"] == "file:///tmp/a.jpg"


# ------------------------------------------------------------------ 响应解析


def test_parse_anthropic_response_joins_text_blocks():
    body = {"content": [{"type": "text", "text": "A"},
                        {"type": "thinking", "thinking": "..."},
                        {"type": "text", "text": "B"}],
            "usage": {"input_tokens": 900, "output_tokens": 12}}
    # 输入 token 必须一起取：图片 base64 撑大的 prompt 才是账单大头。
    assert nl_api.parse_response("anthropic", body) == ("AB", 900, 12)


def test_parse_openai_response_handles_content_parts():
    """少数网关把 content 返成 parts 数组，按块拼起来而不是整条判废。"""
    body = {"choices": [{"message": {"content": [{"type": "text", "text": "A"},
                                                 {"type": "text", "text": "B"}]}}],
            "usage": {"prompt_tokens": 1200, "completion_tokens": 5}}
    assert nl_api.parse_response("openai", body) == ("AB", 1200, 5)


def test_parse_openai_response_rejects_missing_choices():
    with pytest.raises(ValueError):
        nl_api.parse_response("openai", {"error": {"message": "boom"}})


# ------------------------------------------------------------------ 失败分档


def test_classify_status_splits_three_ways():
    """429 与 401 的处理必须不同：一个退避重试，一个立刻停整批。"""
    assert nl_api.classify_status(429) == (True, False)
    assert nl_api.classify_status(529) == (True, False)      # Anthropic overloaded
    assert nl_api.classify_status(408) == (True, False)
    assert nl_api.classify_status(503) == (True, False)
    assert nl_api.classify_status(401) == (False, True)
    assert nl_api.classify_status(403) == (False, True)
    assert nl_api.classify_status(404) == (False, True)
    # 400（图片被内容策略拒）只是这一张的问题，不该停整批。
    assert nl_api.classify_status(400) == (False, False)


def test_retry_after_seconds_parses_header():
    assert nl_api.retry_after_seconds({"retry-after": "3"}) == 3.0
    assert nl_api.retry_after_seconds({"Retry-After": "0.5"}) == 0.5
    # HTTP-date 形式不解析：交给指数退避，别为此写一个时区解析器。
    assert nl_api.retry_after_seconds({"retry-after": "Wed, 21 Oct 2026 07:28:00 GMT"}) is None
    assert nl_api.retry_after_seconds({}) is None
    assert nl_api.retry_after_seconds(None) is None


# ------------------------------------------------------------------ 默认值/成本


def test_provider_defaults_differ():
    assert nl_api.default_max_pixels("anthropic") > 0
    assert nl_api.default_max_pixels("openai") > 0
    assert nl_api.default_max_pixels("") == 0
    assert nl_api.default_concurrency("anthropic") >= 1
    assert nl_api.default_concurrency("") == 0
    assert "claude-sonnet-4-5" in nl_api.model_hints("anthropic")


def test_estimate_cost_uses_prefix_and_refuses_to_guess():
    prices = {"gpt-4o": [2.5, 10.0]}
    # 带日期后缀的模型名要靠前缀命中
    assert nl_api.estimate_cost("gpt-4o-2024-08-06", 1_000_000, 0, prices) == 2.5
    assert nl_api.estimate_cost("gpt-4o", 0, 1_000_000, prices) == 10.0
    # 查不到就 None：宁可只报 token，也不编一个数出来
    assert nl_api.estimate_cost("unknown", 1, 1, prices) is None
    assert nl_api.estimate_cost("gpt-4o", 1, 1, {}) is None


# ------------------------------------------------------------------ 密钥存档


def test_saved_key_roundtrip_and_mask(tmp_path, monkeypatch):
    monkeypatch.setattr(nl_api, "saved_path", lambda: tmp_path / "nl_api.json")
    nl_api.store_key("openai", "https://gw/v1", "sk-abcdefgh1234")
    entry = nl_api.saved_for("openai")
    assert entry["key"] == "sk-abcdefgh1234"
    assert entry["base"] == "https://gw/v1"
    # 页面拿到的永远是脱敏值
    masked = nl_api.mask_key(entry["key"])
    assert "abcdefgh" not in masked
    assert masked.startswith("sk-a") and masked.endswith("1234")

    nl_api.store_key("openai", "", "")
    assert nl_api.saved_for("openai") == {}
    assert nl_api.mask_key("") == ""


# ------------------------------------------------------------------ 图片转换


def test_blob_from_bytes_converts_bmp_for_anthropic():
    """Anthropic 只收 jpeg/png/gif/webp；bmp 会被 400，且报错不指向格式。"""
    buf = io.BytesIO()
    Image.new("RGB", (4, 4), (1, 2, 3)).save(buf, "BMP")
    blob = nl_api.blob_from_bytes(buf.getvalue(), "image/bmp", provider="anthropic")
    assert blob.mime == "image/png"
    assert blob.b64  # 转码后重新编码过
    assert blob.data_url.startswith("data:image/png;base64,")


def test_blob_from_bytes_keeps_original_for_openai():
    buf = io.BytesIO()
    Image.new("RGB", (4, 4), (1, 2, 3)).save(buf, "BMP")
    raw = buf.getvalue()
    blob = nl_api.blob_from_bytes(raw, "image/bmp", provider="openai")
    assert blob.mime == "image/bmp"


# ------------------------------------------------------------------ 接线（client）


class _FakeAnthropicHTTP:
    """记录请求地址与请求体，回一段 Anthropic 形状的响应。"""

    def __init__(self):
        self.calls: list[tuple[str, dict]] = []

    def post(self, url, json=None):
        self.calls.append((url, json))
        from types import SimpleNamespace

        body = {"content": [{"type": "text", "text": GOOD_TEXT}],
                "usage": {"output_tokens": 9}}
        return SimpleNamespace(status_code=200, text="", json=lambda: body)

    def close(self):
        pass


def test_client_routes_anthropic_job_to_messages_endpoint(make_png):
    http = _FakeAnthropicHTTP()
    client = TaggerClient(
        base_url="https://api.anthropic.com", model_name="claude-x",
        output=OutputSpec(mode="nl", nl_min_tokens=1, nl_max_tokens=64),
        temperature=0.2, top_p=0.9, max_tokens=64, timeout_s=5, max_attempts=1,
        gate=_PassGate(),
        prov_base={"provider": "anthropic", "model_id": "claude-x",
                   "precision": "api", "max_pixels": 0},
        artist_rule=ArtistRule(), tag_backend=None, stage=StageTimer(),
        provider="anthropic", api_key="sk-test",
    )
    client._http = http
    outcome = client.process(TaskRow(shard="s", image_id="i1", file="i1.png"),
                             data=make_png())
    client.close()

    assert outcome.ok is True
    url, payload = http.calls[0]
    assert url == "https://api.anthropic.com/v1/messages"
    assert payload["model"] == "claude-x"
    assert payload["messages"][0]["content"][0]["type"] == "image"
    # provenance 要能分辨"这批是谁产的"
    assert outcome.nl["provenance"]["provider"] == "anthropic"


class _PassGate:
    def evaluate(self, ann, *, attempt=0, image=None, temperature=0.2,
                 max_pixels=0):
        from types import SimpleNamespace

        return SimpleNamespace(level="pass", score=1.0, reasons=[], retry=None)


class _StatusHTTP:
    """只回一个状态码，用来验证错误分档。"""

    def __init__(self, status: int, headers: dict | None = None):
        self.status = status
        self.headers = headers or {}
        self.calls = 0

    def post(self, url, json=None):
        from types import SimpleNamespace

        self.calls += 1
        return SimpleNamespace(status_code=self.status, text="bad",
                               headers=self.headers, json=lambda: {})

    def close(self):
        pass


def _api_client(http, provider: str = "openai", *, max_attempts: int = 1):
    client = TaggerClient(
        base_url="https://api.example.com", model_name="m",
        output=OutputSpec(mode="nl", nl_min_tokens=1, nl_max_tokens=64),
        temperature=0.2, top_p=0.9, max_tokens=64, timeout_s=5,
        max_attempts=max_attempts, gate=_PassGate(),
        prov_base={"provider": provider, "model_id": "m", "precision": "api",
                   "max_pixels": 0},
        artist_rule=ArtistRule(), tag_backend=None, stage=StageTimer(),
        provider=provider, api_key="k",
    )
    client._http = http
    return client


def test_client_marks_429_retryable_and_keeps_retry_after(make_png):
    client = _api_client(_StatusHTTP(429, {"retry-after": "7"}))
    outcome = client.process(TaskRow(shard="s", image_id="i", file="i.png"),
                             data=make_png())
    client.close()
    assert outcome.ok is False
    # 429 属于"这张还能救"，不能记成配置错误（否则整批会被误熔断）
    assert outcome.fatal is False
    assert outcome.rate_limited >= 1
    assert "429" in outcome.error


def test_client_marks_401_fatal(make_png):
    client = _api_client(_StatusHTTP(401))
    outcome = client.process(TaskRow(shard="s", image_id="i", file="i.png"),
                             data=make_png())
    client.close()
    # 密钥错：这张失败，并且上层必须据此停掉整批
    assert outcome.ok is False
    assert outcome.fatal is True
    assert outcome.rate_limited == 0


# ------------------------------------------------------------------ 熔断


class _FatalSlot:
    """每张都返回配置性错误，模拟"密钥写错"的批量现场。"""

    def __init__(self):
        self.seen = 0

    def process(self, task, data, reader=None):
        from tagger.client import Outcome

        self.seen += 1
        return Outcome(task.image_id, False, error="HTTP 401: bad key", fatal=True)


def test_batch_breaker_stops_after_consecutive_fatal(tmp_path):
    from tagger.client import ClientStats, Stopped, run_batch

    stats = ClientStats()
    items = [TaskRow(shard="s", image_id=f"i{n}", file=f"{n}.png")
             for n in range(1000)]
    slot = _FatalSlot()
    with pytest.raises(Stopped) as err:
        run_batch(slot, items, None, out_dir=tmp_path, layout="flat",
                  force=True, concurrency=1, guard=None, stats=stats,
                  failures=None, verbose=False)
    # 关键：不是把 1000 张跑完，而是在阈值处停下
    assert slot.seen <= 40
    assert "配置性错误" in str(err.value)


# ------------------------------------------------------------------ Web 表单层


def test_api_key_is_redacted_in_job_snapshot():
    """快照会随事件流广播给浏览器，密钥绝不能原样出门。"""
    from tagger.web.jobs import JobSpec, _redacted_spec

    spec = JobSpec(engine="vlm", vlm_provider="openai", api_key="sk-secret")
    assert _redacted_spec(spec)["api_key"] == "***"


def test_api_base_falls_back_to_provider_default():
    from tagger.web.jobs import JobSpec, spec_api_base, spec_provider

    spec = JobSpec(engine="vlm", vlm_provider="anthropic", api_base="")
    assert spec_provider(spec) == "anthropic"
    assert spec_api_base(spec) == "https://api.anthropic.com"
    # 本机模式没有 API 地址可言，别把默认域名发给本地服务
    assert spec_api_base(JobSpec(engine="vlm", vlm_provider="local")) == ""


def _ui(tmp_path, monkeypatch):
    """建一个只含 API 的 TestClient，并把密钥存档指到 tmp。"""
    from fastapi.testclient import TestClient

    from tagger.web.app import create_app

    monkeypatch.setattr(nl_api, "saved_path", lambda: tmp_path / "nl_api.json")
    return TestClient(create_app(ui_dist=tmp_path / "no-ui"))


def test_keys_endpoint_never_returns_plaintext(tmp_path, monkeypatch):
    client = _ui(tmp_path, monkeypatch)
    secret = "sk-ant-abcdefgh1234"
    r = client.post("/api/nl-api/keys", json={
        "provider": "anthropic", "base": "https://x.dev", "key": secret,
        "remember": True})
    assert r.status_code == 200
    assert secret not in r.text
    assert r.json()["saved"]["key_masked"].endswith("1234")

    got = client.get("/api/nl-api/keys").json()
    assert secret not in str(got)
    assert got["providers"]["anthropic"]["key_masked"]

    # 取消勾选 = 忘掉：存档里不该留下一个"看不见但还在"的密钥
    client.post("/api/nl-api/keys", json={
        "provider": "anthropic", "base": "", "key": "", "remember": False})
    assert client.get("/api/nl-api/keys").json()["providers"]["anthropic"] is None


def test_probe_endpoint_rejects_local_and_reports_dead_endpoint(tmp_path, monkeypatch):
    client = _ui(tmp_path, monkeypatch)
    # 本机模式有 /api/vllm/probe，不该混到这条路上
    assert client.post("/api/nl-api/probe", json={
        "provider": "local", "base": "", "model": "x"}).status_code == 400
    # 连不上也要返回结构化的结果，而不是 500 —— 页面要显示原因
    body = client.post("/api/nl-api/probe", json={
        "provider": "openai", "base": "http://127.0.0.1:9",
        "model": "gpt-4o", "key": "k", "timeout_s": 5}).json()
    assert body["ok"] is False
    assert body["error"]


def test_defaults_expose_provider_meta(tmp_path, monkeypatch):
    client = _ui(tmp_path, monkeypatch)
    providers = {p["value"]: p for p in client.get("/api/defaults").json()["vlm_providers"]}
    assert set(providers) == {"local", "openai", "anthropic"}
    assert providers["anthropic"]["concurrency"] >= 1
    assert providers["anthropic"]["max_pixels"] > 0
    assert "claude-sonnet-4-5" in providers["anthropic"]["models"]
    assert providers["local"]["base"] == ""


def test_create_rejects_api_mode_without_model_name(tmp_path, monkeypatch):
    """API 侧不认识 tagger 这个本地路由名，填错要当场 400 而不是跑起来 404。"""
    from tagger.web.jobs import JobManager, JobSpec

    manager = JobManager()
    monkeypatch.setattr(manager, "running", lambda: None)
    spec = JobSpec(engine="vlm", hf_repo="org/repo", out_dir=str(tmp_path / "o"),
                   vlm_provider="openai", vlm_model="", api_key="k")
    with pytest.raises(ValueError) as err:
        manager.create(spec)
    assert "模型名" in str(err.value)
