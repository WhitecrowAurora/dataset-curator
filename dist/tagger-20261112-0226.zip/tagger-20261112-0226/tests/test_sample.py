"""按配额挑 id（规范 v0.2 §1–§3）。

核心只有"每个来源按配额挑够数、可复现"。分层 / 去重 / 质量线是可选开关，
**默认关闭**——规范里写明它们是"初始可测试策略，需抽样审计后定稿"，
而且都会改变样本分布。
"""

from __future__ import annotations

import json
import random

import pytest

from tagger.sample import (DEFAULT_COLUMNS, SampleError, SampleSpec,
                           dedupe_clusters, pick, read_candidates,
                           resolve_quotas, select, write_selection)

COLS = {"id": "id", "source": "source", "score": "score",
        "cluster": "cluster", "stratum": "stratum"}


def _spec(**kw) -> SampleSpec:
    kw.setdefault("columns", dict(COLS))
    return SampleSpec(**kw)


def _rows(n: int, source: str = "a", stratum: str = "s",
          spec: SampleSpec | None = None) -> list[dict]:
    """造候选行。内部键按 spec 的实际开关填——关掉的开关就连键都不该有，
    这样"不该读的列被读了"能测出来。"""
    s = spec or _spec()
    out = []
    for i in range(n):
        row = {"id": f"{source}-{i}", "source": source, "score": float(i)}
        row["_id"] = f"{source}-{i}"
        row["_source"] = source
        row["_score"] = float(i) if s.needs_score else 0.0
        row["_cluster"] = "" if s.dedupe else ""
        row["_stratum"] = stratum if s.mix else ""
        out.append(row)
    return out


# ------------------------------------------------------------------ 配置


def test_配置解析():
    spec = SampleSpec.from_dict({
        "quotas": {"monet/laion": 10300000, "monet/coyo": 6600000},
        "quota_total": 30000000,
        "seed": 7,
        "columns": {"score": "aesthetic_jasperai", "cluster": "sscd_cluster_id"},
    })
    assert spec.quotas["monet/laion"] == 10300000
    assert spec.columns["score"] == "aesthetic_jasperai"
    assert spec.columns["id"] == DEFAULT_COLUMNS["id"]   # 没给的沿用默认
    assert spec.seed == 7


def test_三个可选开关默认全关():
    spec = SampleSpec.from_dict({"quotas": {"a": 1}})
    assert spec.min_score == 0.0
    assert spec.mix is False
    assert spec.dedupe is False
    assert spec.needs_score is False      # 不读分数列


def test_mix可写开关也可写比例():
    assert SampleSpec.from_dict({"mix": True}).mix is True
    spec = SampleSpec.from_dict({"mix": {"quality": 0.5, "tail": 0.3,
                                         "random": 0.2}})
    assert spec.mix is True and spec.mix_ratio == (0.5, 0.3, 0.2)
    with pytest.raises(SampleError):
        SampleSpec.from_dict({"mix": [0.5, 0.4, 0.4]})      # 合计不为 1


def test_配比不合法直接报错():
    with pytest.raises(SampleError):
        SampleSpec.from_dict({"quotas": {"a": "很多"}})


def test_没有id列不能用():
    with pytest.raises(SampleError):
        SampleSpec.from_dict({"columns": {"id": ""}})


# ------------------------------------------------------------------ 配额记账


def test_候选够用时按计划走():
    tables, borrowed, warn = resolve_quotas({"a": 100, "b": 100}, {"a": 30, "b": 20})
    assert tables["a"] == (30, 30) and tables["b"] == (20, 20)
    assert not any(borrowed.values())
    assert warn == []


def test_候选不足时削顶并记缺额():
    tables, _, warn = resolve_quotas({"a": 10}, {"a": 50}, allow_borrow=False)
    assert tables["a"] == (50, 10)
    assert any("候选不足" in w for w in warn)


def test_缺额跨来源补齐():
    """规范 §2：缺额可跨来源补，但 quota_original 不动。"""
    tables, borrowed, _ = resolve_quotas(
        {"a": 10, "b": 1000}, {"a": 50, "b": 100})
    assert tables["a"] == (50, 10)          # 计划 50，只有 10
    assert tables["b"][1] == 140            # 原定 100 + 补 40
    assert borrowed["b"] == 40
    assert tables["b"][0] == 100            # 计划数不被改写


def test_补不动的部分要出声():
    _, _, warn = resolve_quotas({"a": 10, "b": 20}, {"a": 50, "b": 100})
    assert any("无处可补" in w for w in warn)


def test_有数据但没配额要提醒():
    _, _, warn = resolve_quotas({"a": 10, "ghost": 5}, {"a": 10})
    assert any("ghost" in w and "没配额" in w for w in warn)


# ------------------------------------------------------------------ 挑（默认）

def test_默认就是均匀随机且挑够数():
    spec = _spec(seed=1)
    chosen = pick(_rows(100, spec=spec), 10, spec)
    assert len(chosen) == 10
    # 均匀随机不该是"前 10 条"——否则等于按文件顺序取
    assert {r["_id"] for r in chosen} != {f"a-{i}" for i in range(10)}


def test_选样可复现且与输入顺序无关():
    spec = _spec(seed=11)
    rows = _rows(300, spec=spec)
    a = [r["_id"] for r in pick(rows, 40, spec)]
    shuffled = rows[:]
    random.Random(0).shuffle(shuffled)
    b = [r["_id"] for r in pick(shuffled, 40, spec)]
    assert a == b


def test_换seed会换一批():
    spec1 = _spec(seed=1)
    spec2 = _spec(seed=2)
    rows = _rows(300, spec=spec1)
    a = {r["_id"] for r in pick(rows, 40, spec1)}
    b = {r["_id"] for r in pick(rows, 40, spec2)}
    assert a != b


def test_候选少于目标就全给():
    spec = _spec()
    assert len(pick(_rows(5, spec=spec), 50, spec)) == 5


# ------------------------------------------------------------------ 可选开关


def test_开了分层才按分数取头部():
    spec = _spec(seed=1, mix=True, mix_ratio=(0.6, 0.25, 0.15))
    rows = [dict(r, _stratum="s") for r in _rows(100, spec=spec)]
    chosen = {r["_id"] for r in pick(rows, 10, spec)}
    assert "a-99" in chosen          # 最高分在质量段里必进


def test_稀有分层不会被分数淹没():
    """只有 1 条的稀有题材，分数垫底也要保进来（需开 mix）。"""
    spec = _spec(seed=3, mix=True)
    rows = _rows(200, spec=spec) + [
        {"id": "rare-1", "source": "a", "score": 0.1, "_id": "rare-1",
         "_source": "a", "_score": 0.1, "_cluster": "", "_stratum": "rare"},
    ]
    chosen = {r["_id"] for r in pick(rows, 50, spec)}
    assert "rare-1" in chosen


def test_同簇只留最高分():
    rows = [
        {"_id": "1", "_source": "a", "_score": 1.0, "_cluster": "c1"},
        {"_id": "2", "_source": "a", "_score": 9.0, "_cluster": "c1"},
        {"_id": "3", "_source": "b", "_score": 5.0, "_cluster": "c1"},
        {"_id": "4", "_source": "a", "_score": 2.0, "_cluster": ""},
    ]
    kept, removed = dedupe_clusters(rows)
    assert [r["_id"] for r in kept] == ["2", "4"]
    assert removed == 2


def test_去重默认不生效():
    """默认不开启：同簇两条都留着（这是本次刻意改回的口径）。"""
    rows = _rows(10, "a")
    for r in rows:
        r["_cluster"] = "same" if r["id"] in ("a-8", "a-9") else ""
    result = select({"a": rows}, _spec(quotas={"a": 10}, seed=5))
    assert len(result.rows) == 10


def test_显式开去重才生效():
    spec = _spec(quotas={"a": 10}, seed=5, dedupe=True)
    rows = _rows(10, "a", spec=spec)
    for r in rows:
        r["_cluster"] = "same" if r["id"] in ("a-8", "a-9") else ""
    result = select({"a": rows}, spec)
    assert len(result.rows) == 9
    assert result.report[0].duplicates == 1


def test_质量线在选样之前生效():
    spec = _spec(quotas={"a": 10}, min_score=50.0)
    result = select({"a": _rows(100, "a", spec=spec)}, spec)
    assert result.total == 10
    assert min(r["score"] for r in result.rows) >= 50


# ------------------------------------------------------------------ 端到端


def test_端到端按来源记账():
    by_source = {"a": _rows(100, "a"), "b": _rows(30, "b")}
    result = select(by_source,
                    _spec(quotas={"a": 20, "b": 50}, seed=1, allow_borrow=False))
    assert result.total == 20 + 30            # b 只有 30 条
    rows = {r.source: r for r in result.report}
    assert rows["a"].quota_original == 20 and rows["a"].selected == 20
    assert rows["b"].quota_original == 50 and rows["b"].selected == 30
    assert rows["b"].shortfall == 20
    assert result.quota_original == 70 and result.quota_final == 50


def test_缺额补齐后总数回到计划():
    """允许借额时，b 缺的 20 条由 a 的余量补上：合计仍是 70。"""
    by_source = {"a": _rows(100, "a"), "b": _rows(30, "b")}
    result = select(by_source, _spec(quotas={"a": 20, "b": 50}, seed=1))
    rows = {r.source: r for r in result.report}
    assert result.total == 70
    assert rows["a"].quota_final == 40 and rows["a"].borrowed == 20
    assert rows["b"].quota_final == 30 and rows["b"].selected == 30
    assert result.quota_original == 70 and result.quota_final == 70


def test_输出剥掉内部键并记账(tmp_path):
    spec = _spec(quotas={"a": 4}, seed=2)
    result = select({"a": _rows(10, "a", spec=spec)}, spec)
    out, n = write_selection(result, tmp_path / "picked.jsonl")
    lines = [json.loads(x) for x in out.read_text("utf-8").splitlines()]
    assert n == 4 and len(lines) == 4
    assert all(not any(k.startswith("_") for k in row) for row in lines)
    assert all(row["sample_source"] == "a" and row["sample_quota"] == 4
               for row in lines)


def test_读jsonl候选(tmp_path):
    p = tmp_path / "cand.jsonl"
    p.write_text("\n".join(json.dumps({"id": f"x{i}", "source": "a",
                                       "score": i, "cluster": "",
                                       "stratum": "s"}) for i in range(3)),
                 encoding="utf-8")
    rows = read_candidates(p, _spec())
    assert [r["_id"] for r in rows] == ["x0", "x1", "x2"]
    assert rows[2]["_score"] == 0.0        # 没开质量线/分层：不读分数


def test_开了质量线才读分数(tmp_path):
    p = tmp_path / "cand.jsonl"
    p.write_text('{"id": "x", "source": "a", "score": 3.5}\n', encoding="utf-8")
    rows = read_candidates(p, _spec(min_score=1.0))
    assert rows[0]["_score"] == 3.5


def test_读parquet候选(tmp_path):
    pa = pytest.importorskip("pyarrow")
    import pyarrow.parquet as pq

    tbl = pa.table({"id": ["a", "b"], "source": ["s", "s"],
                    "score": [1.0, 2.0], "cluster": ["", ""],
                    "stratum": ["x", "x"]})
    p = tmp_path / "cand.parquet"
    pq.write_table(tbl, p)
    rows = read_candidates(p, _spec())
    assert [r["_id"] for r in rows] == ["a", "b"]


def test_parquet只读实际要用的列(tmp_path):
    """默认不读分数/簇/题材列：清单里没有这些列也照样能跑。"""
    pa = pytest.importorskip("pyarrow")
    import pyarrow.parquet as pq

    tbl = pa.table({"id": ["a"], "source": ["s"]})   # 只有两列
    p = tmp_path / "cand.parquet"
    pq.write_table(tbl, p)
    rows = read_candidates(p, _spec())
    assert [r["_id"] for r in rows] == ["a"]
