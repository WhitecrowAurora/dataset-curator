"""顶栏「配置方案」的接口行为。

只测这一层该保证的东西：
1. 存一份 / 同名覆盖（当更新用）
2. 切换会把 active 指过去，并把快照原样回传（一次往返）
3. 删除连 active 一起清
4. 自动保存：开 → 新起一条「自动保存 + 时间戳」，之后原地覆盖，关掉留档
5. 凭据不落盘（与 ui-form 同一套清洗）
"""

from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(tmp_path, monkeypatch):
    from tagger.web import ui_presets

    monkeypatch.setattr(ui_presets, "PRESET_PATH", tmp_path / "ui-presets.json")
    from tagger.web.app import create_app

    with TestClient(create_app(ui_dist=tmp_path / "no-ui")) as test_client:
        yield test_client


def _save(client, name: str, form: dict) -> dict:
    resp = client.post("/api/presets", json={"name": name, "form": form})
    assert resp.status_code == 200, resp.text
    return resp.json()


def test_save_and_list(client):
    state = _save(client, "中文30%", {"mode": "both", "zhRatio": 0.3})
    assert [it["name"] for it in state["items"]] == ["中文30%"]
    assert state["active"] == "中文30%"
    assert state["auto"] is False

    got = client.get("/api/presets/one", params={"name": "中文30%"}).json()
    assert got["form"]["zhRatio"] == 0.3
    assert got["name"] == "中文30%"


def test_same_name_overwrites(client):
    first = _save(client, "tag 档", {"mode": "tag", "limit": 100})
    second = _save(client, "tag 档", {"mode": "tag", "limit": 500})
    assert len(second["items"]) == 1
    assert first["items"][0]["ts"] <= second["items"][0]["ts"]
    got = client.get("/api/presets/one", params={"name": "tag 档"}).json()
    assert got["form"]["limit"] == 500


def test_apply_switches_active(client):
    _save(client, "A", {"limit": 1})
    _save(client, "B", {"limit": 2})
    got = client.post("/api/presets/apply", json={"name": "A"}).json()
    assert got["form"]["limit"] == 1
    assert got["state"]["active"] == "A"
    # 名字不存在的方案要明确 404，而不是悄悄当成"没切"
    assert client.post("/api/presets/apply", json={"name": "没有这个"}).status_code == 404


def test_delete_clears_active(client):
    _save(client, "A", {"limit": 1})
    state = client.delete("/api/presets", params={"name": "A"}).json()
    assert state["items"] == []
    assert state["active"] is None


def test_auto_save_names_with_timestamp_and_overwrites(client):
    state = client.post("/api/presets/auto", json={"enabled": True,
                                                  "form": {"limit": 1}}).json()
    assert state["auto"] is True
    assert state["auto_name"].startswith("自动保存 ")
    name = state["auto_name"]

    # 再写一次：名字不变（原地覆盖），否则下拉列表会被同义项刷爆
    state = client.post("/api/presets/auto", json={"form": {"limit": 2}}).json()
    assert state["auto_name"] == name
    assert len(state["items"]) == 1
    assert client.get("/api/presets/one", params={"name": name}).json()["form"]["limit"] == 2

    # 关掉只清开关，快照留着可以切回去
    state = client.post("/api/presets/auto", json={"enabled": False}).json()
    assert state["auto"] is False
    assert [it["name"] for it in state["items"]] == [name]

    # 关着的时候写入是空操作，不该偷偷攒文件
    before = client.get("/api/presets").json()
    client.post("/api/presets/auto", json={"form": {"limit": 3}})
    assert client.get("/api/presets").json() == before


def test_secrets_are_not_persisted(client, tmp_path):
    from tagger.web import ui_presets

    _save(client, "带密钥", {"mode": "both", "api_key": "sk-should-not-land",
                           "hfToken": "hf_should_not_land", "limit": 5})
    raw = json.loads(ui_presets.PRESET_PATH.read_text(encoding="utf-8"))
    blob = json.dumps(raw, ensure_ascii=False)
    assert "sk-should-not-land" not in blob
    assert "hf_should_not_land" not in blob


def test_auto_items_are_capped(client):
    from tagger.web import ui_presets

    for _ in range(ui_presets.MAX_AUTO + 3):
        client.post("/api/presets/auto", json={"enabled": True, "form": {"limit": 1}})
        client.post("/api/presets/auto", json={"enabled": False})
    state = client.get("/api/presets").json()
    autos = [it for it in state["items"] if it["auto"]]
    assert len(autos) <= ui_presets.MAX_AUTO
