"""画师输入整流器：格式适配、清洗口径、冲突处理、按分片切。

这一层最容易出静默错，四条底线：
1. 多画师按 `& , ; | 、` 切开，但**不**按 `/` 切（名字里带斜杠）；
2. 清洗与注入侧同一口径（空格→下划线、去 @#）；
3. 同 id 不同画师默认失败，不许后者悄悄覆盖；
4. 切出来的分片表要能被 ArtistTable 的配对校验直接吃（rows=成员数）。
"""

from __future__ import annotations

import io
import tarfile
import zipfile

import pytest

from tagger.artist import ArtistTable
from tagger.artist_import import (collect, import_artists, parse_artists,
                                 split_by_shards)
from tagger.config import ConfigError


def _tar(path, names):
    with tarfile.open(path, "w") as tf:
        for n in names:
            data = b"x"
            info = tarfile.TarInfo(n)
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    return path


def _zip(path, names):
    with zipfile.ZipFile(path, "w") as zf:
        for n in names:
            zf.writestr(n, b"x")
    return path


# ---------------------------------------------------------------- 切分与清洗

def test_多画师按常见分隔符切开():
    assert parse_artists("a & b") == ["a", "b"]
    assert parse_artists("a,b;c|d、e") == ["a", "b", "c", "d", "e"]
    assert parse_artists("a & a") == ["a"]              # 去重保序


def test_名字里的斜杠不当分隔符():
    """`hatsune_miku_(cosplay)` 按斜杠切会劈成两个画师。"""
    assert parse_artists("hatsune_miku_(cosplay)") == ["hatsune_miku_(cosplay)"]


def test_清洗口径与注入侧一致():
    assert parse_artists("@ban syou") == ["ban_syou"]
    assert parse_artists("  ") == []


def test_别名只映射切分后的每一段(tmp_path):
    """整段查会在 `a & b` 上永远不命中，等于白搭。"""
    aliases = {"水月": "shuiyue", "a": "alpha"}
    assert parse_artists("水月 & a", aliases=aliases) == ["shuiyue", "alpha"]


# ---------------------------------------------------------------- 各种输入

def test_csv带表头(tmp_path):
    src = tmp_path / "a.csv"
    src.write_text("id,artists\n8349000,a & b\n8349001,c\n", encoding="utf-8")
    out = tmp_path / "all.parquet"
    report = import_artists([src], out)
    assert report.rows == 2 and report.names == 3

    table = ArtistTable(str(out))
    assert table.lookup("8349000") == ["a", "b"]
    assert table.lookup("8349001") == ["c"]


def test_csv列序反了也认(tmp_path):
    src = tmp_path / "b.csv"
    src.write_text("artists,id\nban_syou,8349000\n", encoding="utf-8")
    out = tmp_path / "all.parquet"
    import_artists([src], out)
    assert ArtistTable(str(out)).lookup("8349000") == ["ban_syou"]


def test_txt纯名字按顺序编号(tmp_path):
    src = tmp_path / "names.txt"
    src.write_text("a\nb\n", encoding="utf-8")
    out = tmp_path / "all.parquet"
    report = import_artists([src], out, start=10)
    assert report.rows == 2
    table = ArtistTable(str(out))
    assert table.lookup("10") == ["a"]
    assert table.lookup("11") == ["b"]


def test_jsonl两种写法(tmp_path):
    src = tmp_path / "a.jsonl"
    src.write_text(
        '{"image_id": 8349000, "artists": ["a", "b"]}\n'
        '{"id": "8349001", "artist": "c & d"}\n', encoding="utf-8")
    out = tmp_path / "all.parquet"
    import_artists([src], out)
    table = ArtistTable(str(out))
    assert table.lookup("8349000") == ["a", "b"]
    assert table.lookup("8349001") == ["c", "d"]


def test_parquet换列名也能转(tmp_path):
    import pyarrow as pa
    import pyarrow.parquet as pq

    src = tmp_path / "old.parquet"
    pq.write_table(pa.table({
        "image_id": pa.array(["8349000"], pa.string()),
        "artist": pa.array(["a"], pa.string()),
    }), src)
    out = tmp_path / "all.parquet"
    import_artists([src], out)
    assert ArtistTable(str(out)).lookup("8349000") == ["a"]


# ---------------------------------------------------------------- 冲突

def test_同id不同画师默认失败且不写文件(tmp_path):
    a = tmp_path / "a.csv"
    a.write_text("id,artists\n1,alice\n", encoding="utf-8")
    b = tmp_path / "b.csv"
    b.write_text("id,artists\n1,bob\n", encoding="utf-8")
    out = tmp_path / "all.parquet"

    table, report = collect([a, b])
    assert report.conflicts and "alice" in report.conflicts[0]
    with pytest.raises(ConfigError, match="冲突"):
        import_artists([a, b], out)
    assert not out.exists()


def test_冲突可以指定留哪边(tmp_path):
    src = tmp_path / "c.csv"
    src.write_text("id,artists\n1,alice\n1,bob\n", encoding="utf-8")
    keep_last = tmp_path / "last.parquet"
    import_artists([src], keep_last, on_conflict="last")
    assert ArtistTable(str(keep_last)).lookup("1") == ["bob"]

    keep_first = tmp_path / "first.parquet"
    import_artists([src], keep_first, on_conflict="first")
    assert ArtistTable(str(keep_first)).lookup("1") == ["alice"]


def test_重复行不算冲突(tmp_path):
    src = tmp_path / "d.csv"
    src.write_text("id,artists\n1,a\n1,a\n", encoding="utf-8")
    table, report = collect([src])
    assert not report.conflicts and table[1] == ["a"]


# ---------------------------------------------------------------- 切分片

def test_按分片成员切片且能被配对校验(tmp_path):
    shards = tmp_path / "shards"
    shards.mkdir()
    _tar(shards / "shard-000000.tar", ["8349000.jpg", "8349001.jpg"])
    _tar(shards / "shard-000001.tar", ["8349002.jpg"])
    src = tmp_path / "a.csv"
    src.write_text("id,artists\n8349000,a\n8349002,c\n", encoding="utf-8")
    out = tmp_path / "artist-shards"

    table, _ = collect([src])
    stats = split_by_shards(table, shards, out)
    assert len(stats) == 3                       # 两片 + 一行汇总

    # 没画师的成员也写一行：rows 必须等于成员数，否则配对校验会拒答
    assert stats[0]["rows"] == 2 and stats[0]["matched"] == 1

    reader = ArtistTable(str(out))
    assert reader.lookup("8349000", "shard-000000.tar") == ["a"]
    assert reader.lookup("8349001", "shard-000000.tar") == []
    assert reader.lookup("8349002", "shard-000001.tar") == ["c"]
    assert not reader.problems


def test_zip分片也认(tmp_path):
    shards = tmp_path / "shards"
    shards.mkdir()
    _zip(shards / "shard-000000.zip", ["8349000.jpg"])
    table = {8349000: ["a"]}
    stats = split_by_shards(table, shards, tmp_path / "out")
    assert stats[0]["shard"] == "shard-000000.zip"
    assert ArtistTable(str(tmp_path / "out")).lookup(
        "8349000", "shard-000000.zip") == ["a"]


def test_没有分片时报错(tmp_path):
    with pytest.raises(ConfigError, match="没有分片"):
        split_by_shards({}, tmp_path, tmp_path / "out")
