"""HF 分片预取：下载与打标并行、按剩余空间限流、退出时清理。

这三个都是"不会报错但会出事"的形态：预取不生效只是慢；空间不限流会写爆盘；
退出不清理会让 --hf-keep 之外的临时目录越来越大。
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from tagger import hf_source


def _patch(monkeypatch, *, size: int = 10, free=None) -> list[str]:
    """把下载换成"写个小文件"的假实现，返回按顺序记下的分片名。"""
    calls: list[str] = []

    def fake_download(repo, filename, dest_dir, *, revision="main",
                      token=None, verbose=True, conns=1, proxy=""):
        calls.append(filename)
        path = Path(dest_dir) / (Path(filename).name or "shard.tar")
        path.write_bytes(b"x" * size)
        return hf_source.HFShard(repo=repo, filename=filename, path=path,
                                 bytes=size)

    monkeypatch.setattr(hf_source, "download_shard", fake_download)
    if free is not None:
        monkeypatch.setattr(hf_source, "free_bytes", free)
    return calls


def test_prefetch_downloads_next_before_consuming(tmp_path, monkeypatch):
    calls = _patch(monkeypatch, free=lambda p: 10 ** 9)
    names = ["a.tar", "b.tar", "c.tar"]
    sizes = {n: 10 for n in names}
    seen: list[str] = []
    for shard in hf_source.iter_hf_shards(
            names, repo="r", cache_dir=tmp_path, prefetch=1, sizes=sizes):
        seen.append(shard.filename)
        if len(seen) == 1:
            # 第一片还在处理，第二片就应该已经在下了（这正是预取的收益）
            assert len(calls) >= 2
        shard.path.unlink()
    assert seen == names


def test_no_space_fails_loudly(tmp_path, monkeypatch):
    _patch(monkeypatch, free=lambda p: 0)
    with pytest.raises(hf_source.HFError, match="磁盘空间不足"):
        next(iter(hf_source.iter_hf_shards(
            ["a.tar"], repo="r", cache_dir=tmp_path, sizes={"a.tar": 100})))


def test_only_one_fits_still_finishes(tmp_path, monkeypatch):
    """空间只够一片时不报错，退化成"下一片"，而不是"预取 2 片把盘写满"。"""
    def free(p):
        used = sum(f.stat().st_size for f in Path(p).glob("*"))
        return max(0, 15 - used)           # 总共 15 字节，每片 10 字节

    _patch(monkeypatch, free=free)
    names = ["a.tar", "b.tar", "c.tar"]
    got: list[str] = []
    for shard in hf_source.iter_hf_shards(
            names, repo="r", cache_dir=tmp_path, prefetch=2,
            sizes={n: 10 for n in names}):
        got.append(shard.filename)
        shard.path.unlink()      # 处理完即删，下一片才有空间
    assert got == names


def test_unconsumed_prefetch_is_cleaned(tmp_path, monkeypatch):
    _patch(monkeypatch, free=lambda p: 10 ** 9)
    names = ["a.tar", "b.tar", "c.tar"]
    gen = hf_source.iter_hf_shards(
        names, repo="r", cache_dir=tmp_path, prefetch=2,
        sizes={n: 10 for n in names})
    first = next(gen)
    first.path.unlink()
    time.sleep(0.1)          # 等预取那几片真的落盘，才测得到"退出会清理"
    gen.close()              # 模拟 --limit 提前退出
    assert list(tmp_path.glob("*.tar")) == []
