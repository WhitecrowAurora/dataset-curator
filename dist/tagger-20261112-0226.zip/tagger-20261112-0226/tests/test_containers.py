"""嵌套压缩包读取的测试。

重点不是"能列出文件名"，而是几种真实会遇到的情况：
格式和扩展名不符、密码表要重试、密码错了不能把整批卡死、临时目录要清干净。
"""

import tarfile
import zipfile
from pathlib import Path

import pytest

from tagger.containers import PasswordTable, iter_files, sniff_file


def _make_zip(path: Path, files: dict[str, bytes], compress=zipfile.ZIP_DEFLATED) -> Path:
    with zipfile.ZipFile(path, "w", compress) as zf:
        for name, data in files.items():
            zf.writestr(name, data)
    return path


def _make_tar_gz(path: Path, files: dict[str, bytes]) -> Path:
    with tarfile.open(path, "w:gz") as tf:
        for name, data in files.items():
            import io
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    return path


def _collect(gen) -> dict[str, bytes]:
    """遍历并立刻读完。

    嵌套包的条目是"解开一层、用完就删"的临时文件，所以必须在生成器推进到
    下一个之前读完——这是 iter_files 的契约，也是它不用把几十万张图同时
    展开到磁盘的代价。
    """
    out: dict[str, bytes] = {}
    for entry in gen:
        with entry.open() as fh:
            out[entry.vpath] = fh.read()
    return out


def test_single_zip(tmp_path):
    src = _make_zip(tmp_path / "a.zip", {"x/1.jpg": b"A" * 10, "x/2.png": b"B" * 20})
    got = _collect(iter_files(src, work_dir=tmp_path / "w"))
    assert got == {"x/1.jpg": b"A" * 10, "x/2.png": b"B" * 20}


def test_zip_in_zip(tmp_path):
    inner = _make_zip(tmp_path / "inner.zip", {"deep/3.jpg": b"C" * 5})
    outer = _make_zip(tmp_path / "outer.zip",
                      {"inner.zip": inner.read_bytes(), "top.jpg": b"T" * 4})

    paths = sorted(i.vpath for i in iter_files(outer, work_dir=tmp_path / "w"))
    assert paths == ["inner.zip::deep/3.jpg", "top.jpg"]


def test_tar_gz_in_zip(tmp_path):
    inner = _make_tar_gz(tmp_path / "inner.tar.gz", {"t/4.jpg": b"D" * 7})
    outer = _make_zip(tmp_path / "outer.zip", {"inner.tar.gz": inner.read_bytes()})

    got = _collect(iter_files(outer, work_dir=tmp_path / "w"))
    assert got == {"inner.tar.gz::t/4.jpg": b"D" * 7}


def test_format_detected_by_magic_not_suffix(tmp_path):
    """外层伪装成 .jpg 的 zip 也要认出来——素材包里这种很常见。"""
    liar = _make_zip(tmp_path / "actually_a_zip.jpg", {"p.jpg": b"E"})
    assert sniff_file(liar) == "zip"
    assert [i.vpath for i in iter_files(liar, work_dir=tmp_path / "w")] == ["p.jpg"]


def test_password_table_retries(tmp_path):
    """密码表里第二个才对——必须自动往下试。"""
    pyzipper = pytest.importorskip("pyzipper")
    secret = tmp_path / "secret.zip"
    with pyzipper.AESZipFile(secret, "w", compression=pyzipper.ZIP_DEFLATED,
                             encryption=pyzipper.WZ_AES) as zf:
        zf.setpassword(b"second")
        zf.writestr("s.jpg", b"F" * 6)

    outer = _make_zip(tmp_path / "outer.zip", {"secret.zip": secret.read_bytes()})
    table = PasswordTable(items=["wrong1", "wrong2", "second"])

    got = _collect(iter_files(outer, work_dir=tmp_path / "w", passwords=table))
    assert got == {"secret.zip::s.jpg": b"F" * 6}


def test_wrong_passwords_do_not_kill_the_batch(tmp_path):
    """密码全错时：记一笔失败，其余文件照常读出来。"""
    pyzipper = pytest.importorskip("pyzipper")
    secret = tmp_path / "secret.zip"
    with pyzipper.AESZipFile(secret, "w", compression=pyzipper.ZIP_DEFLATED,
                             encryption=pyzipper.WZ_AES) as zf:
        zf.setpassword(b"nobody-knows")
        zf.writestr("s.jpg", b"G")

    outer = _make_zip(tmp_path / "outer.zip",
                      {"secret.zip": secret.read_bytes(), "ok.jpg": b"H" * 3})
    table = PasswordTable(items=["a", "b"])

    items = list(iter_files(outer, work_dir=tmp_path / "w", passwords=table))
    assert [i.vpath for i in items] == ["ok.jpg"]
    assert table.failures, "打不开的容器要留下记录"


def test_unencrypted_zip_does_not_need_password(tmp_path):
    """没密码的包不能被密码表拖住：空密码必须第一个试。"""
    table = PasswordTable(items=["p1", "p2", "p3"])
    src = _make_zip(tmp_path / "plain.zip", {"n.jpg": b"I"})
    items = list(iter_files(src, work_dir=tmp_path / "w", passwords=table))
    assert [i.vpath for i in items] == ["n.jpg"]
    assert not table.failures


def test_depth_limit(tmp_path):
    """嵌套超深时要停下，不能无限递归。"""
    data = _make_zip(tmp_path / "l0.zip", {"leaf.jpg": b"J"}).read_bytes()
    for i in range(4):
        data = _make_zip(tmp_path / f"l{i + 1}.zip", {f"l{i}.zip": data}).read_bytes()

    deep = tmp_path / "l4.zip"
    deep.write_bytes(data)

    logs: list[str] = []
    items = list(iter_files(deep, work_dir=tmp_path / "w", max_depth=2,
                            on_log=logs.append))
    assert not items
    assert any("嵌套层数" in m for m in logs)


def test_work_dir_is_cleaned_up(tmp_path):
    """解出来的临时文件必须删掉，否则 10 层嵌套能把盘吃满。"""
    work = tmp_path / "w"
    inner = _make_zip(tmp_path / "inner.zip", {"a.jpg": b"K"})
    outer = _make_zip(tmp_path / "outer.zip", {"inner.zip": inner.read_bytes()})

    list(iter_files(outer, work_dir=work))
    leftovers = [p for p in work.rglob("*") if p.is_file()]
    assert leftovers == []


def test_broken_archive_is_skipped(tmp_path):
    """半个坏包不能让整批素材失败。"""
    bad = tmp_path / "broken.zip"
    bad.write_bytes(b"PK\x03\x04" + b"\x00" * 40)
    good = _make_zip(tmp_path / "good.zip", {"g.jpg": b"L"})

    items = list(iter_files(tmp_path, work_dir=tmp_path / "w"))
    assert [i.vpath for i in items] == ["g.jpg"]
    assert good.exists()
