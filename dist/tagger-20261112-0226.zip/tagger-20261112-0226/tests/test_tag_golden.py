"""黄金数值测试：预处理/精度/词表一旦悄悄变了，这里必须变红。

为什么非有不可
--------------
仓库里其余测试全是结构性断言（参数怎么落、批怎么攒、字段有没有），
没有一条会因为"预处理换了实现"而失败。而这类事故已经出现过一次：
必须读取权重目录的 config.json：该权重使用短边缩放 + 居中裁剪、
mean/std=0.5，以及 RoPE ref_feat_shape=32×32。只用 timm 架构默认值
会加载另一套配置，代码能跑，整批输出却改变了。

本用例用**合成图**（不提交二进制素材）：固定随机种子画色块，
在真实权重上跑一遍 fp32/CPU（确定性最好，不受驱动与 tf32 影响），
把 top-N tag 与概率钉住。

跑法
----
    env\\python\\python.exe -m pytest tests/test_tag_golden.py -q

没有 `models/wd-eva02` 时自动跳过（CI 上本来也没有 1.3 GB 权重）。
更新期望值：
    env\\python\\python.exe devtools\\dump_golden.py
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

MODEL_DIR = Path(os.environ.get("TAGGER_GOLDEN_MODEL", "models/wd-eva02"))
THRESHOLD = 0.35
# 阈值边界带：落在 阈值±MARGIN 内的 tag 本来就不稳定（换 PIL 版本、换机器
# 都可能翻面），断言时按"稳定区必须一致、边界带只记录"处理。
# 这套判据与 devtools/verify_dtype.py --margin 是同一个口径。
MARGIN = 0.02

# fp32 / CPU / 默认 keep / 阈值 0.35。2026-11-08 与 timm 官方
# local-dir 加载 + resolve_data_config/create_transform 独立比对全部概率，最大差 0。
EXPECTED: dict[str, dict[str, float]] = {
    "img0": {'flat_color': 0.9493, 'no_lineart': 0.9334, 'no_humans': 0.9044,
             'green_background': 0.8645, 'simple_background': 0.7921,
             'close-up': 0.7149, 'food': 0.5547, 'what': 0.4976,
             'tooth': 0.3545, 'hat': 0.3503},
    "img1": {'no_lineart': 0.9672, 'no_humans': 0.9414, 'dango': 0.9246,
             'green_background': 0.8817, 'wagashi': 0.8693, 'food': 0.8427,
             'flat_color': 0.7902, 'simple_background': 0.7881,
             'food_focus': 0.6099, 'green_eyes': 0.5917, 'sanshoku_dango': 0.5788,
             'peach': 0.4905, 'fruit': 0.4838, 'close-up': 0.4448, 'moon': 0.3760},
}

# rating 是四个独立 sigmoid，**加起来不等于 1**（实测 img0 ≈ 1.44）。
# 这里只钉"能稳定复现的那一个"：合成图无人物，general 必须占主导。
EXPECTED_RATING_MAX = {"img0": "general", "img1": "general"}


def _images() -> list:
    """两张确定性的合成图。

    有结构（渐变 + 色块 + 椭圆）而不是纯噪声：纯噪声上分类头输出接近均匀，
    阈值附近全是随机的，期望值不可复现；有结构才能让 tag 落到稳定的区间。
    """
    import random

    from PIL import Image, ImageDraw

    rng = random.Random(20261102)
    out = []
    for _ in range(2):
        im = Image.new("RGB", (448, 448), (rng.randrange(60, 200),
                                           rng.randrange(60, 200),
                                           rng.randrange(60, 200)))
        draw = ImageDraw.Draw(im)
        for _ in range(12):
            x0, y0 = rng.randrange(448), rng.randrange(448)
            x1 = min(447, x0 + rng.randrange(40, 240))
            y1 = min(447, y0 + rng.randrange(40, 240))
            draw.ellipse([x0, y0, x1, y1], fill=(rng.randrange(256),
                                                 rng.randrange(256),
                                                 rng.randrange(256)))
        out.append(im)
    return out


pytestmark = pytest.mark.skipif(
    not MODEL_DIR.is_dir(),
    reason=f"没有权重目录 {MODEL_DIR}（1.3 GB，CI 上通常没有）",
)


def _backend():
    from tagger.cpu_tagger import build_backend

    return build_backend(
        "wd-eva02", model_dir=MODEL_DIR, device="cpu", precision="fp32",
        batch_size=1, use_graph=False, verbose=False,
        thresholds={"default": THRESHOLD},
    )


@pytest.fixture(scope="module")
def preds():
    """整个模块只加载一次模型：CPU 上加载要十来秒，两个用例各来一遍太浪费。"""
    backend = _backend()
    backend.load()
    return backend.predict_batch(_images())


def test_golden_tags_and_probs(preds):
    for key, pred in zip(EXPECTED, preds):
        expected = EXPECTED[key]
        assert expected, f"{key} 的期望值是空的：先跑 devtools/dump_golden.py"
        got = dict(pred.tags)

        # 只断言"稳定区"（离阈值超过一个边界带）的 tag：边界带上的翻面
        # 换台机器也会发生，钉死它只会让测试变成环境探测器。
        stable_want = {t: p for t, p in expected.items()
                       if abs(p - THRESHOLD) > MARGIN}
        stable_got = {t: p for t, p in got.items()
                      if abs(p - THRESHOLD) > MARGIN}
        assert set(stable_got) == set(stable_want), (
            f"{key} 的稳定 tag 集合变了\n  多了 {sorted(set(stable_got) - set(stable_want))}\n"
            f"  少了 {sorted(set(stable_want) - set(stable_got))}")
        # 集合没变、概率整体平移同样是事故（换精度 / 换归一化 / 换重采样）
        for tag, want in stable_want.items():
            assert abs(stable_got[tag] - want) <= 5e-3, (
                f"{key} 的 {tag} 概率 {stable_got[tag]:.4f} 偏离期望 {want:.4f}")


def test_golden_rating_distribution(preds):
    """rating 必须存在且量级对：它是清洗数据要用的信号，不该悄悄消失。

    注意四个是**独立 sigmoid**，和不等于 1（实测 img0 ≈ 1.44），
    所以这里断言的是"谁占主导"，不是概率分布归一。
    """
    for key, pred in zip(EXPECTED_RATING_MAX, preds):
        assert set(pred.rating) == {"general", "sensitive", "questionable", "explicit"}
        top = max(pred.rating, key=pred.rating.get)
        assert top == EXPECTED_RATING_MAX[key], (
            f"{key} 的 rating 主项从 {EXPECTED_RATING_MAX[key]} 变成 {top}"
            f"（{pred.rating}）")
        # 合成图是纯色块，general 应当很高；掉下来说明 rating 头接错了
        assert pred.rating["general"] > 0.8, pred.rating
