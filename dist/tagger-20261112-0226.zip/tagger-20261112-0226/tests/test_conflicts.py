"""冲突与决策：同 id 两份不同内容 → 扫描 / 批准 / 合并按批准走。

这个功能的正确性只体现在一件事上：**人点了「保留这份」之后，合并的结论
真的变了，而且不再报失败**。所以测试的重心是端到端那条链，不是扫描函数本身。
"""

from __future__ import annotations

import json
from itertools import permutations

import pytest

from tagger import conflicts as cf
from tagger.artifacts import JsonlSink, parse_payload
from tagger.merge import collect, MergeStats

TAG_A = {"image_id": "a", "tag": "1girl, red_dress", "tag_backend": "wd-eva02"}
TAG_B = {"image_id": "a", "tag": "1girl, blue_dress, solo", "tag_backend": "vlm"}
NL_A = {"image_id": "a", "caption": "一个女孩"}
NL_B = {"image_id": "a", "caption": "一个穿蓝裙子的女孩站在窗边，侧身看向镜头外面"}


def _write(root, rows, stem="dist-01"):
    """rows: [(image_id, tag_payload|None, nl_payload|None)]"""
    sink = JsonlSink(root, rows_per_file=100, stem=stem)
    for image_id, tag, nl in rows:
        sink.add(image_id, tag, nl)
    sink.close()


def _decisions_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("TAGGER_CONFLICT_DIR", str(tmp_path / "state"))
    monkeypatch.setattr(cf, "CONFLICT_DIR", str(tmp_path / "state"))


def test_two_versions_of_the_same_image_are_a_conflict(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")

    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    kinds = sorted(item.kind for item in res.items)
    assert kinds == ["nl", "tag"]
    assert res.idempotent == 0
    for item in res.items:
        assert len(item.candidates) == 2
        assert item.decided == ""


def test_identical_content_is_not_a_conflict(tmp_path, monkeypatch):
    """重跑没清目录产生的幂等重复不该进待办——取一份就行，不需要人点。"""
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "one", [("a", TAG_A, NL_A)], stem="one")
    _write(tmp_path / "two", [("a", TAG_A, NL_A)], stem="two")

    res = cf.scan([tmp_path / "one", tmp_path / "two"])
    assert res.items == []
    assert res.idempotent == 2          # tag + nl 各一次


def test_scan_reports_unreadable_inputs_and_keeps_readable_candidates(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, None)])
    _write(tmp_path / "new", [("a", TAG_B, None)])
    (tmp_path / "old" / "artifacts-bad.jsonl").write_text('{"image_id":\n', encoding="utf-8")
    result = cf.scan([tmp_path / "old", tmp_path / "new", tmp_path / "missing"])
    assert result.unreadable == 2 and len(result.items) == 1
    cf.save_index(result)
    assert cf.load_index().unreadable == 2


def test_decide_makes_merge_take_the_chosen_side(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")

    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    tag_item = next(it for it in res.items if it.kind == "tag")
    newer = max(tag_item.candidates, key=lambda c: c.chars)
    cf.decide("a", "tag", newer.digest)

    stats = MergeStats()
    records = collect([tmp_path / "old", tmp_path / "new"], stats=stats,
                      decisions=cf.picks_for_merge())
    rec = records["a"]
    # Record.tag 存的是**正文**（tag 串），不是整个 payload；payload 在 prov 里。
    assert rec.tag == TAG_B["tag"]                          # 取了批的那份
    assert "a|tag" in stats.resolved
    # nl 没人批，仍然要报冲突——不能因为批了 tag 就把 nl 也放过去
    assert "a" in stats.duplicates
    assert stats.failed


def test_decide_survives_rescan_when_candidate_order_changes(tmp_path, monkeypatch):
    """决策存的是内容哈希，不是下标：候选顺序变了也不会套到另一份上。"""
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")
    first = cf.scan([tmp_path / "old", tmp_path / "new"])
    digest_b = next(c.digest for it in first.items if it.kind == "tag"
                    for c in it.candidates if "blue" in c.value)
    cf.decide("a", "tag", digest_b)

    # 反过来扫（顺序变了），已定的仍然标在同一个内容上
    second = cf.scan([tmp_path / "new", tmp_path / "old"],
                     decisions=cf.picks_for_merge())
    tag_item = next(it for it in second.items if it.kind == "tag")
    assert tag_item.decided == digest_b
    assert "blue" in next(c for c in tag_item.candidates
                          if c.digest == digest_b).value


def test_auto_newest_and_longest(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")

    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    out = cf.auto_decide(res, "longest")
    assert out["applied"] == 2
    picks = cf.picks_for_merge()
    # 最长 = 字符最多那份：tag 是 B，nl 也是 B
    for item in res.items:
        chosen = next(c for c in item.candidates if c.digest == picks[item.key])
        assert chosen.chars == max(c.chars for c in item.candidates)

    # 已经批过的不再被 newest 覆盖
    before = dict(picks)
    cf.auto_decide(cf.scan([tmp_path / "old", tmp_path / "new"]), "newest")
    assert cf.picks_for_merge() == before


def test_auto_newest_picks_later_ts(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")
    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    cf.auto_decide(res, "newest")
    picks = cf.picks_for_merge()
    for item in res.items:
        chosen = next(c for c in item.candidates if c.digest == picks[item.key])
        assert chosen.ts == max(c.ts for c in item.candidates)


def test_manual_strategy_does_nothing(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")
    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    out = cf.auto_decide(res, "manual")
    assert out["applied"] == 0
    assert cf.picks_for_merge() == {}


def test_index_roundtrips_without_rescanning(tmp_path, monkeypatch):
    """页面刷新不该重扫一遍：索引里要能还原出候选内容。"""
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")
    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    cf.save_index(res)

    loaded = cf.load_index()
    assert loaded is not None
    assert len(loaded.items) == len(res.items)
    assert loaded.scanned == res.scanned
    got = {(it.image_id, it.kind): sorted(c.digest for c in it.candidates)
           for it in loaded.items}
    want = {(it.image_id, it.kind): sorted(c.digest for c in it.candidates)
            for it in res.items}
    assert got == want


def test_web_scan_decide_and_auto_roundtrip(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient

    from tagger.web import app as app_mod

    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")

    client = TestClient(app_mod.create_app(ui_dist=tmp_path / "no-ui"))
    assert client.get("/api/conflicts").json()["index"] is False

    res = client.post("/api/conflicts/scan",
                      json={"roots": [str(tmp_path / "old"), str(tmp_path / "new")]})
    assert res.status_code == 200
    body = res.json()
    assert body["index"] is True and body["total"] == 2

    item = body["items"][0]
    pick = item["candidates"][0]["digest"]
    res = client.post("/api/conflicts/decide",
                      json={"image_id": item["image_id"], "kind": item["kind"],
                            "pick": pick})
    assert res.status_code == 200 and res.json()["decisions"] == 1
    state = client.get("/api/conflicts").json()
    assert next(it for it in state["items"] if it["key"] == item["key"])["decided"] == pick
    # 改选和重复批准都只能计数一次。
    pick = item["candidates"][1]["digest"]
    for _ in range(2):
        assert client.post("/api/conflicts/decide", json={
            "image_id": item["image_id"], "kind": item["kind"], "pick": pick,
        }).json()["decisions"] == 1

    res = client.post("/api/conflicts/auto", json={"strategy": "longest"})
    assert res.status_code == 200
    assert res.json()["applied"] == 1          # 剩下那条未批的被批量批掉
    assert res.json()["skipped"] == 1          # 人工批过的不覆盖
    assert all(it["decided"] for it in client.get("/api/conflicts").json()["items"])

    # 撤销：pick 空串
    client.post("/api/conflicts/decide",
                json={"image_id": item["image_id"], "kind": item["kind"], "pick": ""})
    assert client.get("/api/conflicts").json()["decisions"] == 1
    state = client.get("/api/conflicts").json()
    assert not next(it for it in state["items"] if it["key"] == item["key"])["decided"]


def test_three_candidates_use_chosen_content_and_metadata_in_any_order(tmp_path):
    roots = [tmp_path / str(i) for i in range(3)]
    for i, root in enumerate(roots):
        _write(root, [("a", {"tag": f"tag-{i}", "image_path": f"{i}.png",
                              "provenance": {"model_id": f"model-{i}"}}, None)])
    for order in permutations(roots):
        for i in range(3):
            stats = MergeStats()
            rec = collect(order, stats=stats, decisions={"a|tag": cf._digest(f"tag-{i}")})["a"]
            assert not stats.failed and stats.resolved == ["a|tag"]
            assert rec.tag == f"tag-{i}" and rec.image_path == f"{i}.png"
            assert rec.prov["tag"] == {"model_id": f"model-{i}"}
            assert rec.src_files == [f"{roots[i] / 'artifacts-dist-01.jsonl'}#0"]
        stats = MergeStats()
        collect(order, stats=stats, decisions={"a|tag": "expired"})
        assert stats.failed and not stats.resolved


def test_old_decision_missing_from_candidates_is_undecided(tmp_path, monkeypatch):
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, None)])
    _write(tmp_path / "new", [("a", TAG_B, None)])
    cf.decide("a", "tag", "expired")
    result = cf.scan([tmp_path / "old", tmp_path / "new"], decisions=cf.picks_for_merge())
    assert result.decided_count == 0
    cf.save_index(result)
    assert cf.load_index().decided_count == 0
    assert cf.auto_decide(result, "longest")["applied"] == 1
    assert cf.load_index().decided_count == 1


def test_web_merge_uses_saved_decision(tmp_path, monkeypatch):
    from tagger.web.packaging import MergeParams, run_merge

    _decisions_dir(tmp_path, monkeypatch)
    roots = [tmp_path / "old", tmp_path / "new"]
    _write(roots[0], [("a", TAG_A, None)])
    _write(roots[1], [("a", TAG_B, None)])
    cf.decide("a", "tag", cf._digest(TAG_B["tag"]))
    out = tmp_path / "merged.jsonl"
    result = run_merge(MergeParams(roots=[str(r) for r in roots], out=str(out),
                                   require="tag", sample_n=0),
                       on_progress=lambda *args: None, should_stop=lambda: False,
                       on_log=lambda *args: None)
    assert json.loads(out.read_text(encoding="utf-8"))["tag"] == TAG_B["tag"]
    assert result["duplicates_n"] == 0 and not result["failed"]


def test_merge_cli_reads_decisions(tmp_path, monkeypatch):
    """命令行走的就是默认 decisions 文件，不需要额外参数。"""
    from tagger.cli import build_parser, cmd_merge

    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, NL_A)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, NL_B)], stem="new")
    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    for item in res.items:
        pick = max(item.candidates, key=lambda c: c.chars).digest
        cf.decide(item.image_id, item.kind, pick)

    args = build_parser().parse_args([
        "merge", "--roots", str(tmp_path / "old"), str(tmp_path / "new"),
        "--out", str(tmp_path / "merged.jsonl"),
    ])
    assert cmd_merge(args) == 0
    rows = [json.loads(line) for line in
            (tmp_path / "merged.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    assert len(rows) == 1
    assert "blue_dress" in rows[0]["tag"]


def test_unscanned_kinds_still_report_as_conflict(tmp_path, monkeypatch):
    """批了 tag 不等于批了 nl：没批的那一侧照旧算失败，不许静默放行。"""
    _decisions_dir(tmp_path, monkeypatch)
    _write(tmp_path / "old", [("a", TAG_A, None)], stem="old")
    _write(tmp_path / "new", [("a", TAG_B, None)], stem="new")
    res = cf.scan([tmp_path / "old", tmp_path / "new"])
    pick = max(res.items[0].candidates, key=lambda c: c.chars).digest
    cf.decide("a", "tag", pick)

    stats = MergeStats()
    records = collect([tmp_path / "old", tmp_path / "new"], stats=stats,
                      decisions=cf.picks_for_merge())
    assert stats.resolved == ["a|tag"]
    assert not stats.duplicates
    assert records["a"].tag and parse_payload("tag", records["a"].tag)
